import ApiView from '@/components/ApiView';

export const metadata = { title: 'API & นักพัฒนา — NearbyShop' };

export default function Page() {
  return <ApiView />;
}
