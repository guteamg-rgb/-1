import LoginView from '@/components/LoginView';

export const metadata = { title: 'เข้าสู่ระบบ — NearbyShop' };

export default function Page() {
  return <LoginView />;
}
