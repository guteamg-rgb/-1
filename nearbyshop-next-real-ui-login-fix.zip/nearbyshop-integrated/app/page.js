import HomeView from '@/components/HomeView';

export const metadata = { title: 'NearbyShop — Game Top-Up' };

export default function Page() {
  return <HomeView />;
}
