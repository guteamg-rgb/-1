import AdminDashboard from '@/components/AdminDashboard';
export const dynamic = 'force-dynamic';
export const metadata = { title: 'NearbyShop Admin' };
export default function AdminPage() { return <AdminDashboard />; }
