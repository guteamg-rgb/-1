import NewsView from '@/components/NewsView';

export const metadata = { title: 'ข่าวสาร & บทความ — NearbyShop' };

export default function Page() {
  return <NewsView />;
}
