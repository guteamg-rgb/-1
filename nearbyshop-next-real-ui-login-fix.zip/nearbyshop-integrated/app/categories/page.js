import CategoriesView from '@/components/CategoriesView';

export const metadata = { title: 'หมวดหมู่เกม — NearbyShop' };

export default async function Page({ searchParams }) {
  const { cat } = await searchParams;
  // key = cat ทำให้รีเซ็ตตัวกรอง/คำค้นหาเมื่อเข้ามาด้วยหมวดต่างกัน (เหมือนโหลดหน้าใหม่)
  return <CategoriesView key={cat ?? ''} initialCat={Array.isArray(cat) ? cat[0] : cat} />;
}
