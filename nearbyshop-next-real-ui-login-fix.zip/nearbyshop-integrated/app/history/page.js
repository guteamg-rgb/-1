import HistoryView from '@/components/HistoryView';

export const metadata = { title: 'ประวัติรายการ — NearbyShop' };

export default function Page() {
  return <HistoryView />;
}
