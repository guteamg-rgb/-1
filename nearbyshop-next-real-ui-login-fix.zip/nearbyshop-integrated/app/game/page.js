import { redirect } from 'next/navigation';
import GameView from '@/components/GameView';
import { games } from '@/lib/games';
async function fetchGame(name) {
  const url = process.env.NEXT_PUBLIC_SUPABASE_URL; const key = process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY;
  if (!url || !key) return games.find((x) => x.name === name);
  try { const r = await fetch(`${url}/rest/v1/games?name=eq.${encodeURIComponent(name)}&active=eq.true&select=*,game_packages(*)`, { headers: { apikey: key, Authorization: `Bearer ${key}` }, cache: 'no-store' }); const rows = await r.json(); const g = rows?.[0]; return g ? { ...g, cat: g.category, sub: g.subtext, img: g.cover_url, packs: g.game_packages?.map(p => [p.name, Number(p.price)]) || [] } : null; } catch { return games.find((x) => x.name === name); }
}
const findGame = async (searchParams) => { const { g } = await searchParams; return fetchGame(Array.isArray(g) ? g[0] : g); };
export async function generateMetadata({ searchParams }) { const game = await findGame(searchParams); return { title: game ? game.name + ' — NearbyShop' : 'เติมเกม — NearbyShop' }; }
export default async function Page({ searchParams }) { const game = await findGame(searchParams); if (!game) redirect('/categories'); return <GameView key={game.id || game.name} game={game} />; }
