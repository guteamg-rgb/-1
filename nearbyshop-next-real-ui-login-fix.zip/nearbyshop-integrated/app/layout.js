import { Suspense } from 'react';
import 'sweetalert2/dist/sweetalert2.min.css';
import './globals.css';
import { AppProvider } from '@/context/AppContext';
import SvgSprite from '@/components/SvgSprite';
import PageLoader from '@/components/PageLoader';
import Header from '@/components/Header';
import Footer from '@/components/Footer';
import Drawer from '@/components/Drawer';
import RouteWatcher from '@/components/RouteWatcher';

export const metadata = {
  title: 'NearbyShop — Game Top-Up',
};

export const viewport = {
  width: 'device-width',
  initialScale: 1.0,
  viewportFit: 'cover',
  themeColor: '#090d17',
};

export default function RootLayout({ children }) {
  return (
    <html lang="th">
      <head>
        <link rel="preconnect" href="https://fonts.googleapis.com" />
        <link rel="preconnect" href="https://fonts.gstatic.com" crossOrigin="anonymous" />
        <link
          href="https://fonts.googleapis.com/css2?family=Sarabun:wght@300;400;500;600;700&display=swap"
          rel="stylesheet"
        />
      </head>
      <body>
        <AppProvider>
          <SvgSprite />
          <PageLoader />
          <Header />
          <main className="app-shell">{children}</main>
          <Footer />
          <Drawer />
          <Suspense fallback={null}>
            <RouteWatcher />
          </Suspense>
        </AppProvider>
      </body>
    </html>
  );
}
