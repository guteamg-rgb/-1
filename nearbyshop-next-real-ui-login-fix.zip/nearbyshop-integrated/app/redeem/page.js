import RedeemView from '@/components/RedeemView';

export const metadata = { title: 'แลกโค้ดรางวัล — NearbyShop' };

export default function Page() {
  return <RedeemView />;
}
