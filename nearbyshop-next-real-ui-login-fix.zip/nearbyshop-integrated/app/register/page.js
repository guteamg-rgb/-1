import RegisterView from '@/components/RegisterView';

export const metadata = { title: 'สมัครสมาชิก — NearbyShop' };

export default function Page() {
  return <RegisterView />;
}
