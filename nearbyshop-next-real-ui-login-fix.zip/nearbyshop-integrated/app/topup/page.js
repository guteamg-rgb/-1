import TopupView from '@/components/TopupView';

export const metadata = { title: 'เติมเงิน — NearbyShop' };

export default function Page() {
  return <TopupView />;
}
