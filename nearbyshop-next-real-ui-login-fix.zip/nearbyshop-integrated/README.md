# NearbyShop — หน้าบ้าน + หลังบ้าน

โปรเจกต์ Next.js App Router ที่รวมหน้าร้านค้าและหน้าแอดมินไว้ใน ZIP เดียว

## การตั้งค่าระบบจริง

1. สร้างโปรเจกต์ Supabase และรันไฟล์ `supabase/schema.sql` ใน SQL Editor
2. สร้างไฟล์ `.env.local` จาก `.env.example` แล้วใส่ `NEXT_PUBLIC_SUPABASE_URL` และ `NEXT_PUBLIC_SUPABASE_ANON_KEY`
3. สร้างบัญชีผู้ดูแลผ่าน Supabase Authentication แล้วรันคำสั่งสร้าง profile admin ที่ท้าย `supabase/schema.sql`
4. ตั้งค่า Email provider และ Redirect URL ใน Supabase ให้ตรงกับโดเมนที่ใช้งาน

## เริ่มใช้งาน

```bash
npm install
npm run dev
# http://localhost:3000

npm run build && npm start
```

หน้าบ้านใช้ Next.js App Router และหลังบ้านยังคง UI เดิมทั้งหมดใน `public/admin/` เช่น `index.html`, `games.html`, `orders.html`, `settings.html` และไฟล์ assets เดิม โดย `app.js` ใช้ Supabase Auth/RLS และโหลดข้อมูลจากฐานข้อมูลจริงก่อน render ตาราง

ระบบหน้าร้านใช้ Supabase Auth จริงแล้ว และฟังก์ชันแลกรางวัล/ตัดเครดิตสั่งซื้อถูกทำเป็น PostgreSQL RPC แบบ atomic เพื่อป้องกันการตัดยอดซ้ำหรือ race condition

เปิดหลังบ้านที่ `/admin` หรือ URL เดิมอย่าง `/admin/index.html` ได้ โดย URL เดิมจะถูกส่งไปยังระบบใหม่ที่ใช้ session เดียวกัน ข้อมูล seed เหลือไว้เป็น fallback ใน source เท่านั้น และจะไม่ถูกใช้เมื่อ Supabase ตั้งค่าและ Auth สำเร็จ
