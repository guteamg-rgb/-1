import { NextResponse } from 'next/server';
export function middleware(request) {
  const { pathname } = request.nextUrl;
  if (pathname.startsWith('/admin/') && pathname !== '/admin/') {
    const url = request.nextUrl.clone(); url.pathname = '/admin'; url.search = ''; return NextResponse.redirect(url);
  }
  return NextResponse.next();
}
export const config = { matcher: ['/admin/:path*'] };
