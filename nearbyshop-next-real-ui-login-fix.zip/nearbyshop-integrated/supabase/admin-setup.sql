-- NearbyShop: ตั้งค่าบัญชี Admin
-- วิธีใช้:
-- 1) สร้างผู้ใช้ก่อนที่ Supabase Dashboard > Authentication > Users > Add user
-- 2) แก้ค่า v_admin_email ด้านล่างให้ตรงกับอีเมลผู้ใช้
-- 3) รัน supabase/schema.sql ก่อน แล้วจึงรันไฟล์นี้
-- หมายเหตุ: ห้ามใส่รหัสผ่านไว้ใน SQL ไฟล์นี้ ให้ตั้งรหัสผ่านผ่าน Supabase Auth เท่านั้น

DO $$
DECLARE
  v_admin_email text := 'eemailroblox@gmail.com';
  v_user_id uuid;
BEGIN
  SELECT id INTO v_user_id
  FROM auth.users
  WHERE lower(email) = lower(v_admin_email)
  LIMIT 1;

  IF v_user_id IS NULL THEN
    RAISE EXCEPTION 'ไม่พบผู้ใช้ใน auth.users สำหรับอีเมล: %. ให้สร้างผู้ใช้ใน Authentication > Users ก่อน', v_admin_email;
  END IF;

  INSERT INTO public.profiles (id, username, email, role, credit)
  VALUES (v_user_id, 'Team', v_admin_email, 'admin', 0)
  ON CONFLICT (id) DO UPDATE SET
    email = EXCLUDED.email,
    role = 'admin';

  RAISE NOTICE 'ตั้งค่า Admin สำเร็จสำหรับ % (UID: %)', v_admin_email, v_user_id;
END $$;

-- ตรวจสอบผลลัพธ์
SELECT id, username, email, role, credit, created_at
FROM public.profiles
WHERE role = 'admin';

-- Required for logging in with username (for example: Team)
create or replace function public.resolve_login_email(p_username text)
returns text language sql security definer set search_path = public stable
as $$ select email from public.profiles where lower(username) = lower(trim(p_username)) limit 1; $$;
revoke all on function public.resolve_login_email(text) from public;
grant execute on function public.resolve_login_email(text) to anon, authenticated;
