# Supabase setup สำหรับ NearbyShop

## 1. สร้างตาราง

1. เปิด Supabase Dashboard ของโปรเจกต์
2. ไปที่ **SQL Editor → New query**
3. เปิดไฟล์ `supabase/schema.sql`
4. คัดลอกทั้งหมดไปวาง แล้วกด **Run**

สคริปต์นี้สร้างตารางและ RLS policies แบบรันซ้ำได้ และไม่มี API key อยู่ภายใน

## 2. สร้างบัญชีแอดมิน

1. ไปที่ **Authentication → Users → Add user**
2. สร้าง user เช่น `team@nearbyshop.local`
3. ตั้งรหัสผ่านตามที่ต้องการ
4. คัดลอก User UID
5. กลับไปที่ SQL Editor แล้วรันคำสั่งท้ายไฟล์ `schema.sql` โดยแทนที่ `AUTH-USER-UUID-HERE`

ตัวอย่าง:

```sql
insert into public.profiles (id, username, email, role)
values ('USER-UUID-FROM-AUTH', 'Team', 'team@nearbyshop.local', 'admin')
on conflict (id) do update set username = excluded.username, role = 'admin';
```

## 3. หลังสร้างตาราง

โปรเจกต์ต้องติดตั้ง Supabase SDK และเปลี่ยน query ในหน้าบ้าน/หลังบ้านจาก `localStorage` และ `SEED` ไปใช้ Supabase client ก่อนจึงจะอ่านและเขียนข้อมูลจริงได้
