'use client';
import { createContext, useCallback, useContext, useEffect, useMemo, useState } from 'react';
import { usePathname, useRouter } from 'next/navigation';
import Swal from 'sweetalert2';
import { store } from '@/lib/store';
import { pageOf, pathOf } from '@/lib/nav';
import { supabase } from '@/lib/supabase';

const AppContext = createContext(null);
export const useApp = () => useContext(AppContext);
const errorText = (e) => /invalid login credentials/i.test(e?.message || '') ? 'อีเมลหรือรหัสผ่านไม่ถูกต้อง' : (e?.message || 'เกิดข้อผิดพลาดจากระบบ');

export function AppProvider({ children }) {
  const router = useRouter(); const pathname = usePathname(); const page = pageOf(pathname);
  const [ready, setReady] = useState(false); const [currentUser, setCurrentUser] = useState(null);
  const [drawerOpen, setDrawerOpen] = useState(false); const [loading, setLoading] = useState(false);
  const loadProfile = useCallback(async (user) => {
    if (!user || !supabase) { setCurrentUser(null); return; }
    const { data } = await supabase.from('profiles').select('id,username,email,role,credit').eq('id', user.id).maybeSingle();
    setCurrentUser(data ? { ...data, isAdmin: data.role === 'admin' } : { id: user.id, username: user.user_metadata?.username || user.email?.split('@')[0], email: user.email, role: 'customer', credit: 0, isAdmin: false });
  }, []);
  useEffect(() => {
    let active = true;
    if (!supabase) { setReady(true); return undefined; }
    supabase.auth.getSession().then(({ data: { session } }) => loadProfile(session?.user)).finally(() => { if (active) setReady(true); });
    const { data: listener } = supabase.auth.onAuthStateChange((_event, session) => { if (active) loadProfile(session?.user); });
    return () => { active = false; listener.subscription.unsubscribe(); };
  }, [loadProfile]);
  useEffect(() => { const onKey = (e) => e.key === 'Escape' && setDrawerOpen(false); document.addEventListener('keydown', onKey); return () => document.removeEventListener('keydown', onKey); }, []);
  const openDrawer = useCallback(() => setDrawerOpen(true), []); const closeDrawer = useCallback(() => setDrawerOpen(false), []);
  const navigate = useCallback((target, query = '') => { setDrawerOpen(false); if ((target === 'login' || target === 'register') && !['login','register'].includes(page)) store.set('nearbyshop_after_login', pathOf(page) + window.location.search); const url = pathOf(target) + query; if (url === pathname + window.location.search) return window.scrollTo(0, 0); setLoading(true); router.push(url); }, [page, pathname, router]);
  const afterAuth = useCallback(async (msg) => { await Swal.fire({ title: 'สำเร็จ', text: msg, icon: 'success', confirmButtonText: 'ตกลง' }); let dest = store.get('nearbyshop_after_login'); store.del('nearbyshop_after_login'); if (!dest || !/^\/[a-z]*(\?\S*)?$/.test(dest) || /^\/(login|register)(\?|$)/.test(dest)) dest = '/'; router.push(dest); }, [router]);
  const login = useCallback(async (identifier, password) => {
    if (!supabase) return Swal.fire({ title: 'ยังไม่ได้ตั้งค่าระบบ', text: 'กรุณาตั้งค่า Supabase ใน .env.local ก่อนใช้งาน', icon: 'error', confirmButtonText: 'ตกลง' });
    if (!identifier.trim() || !password) return Swal.fire({ title: 'ผิดพลาด', text: 'กรุณากรอกข้อมูลให้ครบถ้วน', icon: 'error', confirmButtonText: 'ตกลง' });
    setLoading(true); let email = identifier.trim();
    if (!email.includes('@')) { const { data, error: lookupError } = await supabase.rpc('resolve_login_email', { p_username: email }); if (lookupError || !data) { setLoading(false); return Swal.fire({ title: 'เข้าสู่ระบบไม่สำเร็จ', text: 'ไม่พบบัญชีผู้ใช้นี้ หรือฐานข้อมูลยังไม่ได้อัปเดตฟังก์ชัน Login', icon: 'error', confirmButtonText: 'ตกลง' }); } email = data; }
    const { error } = await supabase.auth.signInWithPassword({ email, password }); setLoading(false);
    if (error) return Swal.fire({ title: 'เข้าสู่ระบบไม่สำเร็จ', text: errorText(error), icon: 'error', confirmButtonText: 'ตกลง' }); await afterAuth('เข้าสู่ระบบเรียบร้อยแล้ว');
  }, [afterAuth]);
  const register = useCallback(async (username, email, password, confirm) => {
    username = username.trim(); email = email.trim(); const err = (m) => Swal.fire({ title: 'ผิดพลาด', text: m, icon: 'error', confirmButtonText: 'ตกลง' });
    if (!username || !email || !password || !confirm) return err('กรุณากรอกข้อมูลให้ครบถ้วน'); if (!/^[A-Za-z0-9_-]{3,20}$/.test(username)) return err('ชื่อผู้ใช้ต้องยาว 3-20 ตัวอักษร'); if (!/^\S+@\S+\.\S+$/.test(email)) return err('รูปแบบอีเมลไม่ถูกต้อง'); if (password.length < 6) return err('รหัสผ่านต้องมีอย่างน้อย 6 ตัวอักษร'); if (password !== confirm) return err('รหัสผ่านไม่ตรงกัน'); if (!supabase) return err('กรุณาตั้งค่า Supabase ใน .env.local ก่อนใช้งาน');
    setLoading(true); const { data, error } = await supabase.auth.signUp({ email, password, options: { data: { username } } }); setLoading(false); if (error) return err(errorText(error));
    if (data.session) await afterAuth('สมัครสมาชิกเรียบร้อยแล้ว'); else Swal.fire({ title: 'สมัครสมาชิกสำเร็จ', text: 'กรุณาตรวจสอบอีเมลเพื่อยืนยันบัญชีก่อนเข้าสู่ระบบ', icon: 'success', confirmButtonText: 'ตกลง' }).then(() => router.push('/login'));
  }, [afterAuth, router]);
  const logout = useCallback(async () => { setDrawerOpen(false); const r = await Swal.fire({ title: 'ออกจากระบบ?', text: 'คุณต้องการออกจากระบบใช่หรือไม่', icon: 'warning', showCancelButton: true, confirmButtonText: 'ออกจากระบบ', cancelButtonText: 'ยกเลิก' }); if (!r.isConfirmed) return; if (supabase) await supabase.auth.signOut(); setCurrentUser(null); store.del('nearbyshop_user'); router.push('/'); }, [router]);
  const value = useMemo(() => ({ ready, currentUser, page, drawerOpen, loading, setLoading, openDrawer, closeDrawer, navigate, login, register, logout }), [ready, currentUser, page, drawerOpen, loading, openDrawer, closeDrawer, navigate, login, register, logout]);
  return <AppContext.Provider value={value}>{children}</AppContext.Provider>;
}
