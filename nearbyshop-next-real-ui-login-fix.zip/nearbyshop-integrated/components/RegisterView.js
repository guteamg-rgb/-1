'use client';

import { useState } from 'react';
import { useApp } from '@/context/AppContext';
import NavLink from '@/components/NavLink';

export default function RegisterView() {
  const { register } = useApp();
  const [username, setUsername] = useState('');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [confirm, setConfirm] = useState('');

  function onSubmit(e) {
    e.preventDefault();
    register(username, email, password, confirm);
  }

  return (
    <section id="register" className="view active">
      <div className="auth-panel">
        <svg className="logo-large" viewBox="0 0 120 76" aria-hidden="true"><use href="#logo-nb" /></svg>
        <h1 className="auth-title">สมัครสมาชิก</h1>
        <p className="auth-subtitle">สร้างบัญชีใหม่เพื่อเริ่มต้นใช้งาน NearbyShop</p>

        <form id="register-form" noValidate onSubmit={onSubmit}>
          <div className="form-group">
            <label className="form-label">ชื่อผู้ใช้ (Username) <span className="req-star">*</span></label>
            <div className="input-wrapper">
              <svg className="svg-icon input-icon" viewBox="0 0 24 24"><path d="M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2" /><circle cx="12" cy="7" r="4" /></svg>
              <input type="text" id="reg-username" value={username} onChange={(e) => setUsername(e.target.value)} className="auth-form-input" placeholder="เช่น user123 หรือ gamer_pro (ไม่มีช่องว่าง)" maxLength="20" autoComplete="username" />
            </div>
            <div className="form-hint">ความยาว 3-20 ตัวอักษร (ภาษาอังกฤษ, ตัวเลข, _ หรือ - ห้ามเว้นวรรค)</div>
          </div>
          <div className="form-group">
            <label className="form-label">อีเมล (Email) <span className="req-star">*</span></label>
            <div className="input-wrapper">
              <svg className="svg-icon input-icon" viewBox="0 0 24 24"><path d="M4 4h16c1.1 0 2 .9 2 2v12c0 1.1-.9 2-2 2H4c-1.1 0-2-.9-2-2V6c0-1.1.9-2 2-2z" /><polyline points="22,6 12,13 2,6" /></svg>
              <input type="email" id="reg-email" value={email} onChange={(e) => setEmail(e.target.value)} className="auth-form-input" placeholder="yourname@example.com" autoComplete="email" />
            </div>
          </div>
          <div className="form-group">
            <label className="form-label">รหัสผ่าน <span className="req-star">*</span></label>
            <div className="input-wrapper">
              <svg className="svg-icon input-icon" viewBox="0 0 24 24"><rect x="3" y="11" width="18" height="11" rx="2" ry="2" /><path d="M7 11V7a5 5 0 0 1 10 0v4" /></svg>
              <input type="password" id="reg-password" value={password} onChange={(e) => setPassword(e.target.value)} className="auth-form-input" placeholder="รหัสผ่านอย่างน้อย 6 ตัวอักษร" autoComplete="new-password" />
            </div>
          </div>
          <div className="form-group">
            <label className="form-label">ยืนยันรหัสผ่าน <span className="req-star">*</span></label>
            <div className="input-wrapper">
              <svg className="svg-icon input-icon" viewBox="0 0 24 24"><rect x="3" y="11" width="18" height="11" rx="2" ry="2" /><path d="M7 11V7a5 5 0 0 1 10 0v4" /></svg>
              <input type="password" id="reg-confirm-password" value={confirm} onChange={(e) => setConfirm(e.target.value)} className="auth-form-input" placeholder="กรอกรหัสผ่านอีกครั้ง" autoComplete="new-password" />
            </div>
          </div>
          <div className="terms-text">การสร้างบัญชีถือว่าท่านยอมรับ <a href="#">เงื่อนไขการให้บริการ</a> และ <a href="#">นโยบายความเป็นส่วนตัว</a></div>
          <button type="submit" className="auth-submit-btn">สร้างบัญชีผู้ใช้
            <svg className="svg-icon" style={{ width: '18px', height: '18px' }} viewBox="0 0 24 24"><line x1="5" y1="12" x2="19" y2="12" /><polyline points="12 5 19 12 12 19" /></svg>
          </button>
        </form>

        <div className="auth-divider"></div>
        <div className="switch-page-text">มีบัญชีผู้ใช้แล้ว? <NavLink page="login">เข้าสู่ระบบ</NavLink></div>
      </div>
    </section>
  );
}
