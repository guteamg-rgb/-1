export default function Footer() {
  return (
    <footer>
    <p className="footer-text">© 2026 NearbyShop Game Top-Up. All rights reserved.</p>
    <div className="footer-links">
      <a href="#">เงื่อนไขการให้<br />บริการ</a><span className="dot"></span>
      <a href="#">นโยบายความเป็น<br />ส่วนตัว</a><span className="dot"></span>
      <a href="#">แจ้งปัญหาการใช้<br />งาน</a>
    </div>
  </footer>
  );
}
