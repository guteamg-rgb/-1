'use client';

import { useApp } from '@/context/AppContext';
import NavLink from '@/components/NavLink';
import Icon from '@/components/Icon';

export default function Header() {
  const { ready, currentUser, openDrawer, navigate } = useApp();

  return (
    <header>
      <div className="header-container">
        <button id="open-drawer" className="menu-btn" type="button" aria-label="เปิดเมนู" onClick={openDrawer}>
          <svg className="svg-icon" viewBox="0 0 24 24"><line x1="3" y1="12" x2="21" y2="12" /><line x1="3" y1="6" x2="21" y2="6" /><line x1="3" y1="18" x2="21" y2="18" /></svg>
        </button>

        <NavLink page="home" className="logo-container">
          <svg className="svg-logo" viewBox="0 0 120 76" aria-hidden="true"><use href="#logo-nb" /></svg>
          <span className="logo-text">NEARBY<span>SHOP</span></span>
        </NavLink>

        <div id="header-auth-area">
          {ready && (currentUser ? (
            <div className="header-actions">
              <button type="button" className="header-history-btn" aria-label="ประวัติรายการ" title="ประวัติรายการ" onClick={() => navigate('history')}>
                <Icon name="receipt" />
              </button>
              <button type="button" className="balance-btn" onClick={() => navigate('topup')}>
                <span className="bal">฿0</span><span className="add">+ เติม</span>
              </button>
            </div>
          ) : (
            <button className="login-btn-header" onClick={() => navigate('login')}>เข้าสู่ระบบ</button>
          ))}
        </div>
      </div>
    </header>
  );
}
