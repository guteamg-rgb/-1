'use client';

import { useState } from 'react';
import Swal from 'sweetalert2';
import { useApp } from '@/context/AppContext';
import { supabase } from '@/lib/supabase';

export default function RedeemView() {
  const { currentUser, navigate } = useApp();
  const [code, setCode] = useState('');

  async function checkRedeemCode() {
    if (!currentUser) {
      Swal.fire({ title: 'กรุณาเข้าสู่ระบบ', text: 'ต้องเข้าสู่ระบบก่อนแลกโค้ดของรางวัล', icon: 'warning', confirmButtonText: 'เข้าสู่ระบบ' }).then(() => navigate('login'));
      return;
    }
    const c = code.trim();
    if (!c) { Swal.fire({ title: 'กรุณากรอกโค้ด', text: 'โปรดระบุรหัสโค้ดที่ต้องการแลก', icon: 'warning', confirmButtonText: 'ตกลง' }); return; }
    if (c.length < 6) { Swal.fire({ title: 'โค้ดไม่ถูกต้อง', text: 'โค้ดต้องมีความยาวอย่างน้อย 6 ตัวอักษร', icon: 'error', confirmButtonText: 'ลองใหม่' }); return; }
    if (!supabase) { Swal.fire({ title: 'ยังไม่ได้ตั้งค่าระบบ', text: 'กรุณาตั้งค่า Supabase ก่อนใช้งาน', icon: 'error', confirmButtonText: 'ตกลง' }); return; }
    const { data, error } = await supabase.rpc('redeem_code', { p_code: c });
    if (error) { Swal.fire({ title: 'แลกโค้ดไม่สำเร็จ', text: error.message || 'โค้ดไม่ถูกต้องหรือถูกใช้งานแล้ว', icon: 'error', confirmButtonText: 'ลองใหม่' }); return; }
    Swal.fire({ title: 'แลกโค้ดสำเร็จ', text: `คุณได้รับ ${data.reward}`, icon: 'success', confirmButtonText: 'ตกลง' });
    setCode('');
  }

  return (
    <section id="redeem" className="view active page">
      <div style={{ background: 'linear-gradient(180deg,#17142d,#11141e)', padding: '28px 18px', textAlign: 'center', marginBottom: '16px', border: '1px solid #312a5c', borderRadius: '24px' }}>
        <div style={{ width: '60px', height: '60px', borderRadius: '16px', background: '#23204a', border: '1px solid #3e377c', display: 'flex', alignItems: 'center', justifyContent: 'center', margin: '0 auto 14px' }}>
          <svg className="svg-icon" style={{ color: '#a99eff', width: '30px', height: '30px' }} viewBox="0 0 24 24"><polyline points="20 12 20 22 4 22 4 12" /><rect x="2" y="7" width="20" height="5" /><line x1="12" y1="22" x2="12" y2="7" /><path d="M12 7H7.5a2.5 2.5 0 0 1 0-5C11 2 12 7 12 7z" /><path d="M12 7h4.5a2.5 2.5 0 0 0 0-5C13 2 12 7 12 7z" /></svg>
        </div>
        <h1 style={{ fontSize: '24px', margin: '0 0 10px', lineHeight: '1.3' }}>ศูนย์แลกโค้ดของรางวัล<br /><span className="grad-text">Redeem Center</span></h1>
        <p className="muted" style={{ fontSize: '13.5px', margin: '0', lineHeight: '1.6' }}>กรอกรหัสโค้ดโปรโมชั่น กิจกรรม หรือโค้ดชดเชยเพื่อรับแพ็กเกจเกมฟรี หรือเติมเงินเข้ากระเป๋าเงินอัตโนมัติทันที</p>
      </div>

      <div className="panel" style={{ padding: '20px 16px', marginBottom: '14px', borderRadius: '20px' }}>
        <label style={{ display: 'block', fontSize: '14px', fontWeight: '600', marginBottom: '12px' }}>ระบุรหัสโค้ดของรางวัล (REDEEM CODE)</label>
        <div style={{ position: 'relative', marginBottom: '14px' }}>
          <svg className="svg-icon" style={{ position: 'absolute', left: '14px', top: '14px', color: '#8b93a8' }} viewBox="0 0 24 24"><path d="M20.59 13.41l-7.17 7.17a2 2 0 0 1-2.83 0L2 12V2h10l8.59 8.59a2 2 0 0 1 0 2.82z" /><line x1="7" y1="7" x2="7.01" y2="7" /></svg>
          <input id="redeem-input" value={code} onChange={(e) => setCode(e.target.value)} type="text" className="field" placeholder="เช่น ROV-FREE-2026 หรือ..." style={{ padding: '12px 12px 12px 42px', letterSpacing: '.5px', background: '#151820', borderRadius: '14px' }} maxLength="40" autoComplete="off" />
        </div>
        <button id="redeem-btn" onClick={checkRedeemCode} className={'primary' + (!currentUser || !code.trim() ? ' btn-dim' : '')} style={{ width: '100%', padding: '12px', fontSize: '14px', borderRadius: '14px', display: 'flex', justifyContent: 'center', alignItems: 'center', gap: '8px' }}>
          <svg className="svg-icon" viewBox="0 0 24 24"><path d="M12 3l1.9 5.1L19 10l-5.1 1.9L12 17l-1.9-5.1L5 10l5.1-1.9z" /></svg>
          ตรวจสอบโค้ด
        </button>
      </div>

      <div className="panel" style={{ padding: '16px', marginBottom: '12px', borderRadius: '20px' }}>
        <h3 style={{ fontSize: '14.5px', margin: '0 0 8px', display: 'flex', alignItems: 'center', gap: '8px' }}>
          <svg className="svg-icon" style={{ color: '#a99eff' }} viewBox="0 0 24 24"><polyline points="20 12 20 22 4 22 4 12" /><rect x="2" y="7" width="20" height="5" /><line x1="12" y1="22" x2="12" y2="7" /><path d="M12 7H7.5a2.5 2.5 0 0 1 0-5C11 2 12 7 12 7z" /><path d="M12 7h4.5a2.5 2.5 0 0 0 0-5C13 2 12 7 12 7z" /></svg>
          รับโค้ดของรางวัลได้จากที่ไหน?
        </h3>
        <p className="muted" style={{ fontSize: '13px', margin: '0', lineHeight: '1.5' }}>ติดตามกิจกรรมแจกโค้ดพิเศษได้ทางเพจ Facebook, Discord Community และกิจกรรมสตรีมเมอร์พาร์ทเนอร์ของ NearbyShop</p>
      </div>

      <div className="panel" style={{ padding: '16px', borderRadius: '20px' }}>
        <h3 style={{ fontSize: '14.5px', margin: '0 0 8px', display: 'flex', alignItems: 'center', gap: '8px' }}>
          <svg className="svg-icon" style={{ color: '#10b981' }} viewBox="0 0 24 24"><path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z" /><polyline points="9 12 11 14 15 10" /></svg>
          โค้ดชดเชยจากทีมงาน
        </h3>
        <p className="muted" style={{ fontSize: '13px', margin: '0', lineHeight: '1.5' }}>กรณีเกิดข้อผิดพลาดในการสั่งซื้อหรือได้รับโค้ดชดเชยจากทีมงาน สามารถนำมากรอกที่หน้านี้เพื่อรับเครดิตหรือไอเทมคืนได้ทันที</p>
      </div>
    </section>
  );
}
