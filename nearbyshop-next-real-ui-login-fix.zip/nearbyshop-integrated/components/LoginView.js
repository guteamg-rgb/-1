'use client';

import { useState } from 'react';
import Swal from 'sweetalert2';
import { useApp } from '@/context/AppContext';
import NavLink from '@/components/NavLink';

export default function LoginView() {
  const { login } = useApp();
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');

  function onSubmit(e) {
    e.preventDefault();
    login(username, password);
  }

  return (
    <section id="login" className="view active">
      <div className="auth-panel">
        <svg className="logo-large" viewBox="0 0 120 76" aria-hidden="true"><use href="#logo-nb" /></svg>
        <h1 className="auth-title">เข้าสู่ระบบ</h1>
        <p className="auth-subtitle">เข้าสู่ระบบ NearbyShop เพื่อใช้งานบัญชีและตรวจสอบรายการของคุณ</p>

        <form id="login-form" noValidate onSubmit={onSubmit}>
          <div className="form-group">
            <label className="form-label">ชื่อผู้ใช้ หรือ อีเมล</label>
            <div className="input-wrapper">
              <svg className="svg-icon input-icon" viewBox="0 0 24 24"><path d="M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2" /><circle cx="12" cy="7" r="4" /></svg>
              <input type="text" id="login-username" value={username} onChange={(e) => setUsername(e.target.value)} className="auth-form-input" placeholder="กรอกชื่อผู้ใช้หรืออีเมล" autoComplete="username" />
            </div>
          </div>
          <div className="form-group">
            <div className="form-label"><span>รหัสผ่าน</span><a href="#" onClick={(event) => { event.preventDefault(); Swal.fire({title:'ลืมรหัสผ่าน',text:'กรุณาติดต่อทีมงานเพื่อรีเซ็ตรหัสผ่าน',icon:'info',confirmButtonText:'ตกลง'}); }}>ลืมรหัสผ่าน?</a></div>
            <div className="input-wrapper">
              <svg className="svg-icon input-icon" viewBox="0 0 24 24"><rect x="3" y="11" width="18" height="11" rx="2" ry="2" /><path d="M7 11V7a5 5 0 0 1 10 0v4" /></svg>
              <input type="password" id="login-password" value={password} onChange={(e) => setPassword(e.target.value)} className="auth-form-input" placeholder="กรอกรหัสผ่าน" autoComplete="current-password" />
            </div>
          </div>
          <button type="submit" className="auth-submit-btn">เข้าสู่ระบบ
            <svg className="svg-icon" style={{ width: '18px', height: '18px' }} viewBox="0 0 24 24"><line x1="5" y1="12" x2="19" y2="12" /><polyline points="12 5 19 12 12 19" /></svg>
          </button>
        </form>

        <div className="auth-divider"></div>
        <div className="switch-page-text">ยังไม่มีบัญชีผู้ใช้? <NavLink page="register">สมัครสมาชิก</NavLink></div>
      </div>
    </section>
  );
}
