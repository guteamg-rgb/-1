'use client';

import { useEffect } from 'react';
import { usePathname, useSearchParams } from 'next/navigation';
import { useApp } from '@/context/AppContext';

// ปิดหน้า loader เมื่อเปลี่ยนหน้าเสร็จ (แทน event 'pageshow' ของเว็บเดิม)
export default function RouteWatcher() {
  const pathname = usePathname();
  const search = useSearchParams().toString();
  const { setLoading } = useApp();

  useEffect(() => {
    setLoading(false);
  }, [pathname, search, setLoading]);

  return null;
}
