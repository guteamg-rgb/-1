'use client';
import { useEffect, useMemo, useState } from 'react';
import GameCard from '@/components/GameCard';
import { games, CAT_ONLINE, CAT_CARD } from '@/lib/games';
import { supabase } from '@/lib/supabase';
export default function CategoriesView({ initialCat }) {
  const [catalog, setCatalog] = useState(games); const [filter, setFilter] = useState([CAT_ONLINE, CAT_CARD].includes(initialCat) ? initialCat : 'ทั้งหมด'); const [query, setQuery] = useState('');
  useEffect(() => { if (supabase) supabase.from('games').select('*,game_packages(*)').eq('active', true).order('id').then(({ data }) => { if (data?.length) setCatalog(data.map(g => ({ ...g, cat: g.category, sub: g.subtext, img: g.cover_url }))); }); }, []);
  const counts = { all: catalog.length, online: catalog.filter(g => (g.cat || g.category) === CAT_ONLINE).length, card: catalog.filter(g => (g.cat || g.category) === CAT_CARD).length };
  const q = query.trim().toLocaleLowerCase(); const matches = catalog.filter(g => (filter === 'ทั้งหมด' || (g.cat || g.category) === filter) && g.name.toLocaleLowerCase().includes(q));
  return <section id="categories" className="view active page">
    <h1 style={{ fontSize: '24px', margin: '0 0 6px' }}>หมวดหมู่เกมทั้งหมด</h1>
    <p className="muted" style={{ fontSize: '13.5px', margin: '0 0 16px' }}>ค้นหาและเลือกดูบริการเติมเกมที่ต้องการ (<span className="c-all">{counts.all}</span> รายการ)</p>
    <div style={{ position: 'relative', marginBottom: '16px' }}><svg className="svg-icon" style={{ position: 'absolute', left: '14px', top: '14px', color: '#6b7280', width: '20px', height: '20px' }} viewBox="0 0 24 24"><circle cx="11" cy="11" r="8" /><line x1="21" y1="21" x2="16.65" y2="16.65" /></svg><input id="game-search" className="field" type="search" placeholder="ค้นหาเกม, บัตรเติมเงิน..." style={{ padding: '13px 14px 13px 44px', borderRadius: '16px', background: '#151820', borderColor: '#252a38' }} value={query} onChange={(e) => setQuery(e.target.value)} /></div>
    <div className="filter-pills" role="group" aria-label="กรองหมวดหมู่">
      {[['ทั้งหมด','c-all',counts.all], [CAT_ONLINE,'c-online',counts.online], [CAT_CARD,'c-card',counts.card]].map(([value, cls, count]) => <button key={value} type="button" className={'pill' + (filter === value ? ' selected' : '')} onClick={() => setFilter(value)}>{value} (<span className={cls}>{count}</span>)</button>)}
    </div>
    <div id="category-games-list" className="game-grid" style={{ marginTop: '18px' }}>{matches.map((g) => <GameCard key={g.id || g.name} game={g} />)}</div>
    <p id="game-empty" className={'muted text-center' + (matches.length > 0 ? ' hidden' : '')} style={{ padding: '28px 0', fontSize: '14px' }}>ไม่พบบริการที่ตรงกับการค้นหา</p>
  </section>;
}
