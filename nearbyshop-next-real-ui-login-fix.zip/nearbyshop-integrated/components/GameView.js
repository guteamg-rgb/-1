'use client';

import { useState } from 'react';
import Swal from 'sweetalert2';
import { useApp } from '@/context/AppContext';
import Icon from '@/components/Icon';
import { TagIcon } from '@/components/GameCard';
import { coverFor, fmtBaht, packsFor } from '@/lib/games';
import { supabase } from '@/lib/supabase';

export default function GameView({ game }) {
  const { currentUser, navigate } = useApp();
  const packs = game.packs?.length ? game.packs : (game.game_packages?.map((x) => [x.name, Number(x.price), x.id]) || packsFor(game));
  const fallback = coverFor(game);

  const [imgSrc, setImgSrc] = useState(game.img || fallback);
  const [pack, setPack] = useState(0);
  const [uid, setUid] = useState('');

  const uidLbl = 'Player ID (UID ' + game.name + ')';
  const p = packs[pack];
  const uidTrim = uid.trim();

  function payGame() {
    if (!currentUser) { navigate('login'); return; }
    if (uidTrim.length < 5) {
      Swal.fire({ title: 'กรุณากรอก Player ID', text: 'ระบุ UID ของเกมให้ถูกต้องก่อนชำระเงิน', icon: 'warning', confirmButtonText: 'ตกลง' });
      return;
    }
    if (!supabase || !game.id || !p[2]) return Swal.fire({ title: 'ไม่สามารถสร้างคำสั่งซื้อ', text: 'เกมหรือแพ็กเกจนี้ยังไม่ได้ตั้งค่าในฐานข้อมูล', icon: 'error', confirmButtonText: 'ตกลง' });
    supabase.rpc('purchase_game', { p_game_id: game.id, p_package_id: p[2], p_player_uid: uidTrim }).then(({ data, error }) => {
      if (error) return Swal.fire({ title: 'สั่งซื้อไม่สำเร็จ', text: error.message, icon: 'error', confirmButtonText: 'ตกลง' });
      Swal.fire({ title: 'สร้างคำสั่งซื้อแล้ว', text: `เลขที่คำสั่งซื้อ ${data.id}`, icon: 'success', confirmButtonText: 'ดูประวัติ' }).then(() => navigate('history'));
    });
  }

  return (
    <section id="game" className="view active page">
      <button type="button" className="back-link" onClick={() => navigate('categories')}>
        <svg className="svg-icon" viewBox="0 0 24 24"><path d="M19 12H5" /><path d="m12 19-7-7 7-7" /></svg>ย้อนกลับไปหน้าหมวดหมู่
      </button>

      <div className="gp-panel"><div className="gp-hero">
        <div className="gp-cover">
          {/* eslint-disable-next-line @next/next/no-img-element */}
          <img id="gp-img" src={imgSrc} alt={game.name} onError={() => { if (imgSrc !== fallback) setImgSrc(fallback); }} />
        </div>
        <div>
          <div className="gp-name">
            <span id="gp-name">{game.name}</span>
            <span id="gp-chip">
              {game.tag && (
                <span className="gp-chip">{game.icon === 'bolt' && <TagIcon name="bolt" />}{game.tag}</span>
              )}
            </span>
          </div>
          <div className="gp-sub" id="gp-sub">{'เติม ' + game.name + ' อัตโนมัติ ปลอดภัย รวดเร็ว'}</div>
        </div>
      </div></div>

      <div className="gp-panel">
        <div className="gp-h"><span className="gp-num">1</span>ข้อมูลผู้เล่น / ข้อมูลการรับสินค้า</div>
        <div className="gp-label" id="gp-uid-label">{uidLbl} <b>*</b></div>
        <input
          id="gp-uid"
          className="field gp-input"
          type="text"
          inputMode="numeric"
          autoComplete="off"
          maxLength={30}
          placeholder={'กรอก ' + uidLbl}
          value={uid}
          onChange={(e) => setUid(e.target.value)}
        />
      </div>

      <div className="gp-panel">
        <div className="gp-h"><span className="gp-num">2</span><span id="gp-pack-title">{'เลือกแพ็กเกจ (' + packs.length + ' รายการ)'}</span></div>
        <div id="gp-packs">
          {packs.map((pk, i) => (
            <button key={i} type="button" className={'pack' + (i === pack ? ' selected' : '')} onClick={() => setPack(i)}>
              <div className="pack-name">{pk[0]}</div>
              <div className="pack-price">{fmtBaht(pk[1])}</div>
            </button>
          ))}
        </div>
      </div>

      <div className="gp-panel">
        <div className="gp-h" style={{ marginBottom: '14px' }}>3. ชำระเงิน</div>
        <div className="pay-bal"><span><Icon name="wallet" />เครดิตคงเหลือ</span><b>฿0</b></div>
        <div className="pay-row"><span>รายการ:</span><b id="pay-item">{p[0]}</b></div>
        <div className="pay-row"><span id="pay-uid-label">{uidLbl + ':'}</span><b id="pay-uid">{uidTrim || '-'}</b></div>
        <div className="pay-total"><span>ยอดชำระ</span><b id="pay-total">{fmtBaht(p[1])}</b></div>
        <button type="button" id="pay-btn" className="primary pay-btn" onClick={payGame}>{'ชำระเงินด้วยเครดิต ' + fmtBaht(p[1])}</button>
        <div className="pay-safe"><svg className="svg-icon" viewBox="0 0 24 24"><path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z" /><polyline points="9 12 11 14 15 10" /></svg>ชำระเงินผ่านระบบความปลอดภัยสูง 24 ชม.</div>
      </div>
    </section>
  );
}
