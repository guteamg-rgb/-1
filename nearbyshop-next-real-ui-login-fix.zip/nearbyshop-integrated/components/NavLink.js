'use client';

import Link from 'next/link';
import { useApp } from '@/context/AppContext';
import { pathOf } from '@/lib/nav';

// ลิงก์ภายในเว็บ: ใช้ <Link> ของ Next.js แต่ผ่าน navigate() เดิม
// (ปิดเมนูข้าง / แสดง loader / จำหน้าก่อนล็อกอิน)
export default function NavLink({ page, query = '', ...props }) {
  const { navigate } = useApp();
  return (
    <Link
      href={pathOf(page) + query}
      onClick={(e) => {
        if (e.metaKey || e.ctrlKey || e.shiftKey || e.altKey || e.button !== 0) return;
        e.preventDefault();
        navigate(page, query);
      }}
      {...props}
    />
  );
}
