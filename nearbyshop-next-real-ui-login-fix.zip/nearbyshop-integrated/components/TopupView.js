'use client';

import { Fragment, useRef, useState } from 'react';
import Swal from 'sweetalert2';
import { useApp } from '@/context/AppContext';
import NavLink from '@/components/NavLink';
import { copyToClipboard } from '@/lib/utils';
import { supabase } from '@/lib/supabase';

const METHODS = {
  truemoney: { label: 'TrueMoney Wallet', fee: '2.9% (สูงสุด ฿20)', feeColor: '#f59e0b' },
  bank: { label: 'โอนผ่านธนาคาร', fee: 'ฟรี (0%)', feeColor: '#10b981' },
  voucher: { label: 'โค้ดของขวัญ / Voucher', fee: 'ฟรี (0%)', feeColor: '#10b981' },
};

export default function TopupView() {
  const { ready, currentUser, navigate } = useApp();
  const [method, setMethod] = useState('truemoney');
  const [formKey, setFormKey] = useState(0); // เปลี่ยนค่าเพื่อรีเซ็ตฟอร์ม (เหมือน innerHTML ใหม่ทุกครั้งที่เลือกช่องทาง)
  const [tmLink, setTmLink] = useState('');
  const [voucherCode, setVoucherCode] = useState('');
  const [amount, setAmount] = useState('');
  const [slipFile, setSlipFile] = useState(null);
  const slipInputRef = useRef(null);

  const M = METHODS[method];

  function selectMethod(m) {
    setMethod(m);
    setSlipFile(null);
    setTmLink('');
    setVoucherCode('');
    setFormKey((k) => k + 1);
  }

  function onSlipPicked(e) {
    const input = e.target;
    const f = input.files && input.files[0];
    if (!f) return;
    if (!/^image\/(png|jpeg)$/.test(f.type)) {
      input.value = ''; setSlipFile(null);
      Swal.fire({ title: 'ไฟล์ไม่รองรับ', text: 'กรุณาเลือกไฟล์ JPG หรือ PNG', icon: 'error', confirmButtonText: 'ตกลง' });
      return;
    }
    if (f.size > 5 * 1024 * 1024) {
      input.value = ''; setSlipFile(null);
      Swal.fire({ title: 'ไฟล์ใหญ่เกินไป', text: 'ขนาดไฟล์ต้องไม่เกิน 5 MB', icon: 'error', confirmButtonText: 'ตกลง' });
      return;
    }
    setSlipFile(f);
  }

  async function confirmTopup() {
    if (!currentUser) { navigate('login'); return; }
    if (method === 'truemoney') {
      if (!tmLink.trim().startsWith('https://gift.truemoney.com/')) {
        Swal.fire({ title: 'ลิงก์ไม่ถูกต้อง', text: 'กรุณาวางลิงก์ซองของขวัญ TrueMoney (https://gift.truemoney.com/...)', icon: 'warning', confirmButtonText: 'ตกลง' }); return;
      }
    } else if (method === 'bank') {
      if (!slipFile) { Swal.fire({ title: 'ยังไม่ได้แนบสลิป', text: 'กรุณาแนบรูปสลิปการโอนเงิน', icon: 'warning', confirmButtonText: 'ตกลง' }); return; }
    } else if (method === 'voucher') {
      if (voucherCode.trim().length < 4) { Swal.fire({ title: 'กรุณากรอกโค้ด', text: 'โปรดระบุรหัสโค้ดเติมเงินให้ถูกต้อง', icon: 'warning', confirmButtonText: 'ตกลง' }); return; }
    } else {
      Swal.fire({ title: 'เลือกช่องทางชำระเงิน', text: 'กรุณาเลือกช่องทางก่อนทำรายการ', icon: 'warning', confirmButtonText: 'ตกลง' }); return;
    }
    const value = Number(amount);
    if (!(value > 0)) { Swal.fire({ title: 'กรุณาระบุยอดเติมเงิน', text: 'ยอดเติมเงินต้องมากกว่า 0', icon: 'warning', confirmButtonText: 'ตกลง' }); return; }
    const r = await Swal.fire({ title: 'ยืนยันการเติมเงิน?', text: 'ระบบจะสร้างรายการรอตรวจสอบในฐานข้อมูลจริง', icon: 'question', showCancelButton: true, confirmButtonText: 'ยืนยัน', cancelButtonText: 'ยกเลิก' });
    if (!r.isConfirmed || !supabase) return;
    const { error } = await supabase.from('topups').insert({ id: 'TXN-' + crypto.randomUUID().slice(0, 12).toUpperCase(), user_id: currentUser.id, username_snapshot: currentUser.username, method: M.label, amount: value, fee: 0, status: 'pending', note: method === 'truemoney' ? tmLink.trim() : (slipFile ? slipFile.name : voucherCode.trim()) });
    if (error) Swal.fire({ title: 'สร้างรายการไม่สำเร็จ', text: error.message, icon: 'error', confirmButtonText: 'ตกลง' });
    else { setAmount(''); Swal.fire({ title: 'รับรายการแล้ว', text: 'รายการถูกส่งเข้าสู่ขั้นตอนตรวจสอบ กรุณาติดตามสถานะจากประวัติรายการ', icon: 'success', confirmButtonText: 'ตกลง' }); }
  }

  return (
    <section id="topup" className="view active page">

      <div className="topup-card">
        <div className="flex justify-between items-center" style={{ marginBottom: '8px' }}>
          <h1 style={{ fontSize: '20px', margin: '0', display: 'flex', alignItems: 'center', gap: '8px', flexWrap: 'wrap' }}>เติมเครดิต
            <span style={{ background: 'rgba(16,185,129,.15)', color: '#10b981', fontSize: '11px', fontWeight: '600', padding: '3px 8px', borderRadius: '8px', display: 'inline-flex', alignItems: 'center', gap: '3px' }}>
              <svg className="svg-icon" style={{ width: '12px', height: '12px' }} viewBox="0 0 24 24"><polygon points="13 2 3 14 12 14 11 22 21 10 12 10 13 2" /></svg>อัตโนมัติ 24 ชม.</span>
          </h1>
        </div>
        <p className="muted" style={{ fontSize: '13px', margin: '0 0 14px', lineHeight: '1.5' }}>เลือกช่องทางชำระเงิน ระบบจะตรวจสอบและเพิ่มยอดเครดิตให้อัตโนมัติตามยอดจริง</p>

        
        <div id="topup-balance-card" style={{ display: ready && currentUser ? 'flex' : 'none', background: '#11141e', border: '1px solid #252a38', borderRadius: '10px', padding: '12px', alignItems: 'center' }}>
          <div style={{ flex: '1', borderRight: '1px solid #252a38', paddingRight: '10px' }}>
            <div className="muted" style={{ fontSize: '11px', marginBottom: '4px' }}>ยอดเครดิตปัจจุบัน (<span id="topup-username">{currentUser ? currentUser.username : '-'}</span>)</div>
            <div style={{ fontSize: '20px', fontWeight: '700', color: '#10b981' }}>฿0</div>
          </div>
          <div style={{ flex: '1', paddingLeft: '12px' }}>
            <div className="muted" style={{ fontSize: '11px', marginBottom: '4px' }}>คะแนนสะสม</div>
            <div style={{ fontSize: '20px', fontWeight: '700', color: '#f59e0b', display: 'flex', alignItems: 'center', gap: '6px' }}><svg className="svg-icon" style={{ width: '18px', height: '18px' }} viewBox="0 0 24 24" aria-hidden="true"><use href="#i-sparkles" /></svg>0 pts</div>
          </div>
        </div>

        <button id="topup-login-btn" type="button" className="primary" style={{ width: '100%', padding: '12px', fontSize: '14px', display: ready && !currentUser ? 'flex' : 'none', justifyContent: 'center', alignItems: 'center', gap: '8px' }} onClick={() => navigate('login')}>
          <svg className="svg-icon" viewBox="0 0 24 24"><path d="M15 3h4a2 2 0 0 1 2 2v14a2 2 0 0 1-2 2h-4" /><polyline points="10 17 15 12 10 7" /><line x1="15" y1="12" x2="3" y2="12" /></svg>
          เข้าสู่ระบบเพื่อเติมเงิน
        </button>
      </div>

      <div className="topup-card">
        <h2 style={{ fontSize: '16px', margin: '0 0 14px' }}>1. เลือกช่องทางชำระเงิน</h2>

        <div className={'method-card' + (method === 'truemoney' ? ' active' : '')} id="method-truemoney" onClick={() => selectMethod('truemoney')}>
          <div className="method-icon" style={{ background: 'rgba(217,119,6,.15)', color: '#f59e0b' }}>
            <svg className="svg-icon" viewBox="0 0 24 24"><polyline points="20 12 20 22 4 22 4 12" /><rect x="2" y="7" width="20" height="5" /><line x1="12" y1="22" x2="12" y2="7" /><path d="M12 7H7.5a2.5 2.5 0 0 1 0-5C11 2 12 7 12 7z" /><path d="M12 7h4.5a2.5 2.5 0 0 0 0-5C13 2 12 7 12 7z" /></svg>
          </div>
          <h3 style={{ fontSize: '15px', margin: '0 0 4px', color: '#fff' }}>TrueMoney Wallet</h3>
          <p className="muted" style={{ fontSize: '12px', margin: '0 0 8px' }}>ซองของขวัญอัตโนมัติ</p>
          <span style={{ background: 'rgba(217,119,6,.15)', color: '#f59e0b', fontSize: '11.5px', fontWeight: '600', padding: '3px 10px', borderRadius: '8px', border: '1px solid rgba(217,119,6,.35)' }}>ค่าธรรมเนียม 2.9% (สูงสุด ฿20)</span>
        </div>

        <div className={'method-card' + (method === 'bank' ? ' active-bank' : '')} id="method-bank" onClick={() => selectMethod('bank')}>
          <div className="method-icon" style={{ background: 'rgba(79,70,229,.18)', color: '#818cf8' }}>
            <svg className="svg-icon" viewBox="0 0 24 24"><line x1="3" y1="22" x2="21" y2="22" /><line x1="6" y1="18" x2="6" y2="11" /><line x1="10" y1="18" x2="10" y2="11" /><line x1="14" y1="18" x2="14" y2="11" /><line x1="18" y1="18" x2="18" y2="11" /><polygon points="12 2 20 7 4 7" /></svg>
          </div>
          <h3 style={{ fontSize: '15px', margin: '0 0 4px', color: '#fff' }}>โอนผ่านธนาคาร</h3>
          <p className="muted" style={{ fontSize: '12px', margin: '0 0 8px' }}>แนบสลิป (ตรวจสอบอัตโนมัติ)</p>
          <span style={{ background: 'rgba(16,185,129,.15)', color: '#10b981', fontSize: '11.5px', fontWeight: '600', padding: '3px 10px', borderRadius: '8px', border: '1px solid rgba(16,185,129,.3)' }}>ฟรีค่าธรรมเนียม</span>
        </div>

        <div className={'method-card' + (method === 'voucher' ? ' active-voucher' : '')} id="method-voucher" onClick={() => selectMethod('voucher')}>
          <div className="method-icon" style={{ background: 'rgba(16,185,129,.15)', color: '#10b981' }}>
            <svg className="svg-icon" viewBox="0 0 24 24"><path d="M20.59 13.41l-7.17 7.17a2 2 0 0 1-2.83 0L2 12V2h10l8.59 8.59a2 2 0 0 1 0 2.82z" /><line x1="7" y1="7" x2="7.01" y2="7" /></svg>
          </div>
          <h3 style={{ fontSize: '15px', margin: '0 0 4px', color: '#fff' }}>โค้ดของขวัญ / Voucher</h3>
          <p className="muted" style={{ fontSize: '12px', margin: '0 0 8px' }}>เติมเงินด้วยรหัสโค้ด</p>
          <span style={{ background: 'rgba(16,185,129,.15)', color: '#10b981', fontSize: '11.5px', fontWeight: '600', padding: '3px 10px', borderRadius: '8px', border: '1px solid rgba(16,185,129,.3)' }}>ฟรีไม่มีค่าธรรมเนียม</span>
        </div>

        <div className="form-box" id="topup-form-container">
          <Fragment key={formKey}>
            {method === 'truemoney' && (
              <>
        <h3 style={{ fontSize: '15px', margin: '0 0 12px', color: '#f59e0b', display: 'flex', alignItems: 'center', gap: '8px' }}>
                <svg className="svg-icon" viewBox="0 0 24 24"><rect x="5" y="2" width="14" height="20" rx="2" ry="2" /><line x1="12" y1="18" x2="12.01" y2="18" /></svg>
                วิธีการสร้างซองของขวัญ TrueMoney Wallet
              </h3>
              <ol className="steps" style={{ fontSize: '12.5px', color: '#c3c9da', margin: '0 0 14px', lineHeight: '1.7' }}>
                <li>เปิดแอป TrueMoney Wallet เลือกเมนู &quot;ส่งของขวัญ&quot;</li>
                <li>กรอกจำนวนเงินที่ต้องการเติม <strong style={{ color: '#fff' }}>(ไม่มีขั้นต่ำ)</strong></li>
                <li>เลือกประเภทการส่งเป็น <strong style={{ color: '#fff' }}>&quot;แบ่งจำนวนเงินเท่ากัน&quot;</strong> และใส่จำนวนผู้รับ 1 คน</li>
                <li>กดยืนยันสร้างซอง แล้วคัดลอกลิงก์มาวางในช่องด้านล่างนี้</li>
              </ol>
              <label style={{ display: 'block', fontSize: '13px', fontWeight: '600', marginBottom: '8px' }}>ลิงก์ซองของขวัญ TrueMoney <span style={{ color: '#ef4444' }}>*</span></label>
              <input id="tm-link" value={tmLink} onChange={(e) => setTmLink(e.target.value)} type="text" className="field" placeholder="https://gift.truemoney.com/campaign/..." style={{ background: '#090d17', marginBottom: '8px', fontFamily: 'ui-monospace,Menlo,Consolas,monospace', fontSize: '12.5px' }} autoComplete="off" />
              <p className="muted" style={{ fontSize: '11.5px', margin: '0', lineHeight: '1.5' }}>* ระบบจะดึงยอดเงินจากซองของขวัญและเติมเข้ากระเป๋าเงินให้อัตโนมัติทันที</p>
              </>
            )}
            {method === 'bank' && (
              <>
        <div style={{ border: '1px solid #252a38', borderRadius: '12px', padding: '14px', marginBottom: '16px', background: '#0d111a', display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', gap: '10px' }}>
                <div style={{ minWidth: '0' }}>
                  <div style={{ fontSize: '12px', color: '#8b93a8', marginBottom: '4px' }}>ธนาคารกสิกรไทย</div>
                  <div style={{ fontSize: '19px', fontWeight: '700', color: '#fff', letterSpacing: '1px', fontFamily: 'ui-monospace,Menlo,Consolas,monospace' }}>214-8-29425-1</div>
                  <div style={{ fontSize: '12px', color: '#8b93a8', marginTop: '6px', lineHeight: '1.4' }}>ชื่อบัญชี: นาย ปุณญพัฒน์ เครือบุญ / Mr. Poonyapat Kruaboon</div>
                </div>
                <button type="button" onClick={() => { copyToClipboard('2148294251') }} style={{ flexShrink: '0', background: '#1c1e2a', border: '1px solid #303646', color: '#fff', fontSize: '11px', padding: '8px 10px', borderRadius: '10px', display: 'flex', flexDirection: 'column', alignItems: 'center', gap: '4px', cursor: 'pointer', lineHeight: '1.2' }}>
                  <svg className="svg-icon" viewBox="0 0 24 24"><rect x="9" y="9" width="13" height="13" rx="2" ry="2" /><path d="M5 15H4a2 2 0 0 1-2-2V4a2 2 0 0 1 2-2h9a2 2 0 0 1 2 2v1" /></svg>คัดลอก<br />เลขบัญชี
                </button>
              </div>
              <label style={{ display: 'block', fontSize: '13px', fontWeight: '600', marginBottom: '8px' }}>แนบรูปภาพสลิปการโอนเงิน <span style={{ color: '#ef4444' }}>*</span></label>
              <input id="slip-file" ref={slipInputRef} type="file" accept="image/png,image/jpeg" hidden onChange={onSlipPicked} />
              <div onClick={() => slipInputRef.current && slipInputRef.current.click()} style={{ border: '1px dashed #303646', borderRadius: '12px', padding: '30px 16px', textAlign: 'center', background: '#0d111a', cursor: 'pointer' }}>
                <svg className="svg-icon" style={{ color: '#8b93a8', width: '34px', height: '34px', margin: '0 auto 8px', display: 'block' }} viewBox="0 0 24 24"><polyline points="16 16 12 12 8 16" /><line x1="12" y1="12" x2="12" y2="21" /><path d="M20.39 18.39A5 5 0 0 0 18 9h-1.26A8 8 0 1 0 3 16.3" /></svg>
                <div id="slip-name" style={{ fontSize: '14px', fontWeight: '600', color: '#e5e7f1', marginBottom: '4px' }}>{slipFile ? '✔ ' + slipFile.name : 'คลิกเพื่ออัปโหลดสลิปโอนเงิน'}</div>
                <div style={{ fontSize: '12px', color: '#8b93a8' }}>รองรับไฟล์ JPG, PNG (ระบบจะอ่านและตรวจสอบยอดเงินอัตโนมัติ)</div>
              </div>
              </>
            )}
            {method === 'voucher' && (
              <>
        <label style={{ display: 'block', fontSize: '13px', fontWeight: '600', marginBottom: '8px' }}>ระบุรหัสโค้ดเติมเงิน (VOUCHER CODE) <span style={{ color: '#ef4444' }}>*</span></label>
              <div style={{ position: 'relative', marginBottom: '14px' }}>
                <svg className="svg-icon" style={{ position: 'absolute', left: '14px', top: '14px', color: '#8b93a8' }} viewBox="0 0 24 24"><path d="M20.59 13.41l-7.17 7.17a2 2 0 0 1-2.83 0L2 12V2h10l8.59 8.59a2 2 0 0 1 0 2.82z" /><line x1="7" y1="7" x2="7.01" y2="7" /></svg>
                <input id="voucher-code" value={voucherCode} onChange={(e) => setVoucherCode(e.target.value)} type="text" className="field" placeholder="เช่น VOUCHER-50 หรือ COMF" style={{ paddingLeft: '42px', background: '#090d17', fontFamily: 'ui-monospace,Menlo,Consolas,monospace' }} autoComplete="off" />
              </div>
              <div style={{ background: 'rgba(16,185,129,.1)', border: '1px solid rgba(16,185,129,.3)', borderRadius: '12px', padding: '14px', marginBottom: '14px', display: 'flex', alignItems: 'center', gap: '10px' }}>
                <svg className="svg-icon" style={{ color: '#10b981', width: '20px', height: '20px' }} viewBox="0 0 24 24"><path d="M12 3l1.9 5.1L19 10l-5.1 1.9L12 17l-1.9-5.1L5 10l5.1-1.9z" /></svg>
                <div style={{ fontSize: '13px', color: '#10b981', fontWeight: '500', lineHeight: '1.4' }}>เครดิตจะถูกเติมเข้ากระเป๋าเงินของคุณอัตโนมัติทันทีหลังกดยืนยัน</div>
              </div>
              <p style={{ fontSize: '12.5px', color: '#8b93a8', margin: '0', lineHeight: '1.5' }}>มีโค้ดของรางวัลไอเทมเกมใช่ไหม? <NavLink page="redeem" style={{ color: '#6a5cff', textDecoration: 'underline' }}>ไปที่ศูนย์แลกโค้ดของรางวัล (Redeem Center) →</NavLink></p>
              </>
            )}
          </Fragment>
        </div>
      </div>

      <div className="topup-card" id="summary-card">
        <h2 style={{ fontSize: '16px', margin: '0 0 14px' }}>2. สรุปรายการเติมเงิน</h2>
        <label style={{ display: 'block', fontSize: '13px', fontWeight: '600', marginBottom: '8px' }}>ยอดเติมเงิน <span style={{ color: '#ef4444' }}>*</span></label>
        <input className="field" type="number" min="1" step="0.01" value={amount} onChange={(e) => setAmount(e.target.value)} placeholder="ระบุจำนวนเงิน เช่น 100" style={{ marginBottom: '14px' }} />
        <div style={{ display: 'flex', flexDirection: 'column', gap: '10px', fontSize: '13.5px', marginBottom: '18px' }}>
          <div className="flex justify-between"><span className="muted">ช่องทางที่เลือก:</span><span id="sum-method" style={{ fontWeight: '600' }}>{M.label}</span></div>
          <div className="flex justify-between"><span className="muted">สถานะช่องทาง:</span><span style={{ color: '#10b981', fontWeight: '600' }}>พร้อมให้บริการ</span></div>
          <div className="flex justify-between"><span className="muted">ระบบประมวลผล:</span><span style={{ color: '#10b981', fontWeight: '600', display: 'flex', alignItems: 'center', gap: '4px' }}><svg className="svg-icon" style={{ width: '12px', height: '12px' }} viewBox="0 0 24 24"><polygon points="13 2 3 14 12 14 11 22 21 10 12 10 13 2" /></svg>อัตโนมัติ (1-3 วินาที)</span></div>
          <div className="flex justify-between"><span className="muted">ยอดเติมขั้นต่ำ:</span><span style={{ fontWeight: '600' }}>ไม่มีขั้นต่ำ</span></div>
          <div className="flex justify-between"><span className="muted">ค่าธรรมเนียม:</span><span id="sum-fee" style={{ fontWeight: '600', color: M.feeColor }}>{M.fee}</span></div>
          <div className="flex justify-between"><span className="muted">แต้มสะสม:</span><span style={{ fontWeight: '600', color: '#8b93a8' }}>ได้รับเมื่อสั่งซื้อสินค้า</span></div>
        </div>

        <div style={{ background: '#11141e', border: '1px solid #252a38', borderRadius: '10px', padding: '12px', marginBottom: '18px', display: 'flex', alignItems: 'flex-start', gap: '10px' }}>
          <svg className="svg-icon" style={{ color: '#6a5cff', width: '20px', height: '20px' }} viewBox="0 0 24 24"><path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z" /><polyline points="9 12 11 14 15 10" /></svg>
          <div>
            <div style={{ fontSize: '13.5px', fontWeight: '600', color: '#e5e7f1', marginBottom: '2px' }}>ระบบเติมเงินปลอดภัย 100%</div>
            <div className="muted" style={{ fontSize: '12px', lineHeight: '1.4' }}>ยอดเงินจะถูกตรวจสอบอัตโนมัติ เมื่อสำเร็จระบบจะปรับยอดเครดิตให้คุณทันที</div>
          </div>
        </div>

        <button id="confirm-topup-btn" onClick={confirmTopup} type="button" className="primary" style={{ width: '100%', padding: '12px', fontSize: '14px', display: 'flex', justifyContent: 'center', alignItems: 'center', gap: '8px' }}>
          {ready && (currentUser ? 'ยืนยันการเติมเงิน' : (
            <>
              <svg className="svg-icon" viewBox="0 0 24 24"><path d="M15 3h4a2 2 0 0 1 2 2v14a2 2 0 0 1-2 2h-4" /><polyline points="10 17 15 12 10 7" /><line x1="15" y1="12" x2="3" y2="12" /></svg>เข้าสู่ระบบเพื่อทำรายการ
            </>
          ))}
        </button>
      </div>

      <div className="topup-card">
        <div className="flex items-center gap-2" style={{ marginBottom: '16px' }}>
          <svg className="svg-icon" style={{ color: '#8b93a8' }} viewBox="0 0 24 24"><circle cx="12" cy="12" r="10" /><polyline points="12 6 12 12 16 14" /></svg>
          <h2 style={{ fontSize: '15px', margin: '0' }}>ประวัติการทำรายการล่าสุด</h2>
        </div>
        <div className="grid grid-cols-5" style={{ fontSize: '11.5px', color: '#8b93a8', textAlign: 'center', marginBottom: '12px' }}>
          <div>รหัส<br />อ้างอิง</div><div>รายการ</div><div>ช่อง<br />ทาง</div><div>วัน<br />ที่</div><div>จำนวน</div>
        </div>
        <div style={{ borderTop: '1px solid #252a38', textAlign: 'center', padding: '22px 0 6px' }}>
          <p className="muted" style={{ fontSize: '13px', margin: '0' }}>ยังไม่มีประวัติการทำรายการ</p>
        </div>
      </div>
    </section>
  );
}
