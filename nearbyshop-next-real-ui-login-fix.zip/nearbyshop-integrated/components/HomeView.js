'use client';

import { useApp } from '@/context/AppContext';
import { useEffect, useState } from 'react';
import GameCard from '@/components/GameCard';
import { supabase } from '@/lib/supabase';
import { games, CAT_ONLINE } from '@/lib/games';

export default function HomeView() {
  const { navigate } = useApp();
  const [catalog, setCatalog] = useState(games);
  useEffect(() => { if (supabase) supabase.from('games').select('*,game_packages(*)').eq('active', true).order('id').then(({ data }) => { if (data?.length) setCatalog(data.map(g => ({ ...g, cat: g.category, sub: g.subtext, img: g.cover_url }))); }); }, []);
  const allCount = catalog.length;
  const onlineCount = catalog.filter(g => (g.cat || g.category) === CAT_ONLINE).length;
  const cardCount = catalog.filter(g => (g.cat || g.category) === 'บัตรเติมเงิน & วอลเล็ต').length;

  return (
    <section id="home" className="view active page">
      <div className="flex justify-between items-end" style={{ marginBottom: '16px' }}>
        <h1 style={{ fontSize: '20px', margin: '0' }}>หมวดหมู่บริการ</h1>
        <button type="button" className="link-btn" onClick={() => navigate('categories')}>ดูทั้งหมด →</button>
      </div>

      <div>
        <button type="button" className="category-card" onClick={() => navigate('categories', '?cat=' + encodeURIComponent('ทั้งหมด'))}>
          <div className="title-row"><span className="title">ทั้งหมด</span><span className="count"><span className="c-all">{allCount}</span> รายการ</span></div>
          <p className="desc">บริการเกมและบัตรเติมเงินทั้งหมด</p>
        </button>
        <button type="button" className="category-card" onClick={() => navigate('categories', '?cat=' + encodeURIComponent('เติมเกมออนไลน์'))}>
          <div className="title-row"><span className="title">เติมเกมออนไลน์</span><span className="count"><span className="c-online">{onlineCount}</span> รายการ</span></div>
          <p className="desc">เติมเพชร เหรียญ ไอเทมเกมออนไลน์ยอดนิยมทุกแพลตฟอร์ม</p>
        </button>
        <button type="button" className="category-card" onClick={() => navigate('categories', '?cat=' + encodeURIComponent('บัตรเติมเงิน & วอลเล็ต'))}>
          <div className="title-row"><span className="title">บัตรเติมเงิน &amp; วอลเล็ต</span><span className="count"><span className="c-card">{cardCount}</span> รายการ</span></div>
          <p className="desc">บัตร Steam Wallet, Razer Gold, iTunes, Google Play</p>
        </button>
      </div>

      <div className="flex justify-between items-end" style={{ marginTop: '36px', marginBottom: '16px' }}>
        <h2 style={{ fontSize: '20px', margin: '0' }}>เกมยอดนิยม</h2>
        <button type="button" className="link-btn" onClick={() => navigate('categories')}>ดูทั้งหมด →</button>
      </div>
      <div id="home-games-popular" className="game-grid">
        {catalog.filter((g) => g.popular).map((g) => <GameCard key={g.id || g.name} game={g} />)}
      </div>

      <div className="panel" style={{ padding: '22px 16px', marginTop: '36px', textAlign: 'center' }}>
        <h2 style={{ fontSize: '17px', margin: '0 0 8px' }}>ระบบกระเป๋าเงิน (Account Credit)</h2>
        <p className="muted" style={{ fontSize: '13px', margin: '0 0 14px', lineHeight: '1.5' }}>เติมเครดิตผ่าน TrueMoney ซองของขวัญ หรือโอนธนาคาร แนบสลิป (Slip Verify) อัตโนมัติ รวดเร็วและปลอดภัย 24 ชม.</p>
        <button type="button" className="primary" style={{ padding: '10px 24px', fontSize: '13.5px' }} onClick={() => navigate('topup')}>เติมเครดิตทันที</button>
      </div>

      <div className="flex justify-between items-end" style={{ marginTop: '36px', marginBottom: '16px' }}>
        <h2 style={{ fontSize: '20px', margin: '0' }}>เติมเกมออนไลน์ทั้งหมด (<span className="c-online">{onlineCount}</span>)</h2>
        <button type="button" className="link-btn" onClick={() => navigate('categories', '?cat=' + encodeURIComponent('เติมเกมออนไลน์'))}>ดูทั้งหมด →</button>
      </div>
      <div id="home-games-all" className="game-grid">
        {catalog.filter((g) => (g.cat || g.category) === CAT_ONLINE).map((g) => <GameCard key={g.id || g.name} game={g} />)}
      </div>
    </section>
  );
}
