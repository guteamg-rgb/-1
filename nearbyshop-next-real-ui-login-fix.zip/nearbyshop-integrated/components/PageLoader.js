'use client';

import { useApp } from '@/context/AppContext';

export default function PageLoader() {
  const { loading } = useApp();
  return (
    <div id="page-loader" className={loading ? 'active' : ''}>
      <div className="loader-spinner"></div>
      <div className="loader-text">กำลังโหลด...</div>
    </div>
  );
}
