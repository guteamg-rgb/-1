'use client';

import { useEffect, useRef, useState } from 'react';
import Swal from 'sweetalert2';
import { useApp } from '@/context/AppContext';
import NavLink from '@/components/NavLink';
import Icon from '@/components/Icon';
import { store, safeParse } from '@/lib/store';
import { copyToClipboard, thaiStamp } from '@/lib/utils';

const API_SCOPES = 'v1,v2,noSlip,tmn';
const STORAGE_KEY = 'nearbyshop_api_keys';
const maskKey = (k) => k.slice(0, 12) + '•'.repeat(24) + '…';

export default function ApiView() {
  const { ready, currentUser, navigate } = useApp();
  const [apiKeys, setApiKeys] = useState([]);
  const keysRef = useRef([]); // ค่าล่าสุดของ apiKeys (ใช้ใน callback ของ Swal)
  const [revealed, setRevealed] = useState(() => new Set());
  const [modalOpen, setModalOpen] = useState(false);
  const [modalName, setModalName] = useState('');
  const [modalNote, setModalNote] = useState('');

  // โหลด API Keys จาก storage (ฝั่ง browser เท่านั้น)
  useEffect(() => {
    const loaded = safeParse(STORAGE_KEY, []);
    commit(Array.isArray(loaded) ? loaded : [], false);
  }, []);

  // ปุ่ม Esc ปิด modal
  useEffect(() => {
    const onKey = (e) => { if (e.key === 'Escape') setModalOpen(false); };
    document.addEventListener('keydown', onKey);
    return () => document.removeEventListener('keydown', onKey);
  }, []);

  function commit(next, persist = true) {
    keysRef.current = next;
    setApiKeys(next);
    if (persist) store.set(STORAGE_KEY, JSON.stringify(next));
  }

  function docsSoon() {
    Swal.fire({ title: 'Coming Soon', text: 'หน้าเอกสาร API จะเปิดใช้งานในเร็วๆ นี้', icon: 'info', confirmButtonText: 'ตกลง' });
  }

  function openApiModal() {
    const t = new Date();
    setModalName(`API Key (${t.getDate()}/${t.getMonth() + 1}/${t.getFullYear() + 543})`);
    setModalNote('');
    setModalOpen(true);
  }
  function closeApiModal() { setModalOpen(false); }

  function submitCreateApiKey() {
    const name = modalName.trim();
    const note = modalNote.trim();
    if (!name) { Swal.fire({ title: 'ผิดพลาด', text: 'กรุณาระบุชื่อ API Key', icon: 'warning', confirmButtonText: 'ตกลง' }); return; }
    const bytes = new Uint8Array(16);
    (window.crypto || window.msCrypto).getRandomValues(bytes);
    const hex = Array.from(bytes, (b) => b.toString(16).padStart(2, '0')).join('');
    commit([...keysRef.current, { name, note, key: `nb_live_${hex}`, date: thaiStamp(new Date()) }]);
    closeApiModal();
    Swal.fire({ title: 'สำเร็จ', text: 'สร้าง API Key เรียบร้อยแล้ว', icon: 'success', confirmButtonText: 'ตกลง' });
  }

  function editApiName(i) {
    const k = keysRef.current[i]; if (!k) return;
    Swal.fire({ title: 'แก้ไขชื่อ API Key', input: 'text', inputValue: k.name, inputAttributes: { maxlength: 60 }, showCancelButton: true, confirmButtonText: 'บันทึก', cancelButtonText: 'ยกเลิก' })
      .then((r) => {
        if (!r.isConfirmed) return;
        const v = String(r.value || '').trim(); if (!v) return;
        commit(keysRef.current.map((x, idx) => (idx === i ? { ...x, name: v.slice(0, 60) } : x)));
      });
  }
  function editApiNote(i) {
    const k = keysRef.current[i]; if (!k) return;
    Swal.fire({ title: 'หมายเหตุ / บันทึกช่วยจำ', input: 'text', inputValue: k.note || '', inputAttributes: { maxlength: 200 }, showCancelButton: true, confirmButtonText: 'บันทึก', cancelButtonText: 'ยกเลิก' })
      .then((r) => {
        if (!r.isConfirmed) return;
        commit(keysRef.current.map((x, idx) => (idx === i ? { ...x, note: String(r.value || '').trim().slice(0, 200) } : x)));
      });
  }
  function toggleApiKey(i) {
    const k = keysRef.current[i]; if (!k) return;
    setRevealed((prev) => {
      const next = new Set(prev);
      next.has(k.key) ? next.delete(k.key) : next.add(k.key);
      return next;
    });
  }
  function copyApiKey(i) { if (keysRef.current[i]) copyToClipboard(keysRef.current[i].key); }
  function deleteApiKey(i) {
    Swal.fire({ title: 'ลบ API Key?', text: 'การกระทำนี้ไม่สามารถย้อนกลับได้', icon: 'warning', showCancelButton: true, confirmButtonText: 'ลบ', cancelButtonText: 'ยกเลิก' }).then((r) => {
      if (!r.isConfirmed) return;
      commit(keysRef.current.filter((_, idx) => idx !== i));
    });
  }

  // ---------- ส่วนแสดง API Dashboard ----------
  function renderDashboard() {
    if (!currentUser) {
      return (
        <div style={{ textAlign: 'center' }}>
          <div style={{ width: '54px', height: '54px', borderRadius: '15px', background: '#1c1a38', border: '1px solid #2d2a52', display: 'flex', alignItems: 'center', justifyContent: 'center', margin: '0 auto 12px', color: '#a99eff' }}><Icon name="key" style={{ width: '26px', height: '26px' }} /></div>
          <h2 style={{ fontSize: '17px', margin: '0 0 8px', lineHeight: '1.4' }}>เข้าสู่ระบบเพื่อจัดการ API Key ของคุณ</h2>
          <p className="muted" style={{ fontSize: '12.5px', margin: '0 0 18px', lineHeight: '1.6' }}>กรุณาเข้าสู่ระบบหรือสมัครสมาชิกบัญชี NearbyShop เพื่อสร้าง API Key สำหรับเรียกใช้งาน API ในเครือข่าย</p>
          <div className="flex justify-center gap-2">
            <button type="button" className="primary" style={{ padding: '10px 20px', fontSize: '13.5px', borderRadius: '12px' }} onClick={() => navigate('login')}>เข้าสู่ระบบ</button>
            <button type="button" className="secondary" style={{ padding: '10px 20px', fontSize: '13.5px', borderRadius: '12px' }} onClick={() => navigate('register')}>สมัครสมาชิกฟรี</button>
          </div>
        </div>
      );
    }
    return (
      <>
        <h2 className="api-h2"><Icon name="key" />API Keys ของคุณ ({apiKeys.length})</h2>
        <p className="muted" style={{ fontSize: '12px', margin: '0 0 14px', lineHeight: '1.5' }}>ใช้ Key ด้านล่างนี้ในการยืนยันตัวตนกับ API Gateway (<code>https://api.nearbyshop.xyz</code>)</p>
        <button type="button" onClick={openApiModal} className="primary" style={{ width: '100%', padding: '11px', fontSize: '13.5px', marginBottom: '14px', borderRadius: '12px', display: 'flex', alignItems: 'center', justifyContent: 'center', gap: '6px' }}><Icon name="plus" />สร้าง API Key ใหม่</button>
        <div style={{ borderTop: '1px solid #252a38', paddingTop: '14px' }}>
          {apiKeys.length === 0 ? (
            <div style={{ textAlign: 'center', padding: '22px 0 8px' }}>
              <p className="muted" style={{ fontSize: '13px', marginBottom: '12px' }}>คุณยังไม่มี API Key ในระบบ</p>
              <button type="button" onClick={openApiModal} className="primary" style={{ padding: '10px 20px', fontSize: '13px', borderRadius: '10px' }}>คลิกเพื่อสร้าง API Key แรก</button>
            </div>
          ) : apiKeys.map((key, i) => {
            const shown = revealed.has(key.key) ? key.key : maskKey(key.key);
            return (
              <div className="key-card" key={key.key}>
                <div className="key-head"><span className="key-name">{key.name}</span><span className="key-ok">ใช้งานได้ปกติ</span></div>
                <div className="key-scope">{API_SCOPES}</div>
                <button type="button" className="key-note" onClick={() => editApiNote(i)}><Icon name="note" /><span>{key.note ? key.note : '+ ใส่หมายเหตุ'}</span></button>
                <div className="key-value">{shown}</div>
                <div className="key-date">สร้างเมื่อ: {key.date}</div>
                <div className="key-actions">
                  <button type="button" className="key-btn" onClick={() => editApiName(i)} aria-label="แก้ไขชื่อ"><Icon name="pencil" /></button>
                  <button type="button" className="key-btn" onClick={() => toggleApiKey(i)} aria-label="แสดงหรือซ่อน Key"><Icon name={revealed.has(key.key) ? 'eye-off' : 'eye'} /></button>
                  <button type="button" className="key-btn primary" onClick={() => copyApiKey(i)}><Icon name="copy" />คัดลอก</button>
                  <button type="button" className="key-btn key-del" onClick={() => deleteApiKey(i)} aria-label="ลบ"><Icon name="trash" /></button>
                </div>
              </div>
            );
          })}
        </div>
      </>
    );
  }

  return (
    <>
      <section id="api" className="view active page">
      <div style={{ background: 'linear-gradient(135deg,#1d1c3c,#161820)', padding: '22px 18px', marginBottom: '18px', borderRadius: '24px', border: '1px solid #2d2a52' }}>
        <span className="badge-pill" style={{ fontSize: '12px' }}>
          <svg className="svg-icon" style={{ width: '14px', height: '14px' }} viewBox="0 0 24 24"><path d="M12 3l1.9 5.1L19 10l-5.1 1.9L12 17l-1.9-5.1L5 10l5.1-1.9z" /></svg>
          Nearby Network API Developer Hub
        </span>
        <h1 style={{ fontSize: '24px', margin: '14px 0 10px', lineHeight: '1.35' }}>ศูนย์รวมนักพัฒนาและจัดการ API Key</h1>
        <p className="muted" style={{ fontSize: '13.5px', margin: '0', lineHeight: '1.6' }}>เชื่อมต่อระบบตรวจสอบสลิปโอนเงินธนาคาร (Slip Verify) และระบบซองของขวัญ TrueMoney Wallet เข้ากับเว็บไซต์, บอท Discord, บอท Line หรือระบบหลังบ้านของคุณได้ในไม่กี่นาที</p>
      </div>

      <div className="panel" style={{ padding: '22px 16px', marginBottom: '18px', borderRadius: '24px' }} id="api-dashboard-area">
        {ready && renderDashboard()}
      </div>

      <div className="panel" style={{ padding: '22px 16px', marginBottom: '18px', borderRadius: '24px' }}>
        <span className="badge-pill" style={{ fontSize: '12px', borderRadius: '8px' }}>
          <svg className="svg-icon" style={{ width: '14px', height: '14px' }} viewBox="0 0 24 24"><path d="M2 3h6a4 4 0 0 1 4 4v14a3 3 0 0 0-3-3H2z" /><path d="M22 3h-6a4 4 0 0 0-4 4v14a3 3 0 0 1 3-3h7z" /></svg>
          คู่มือและรายการบริการ (API Documentation)
        </span>
        <h2 style={{ fontSize: '18px', margin: '14px 0 10px', lineHeight: '1.4' }}>คู่มือการเชื่อมต่อและรายการบริการ API ทั้งหมด</h2>
        <p className="muted" style={{ fontSize: '13.5px', margin: '0 0 12px', lineHeight: '1.6' }}>ดูรายละเอียด Endpoint ทั้งหมด, รูปแบบคำขอ (Request / Response), พารามิเตอร์, ตัวอย่างโค้ดทุกภาษา (Node.js, Python, PHP, cURL) และสถานะบริการ ได้ที่หน้าเอกสารทางการที่</p>
        <a href="#" onClick={(event) => { event.preventDefault(); docsSoon(); }} style={{ color: '#6a5cff', fontSize: '13.5px', fontWeight: '600', textDecoration: 'underline', display: 'inline-flex', alignItems: 'center', gap: '6px', marginBottom: '18px' }}>docs.nearbyshop.xyz
          <svg className="svg-icon" style={{ width: '14px', height: '14px' }} viewBox="0 0 24 24"><path d="M18 13v6a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V8a2 2 0 0 1 2-2h6" /><polyline points="15 3 21 3 21 9" /><line x1="10" y1="14" x2="21" y2="3" /></svg></a>
        <br />
        <a href="#" onClick={(event) => { event.preventDefault(); docsSoon(); }} className="primary" style={{ padding: '12px 22px', fontSize: '14px', borderRadius: '14px', display: 'inline-flex', alignItems: 'center', gap: '8px', textDecoration: 'none' }}>ไปที่ docs.nearbyshop.xyz
          <svg className="svg-icon" style={{ width: '14px', height: '14px' }} viewBox="0 0 24 24"><path d="M18 13v6a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V8a2 2 0 0 1 2-2h6" /><polyline points="15 3 21 3 21 9" /><line x1="10" y1="14" x2="21" y2="3" /></svg></a>
      </div>
    </section>

      <div
      id="api-modal"
      className={'api-modal' + (modalOpen ? ' active' : '')}
      onClick={(e) => { if (e.target === e.currentTarget) closeApiModal(); }}
    >
    <div className="api-modal-content">
      <div className="modal-head">
        <span className="modal-ico"><svg className="svg-icon" viewBox="0 0 24 24" aria-hidden="true"><use href="#i-key" /></svg></span>
        <h2>สร้าง API Key ใหม่</h2>
        <button type="button" onClick={closeApiModal} aria-label="ปิด" className="modal-close"><svg className="svg-icon" viewBox="0 0 24 24" aria-hidden="true"><use href="#i-close" /></svg></button>
      </div>
      <div className="form-group">
        <label className="form-label" style={{ color: '#fff' }} htmlFor="api-key-name">ชื่อ API Key <span className="req-star">*</span></label>
        <input type="text" id="api-key-name" value={modalName} onChange={(e) => setModalName(e.target.value)} className="field" style={{ background: '#090d17' }} maxLength="60" />
      </div>
      <div className="form-group">
        <label className="form-label note-label" style={{ color: '#fff', justifyContent: 'flex-start' }} htmlFor="api-key-note"><svg className="svg-icon" viewBox="0 0 24 24" aria-hidden="true"><use href="#i-note" /></svg>หมายเหตุ / บันทึกช่วยจำ (Note)</label>
        <textarea id="api-key-note" value={modalNote} onChange={(e) => setModalNote(e.target.value)} className="field" style={{ background: '#090d17', height: '84px', resize: 'none' }} maxLength="200" placeholder="ระบุหมายเหตุ เช่น ใช้เชื่อมต่อกับเซิร์ฟเวอร์สำรอง, บอทห้องเติมเงิน VIP (แก้ไขภายหลังได้)"></textarea>
        <div className="form-hint">หมายเหตุนี้ช่วยให้จำได้ว่า Key นี้ถูกนำไปผูกไว้กับระบบใด</div>
      </div>
      <div style={{ display: 'flex', justifyContent: 'flex-end', gap: '10px', marginTop: '16px' }}>
        <button type="button" onClick={closeApiModal} className="secondary" style={{ padding: '9px 18px', fontSize: '13px' }}>ยกเลิก</button>
        <button type="button" onClick={submitCreateApiKey} className="primary" style={{ padding: '9px 16px', fontSize: '13px', display: 'flex', alignItems: 'center', gap: '6px' }}><svg className="svg-icon" viewBox="0 0 24 24" aria-hidden="true"><use href="#i-plus" /></svg>สร้าง API Key</button>
      </div>
    </div>
  </div>
    </>
  );
}
