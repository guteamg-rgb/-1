'use client';

import { useState } from 'react';
import { useRouter } from 'next/navigation';
import { CAT_CARD, coverFor } from '@/lib/games';

function TagIcon({ name }) {
  if (name === 'bolt') {
    return <svg className="svg-icon" viewBox="0 0 24 24"><polygon points="13 2 3 14 12 14 11 22 21 10 12 10 13 2" /></svg>;
  }
  if (name === 'link') {
    return <svg className="svg-icon" viewBox="0 0 24 24"><path d="M10 13a5 5 0 0 0 7.54.54l3-3a5 5 0 0 0-7.07-7.07l-1.72 1.71" /><path d="M14 11a5 5 0 0 0-7.54-.54l-3 3a5 5 0 0 0 7.07 7.07l1.71-1.71" /></svg>;
  }
  if (name === 'fire') return '🔥';
  if (name === 'star') return '⭐';
  return null;
}
export { TagIcon };

export default function GameCard({ game }) {
  const router = useRouter();
  const fallback = coverFor(game);
  const [src, setSrc] = useState(game.img || fallback);

  return (
    <article className="game-card" onClick={() => router.push('/game?g=' + encodeURIComponent(game.name))}>
      <div className="game-img-wrapper">
        {/* eslint-disable-next-line @next/next/no-img-element */}
        <img
          src={src}
          alt={game.name}
          loading="lazy"
          onError={() => { if (src !== fallback) setSrc(fallback); }}
        />
        {game.tag && (
          <div className="game-chip">
            <span className="chip-inner"><TagIcon name={game.icon} /><span>{game.tag}</span></span>
          </div>
        )}
      </div>
      <div className="game-title">{game.name}</div>
      <div className="game-subtitle">{game.sub || (game.cat === CAT_CARD ? 'บัตรเติมเงิน & วอลเล็ต' : 'เข้าทันที')}</div>
    </article>
  );
}
