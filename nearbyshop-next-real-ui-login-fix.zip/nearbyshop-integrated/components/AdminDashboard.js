'use client';
import { useCallback, useEffect, useMemo, useState } from 'react';
import { supabase } from '@/lib/supabase';
import Swal from 'sweetalert2';
import { useRouter } from 'next/navigation';
import './admin.css';

const tabs = [
  ['overview', 'ภาพรวม'], ['games', 'เกมและแพ็กเกจ'], ['orders', 'คำสั่งซื้อ'], ['topups', 'เติมเงิน'],
  ['users', 'ผู้ใช้'], ['redeem', 'โค้ดรางวัล'], ['news', 'ข่าวสาร'],
];
const money = (n) => `฿${Number(n || 0).toLocaleString('th-TH', { minimumFractionDigits: 2 })}`;

export default function AdminDashboard() {
  const router = useRouter();
  const [tab, setTab] = useState('overview');
  const [user, setUser] = useState(null);
  const [data, setData] = useState({ games: [], orders: [], topups: [], users: [], redeem: [], news: [] });
  const [busy, setBusy] = useState(true);
  const [error, setError] = useState('');

  const load = useCallback(async () => {
    if (!supabase) { setError('ยังไม่ได้ตั้งค่า Supabase ใน .env.local'); setBusy(false); return; }
    setBusy(true); setError('');
    const { data: auth } = await supabase.auth.getUser();
    if (!auth?.user) { router.replace('/login'); return; }
    const { data: profile, error: profileError } = await supabase.from('profiles').select('*').eq('id', auth.user.id).single();
    if (profileError || profile?.role !== 'admin') { setError('บัญชีนี้ไม่มีสิทธิ์ผู้ดูแลระบบ'); setBusy(false); return; }
    setUser(profile);
    const results = await Promise.all([
      supabase.from('games').select('*,game_packages(*)').order('id'),
      supabase.from('orders').select('*').order('created_at', { ascending: false }).limit(100),
      supabase.from('topups').select('*').order('created_at', { ascending: false }).limit(100),
      supabase.from('profiles').select('*').order('created_at', { ascending: false }),
      supabase.from('redeem_codes').select('*').order('created_at', { ascending: false }),
      supabase.from('news').select('*').order('created_at', { ascending: false }),
    ]);
    const names = ['games', 'orders', 'topups', 'users', 'redeem', 'news'];
    const next = {}; results.forEach((r, i) => { if (r.error) setError(r.error.message); next[names[i]] = r.data || []; });
    setData(next); setBusy(false);
  }, [router]);
  useEffect(() => { load(); }, [load]);

  async function signOut() { await supabase?.auth.signOut(); router.replace('/login'); }
  async function updateOrder(id, status) {
    const { error: e } = await supabase.from('orders').update({ status }).eq('id', id);
    if (e) return Swal.fire('ไม่สำเร็จ', e.message, 'error'); await load();
  }
  async function approveTopup(topup) {
    const { error: e } = await supabase.from('topups').update({ status: 'success' }).eq('id', topup.id).eq('status', 'pending');
    if (e) return Swal.fire('ไม่สำเร็จ', e.message, 'error');
    const { data: p } = await supabase.from('profiles').select('credit').eq('id', topup.user_id).single();
    if (p) {
      await supabase.from('profiles').update({ credit: Number(p.credit) + Number(topup.amount) }).eq('id', topup.user_id);
      await supabase.from('wallet_ledger').insert({ user_id: topup.user_id, delta: topup.amount, reason: 'Top-up approved', reference_type: 'topup', reference_id: topup.id });
    }
    await load();
  }
  async function toggleGame(g) { const { error: e } = await supabase.from('games').update({ active: !g.active }).eq('id', g.id); if (e) Swal.fire('ไม่สำเร็จ', e.message, 'error'); else load(); }
  async function addGame() {
    const name = prompt('ชื่อเกม'); if (!name) return;
    const category = prompt('หมวดหมู่', 'เติมเกมออนไลน์') || 'เติมเกมออนไลน์';
    const { error: e } = await supabase.from('games').insert({ name, category, active: true });
    if (e) Swal.fire('เพิ่มเกมไม่สำเร็จ', e.message, 'error'); else load();
  }
  async function addPackage(g) {
    const name = prompt(`ชื่อแพ็กเกจสำหรับ ${g.name}`); if (!name) return;
    const price = Number(prompt('ราคา') || 0); if (!(price > 0)) return;
    const { error: e } = await supabase.from('game_packages').insert({ game_id: g.id, name, price, active: true });
    if (e) Swal.fire('เพิ่มแพ็กเกจไม่สำเร็จ', e.message, 'error'); else load();
  }
  async function addRedeem() {
    const code = prompt('รหัสโค้ด (ตัวพิมพ์ใหญ่)'); if (!code) return;
    const reward = prompt('รางวัล เช่น เครดิต ฿50'); if (!reward) return;
    const quantity = Number(prompt('จำนวนสิทธิ์', '1') || 1);
    const { error: e } = await supabase.from('redeem_codes').insert({ code: code.trim().toUpperCase(), reward, quantity, reward_type: 'credit' });
    if (e) Swal.fire('เพิ่มโค้ดไม่สำเร็จ', e.message, 'error'); else load();
  }
  async function addNews() {
    const title = prompt('หัวข้อข่าว'); if (!title) return;
    const body = prompt('เนื้อหา', '') || '';
    const { error: e } = await supabase.from('news').insert({ title, body, excerpt: body.slice(0, 120), status: 'published', published_at: new Date().toISOString(), created_by: user.id });
    if (e) Swal.fire('เพิ่มข่าวไม่สำเร็จ', e.message, 'error'); else load();
  }

  const pendingOrders = useMemo(() => data.orders.filter((x) => x.status === 'pending').length, [data.orders]);
  const pendingTopups = useMemo(() => data.topups.filter((x) => x.status === 'pending').length, [data.topups]);
  if (error && !user) return <main className="admin-page"><div className="admin-error"><h1>NearbyShop Admin</h1><p>{error}</p><button onClick={() => router.push('/login')}>กลับหน้าเข้าสู่ระบบ</button></div></main>;
  return <main className="admin-page">
    <header className="admin-header"><div><div className="admin-brand">NEARBY<span>SHOP</span></div><small>Production Control Center</small></div><div className="admin-account">{user?.username || 'Admin'} <button onClick={signOut}>ออกจากระบบ</button></div></header>
    <nav className="admin-tabs">{tabs.map(([id, label]) => <button key={id} className={tab === id ? 'active' : ''} onClick={() => setTab(id)}>{label}{id === 'orders' && pendingOrders ? ` (${pendingOrders})` : ''}{id === 'topups' && pendingTopups ? ` (${pendingTopups})` : ''}</button>)}<button onClick={load}>รีเฟรช</button></nav>
    {busy ? <div className="admin-loading">กำลังโหลดข้อมูลจาก Supabase...</div> : <section className="admin-content">
      {tab === 'overview' && <><div className="admin-stats"><Stat title="เกมที่เปิดใช้งาน" value={data.games.filter(x => x.active).length} /><Stat title="ผู้ใช้ทั้งหมด" value={data.users.length} /><Stat title="คำสั่งซื้อรอดำเนินการ" value={pendingOrders} /><Stat title="เติมเงินรอตรวจสอบ" value={pendingTopups} /></div><div className="admin-card"><h2>สถานะระบบจริง</h2><p>เชื่อมต่อ Supabase สำเร็จ • RLS ทำงาน • บัญชีปัจจุบัน: {user?.email}</p><p className="muted">การอนุมัติเติมเงินจะเพิ่มเครดิตและบันทึก wallet ledger ในฐานข้อมูล</p></div></>}
      {tab === 'games' && <div className="admin-card"><div className="card-head"><h2>เกมและแพ็กเกจ</h2><button onClick={addGame}>+ เพิ่มเกม</button></div><table><thead><tr><th>เกม</th><th>หมวดหมู่</th><th>แพ็กเกจ</th><th>สถานะ</th><th>จัดการ</th></tr></thead><tbody>{data.games.map(g => <tr key={g.id}><td>{g.name}</td><td>{g.category}</td><td>{g.game_packages?.length || 0}</td><td><Badge ok={g.active} /></td><td><button onClick={() => addPackage(g)}>+ แพ็กเกจ</button> <button onClick={() => toggleGame(g)}>{g.active ? 'ปิดใช้งาน' : 'เปิดใช้งาน'}</button></td></tr>)}</tbody></table></div>}
      {tab === 'orders' && <DataTable rows={data.orders} columns={['id','username_snapshot','product','player_uid','amount','status','created_at']} action={(r) => r.status === 'pending' && <><button onClick={() => updateOrder(r.id, 'success')}>สำเร็จ</button> <button onClick={() => updateOrder(r.id, 'failed')}>ไม่สำเร็จ</button></>} />}
      {tab === 'topups' && <DataTable rows={data.topups} columns={['id','username_snapshot','method','amount','status','created_at']} action={(r) => r.status === 'pending' && <><button onClick={() => approveTopup(r)}>อนุมัติ</button> <button onClick={() => supabase.from('topups').update({ status: 'failed' }).eq('id', r.id).then(load)}>ปฏิเสธ</button></>} />}
      {tab === 'users' && <DataTable rows={data.users} columns={['username','email','role','credit','created_at']} />}
      {tab === 'redeem' && <div className="admin-card"><div className="card-head"><h2>โค้ดรางวัล</h2><button onClick={addRedeem}>+ เพิ่มโค้ด</button></div><DataTable rows={data.redeem} columns={['code','reward','reward_type','used_count','quantity','expires_at']} /></div>}
      {tab === 'news' && <div className="admin-card"><div className="card-head"><h2>ข่าวสาร</h2><button onClick={addNews}>+ เพิ่มข่าว</button></div><DataTable rows={data.news} columns={['title','category','status','created_at']} /></div>}
    </section>}
  </main>;
}
function Stat({ title, value }) { return <div className="admin-stat"><span>{title}</span><strong>{value}</strong></div>; }
function Badge({ ok }) { return <span className={ok ? 'badge ok' : 'badge'}>{ok ? 'เปิดใช้งาน' : 'ปิดใช้งาน'}</span>; }
function DataTable({ rows, columns, action }) { return <div className="admin-card"><table><thead><tr>{columns.map(c => <th key={c}>{c}</th>)}{action && <th>จัดการ</th>}</tr></thead><tbody>{rows.map((r, i) => <tr key={r.id || r.code || i}>{columns.map(c => <td key={c}>{c === 'amount' || c === 'credit' ? money(r[c]) : c === 'status' ? <Badge ok={r[c] === 'success' || r[c] === 'published'} /> : c.endsWith('_at') || c === 'created_at' ? new Date(r[c]).toLocaleString('th-TH') : String(r[c] ?? '-')}</td>)}{action && <td>{action(r)}</td>}</tr>)}</tbody></table>{!rows.length && <p className="muted empty">ยังไม่มีข้อมูล</p>}</div>; }
