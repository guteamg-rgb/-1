// ไอคอนจาก SVG sprite (ดู components/SvgSprite.js)
export default function Icon({ name, style }) {
  return (
    <svg className="svg-icon" style={style} viewBox="0 0 24 24" aria-hidden="true">
      <use href={`#i-${name}`} />
    </svg>
  );
}
