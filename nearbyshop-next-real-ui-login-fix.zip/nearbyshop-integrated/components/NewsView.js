'use client';

import { useRef } from 'react';
import Swal from 'sweetalert2';

export default function NewsView() {
  const searchRef = useRef(null);

  function searchBlog() {
    Swal.fire({ title: 'ไม่พบบทความ', text: 'ยังไม่มีบทความในระบบ', icon: 'info', confirmButtonText: 'ตกลง' });
  }

  return (
    <section id="news" className="view active page">
      <div style={{ background: 'linear-gradient(135deg,#1d1740,#161426 60%,#13131d)', border: '1px solid #2d2a52', borderRadius: '24px', padding: '24px 20px' }}>
        <span className="badge-pill">
          <svg className="svg-icon" viewBox="0 0 24 24"><path d="M12 3l1.9 5.1L19 10l-5.1 1.9L12 17l-1.9-5.1L5 10l5.1-1.9z" /><path d="M19 15l.7 1.8L21.5 17.5l-1.8.7L19 20l-.7-1.8-1.8-.7 1.8-.7z" /></svg>
          NearbyShop Community &amp; Blog
        </span>
        <h1 style={{ fontSize: '24px', lineHeight: '1.35', margin: '16px 0 12px' }}>ข่าวสาร &amp; บทความเกม <span className="grad-text">ทริค เทคนิค และอัปเดตล่าสุด</span></h1>
        <p className="muted" style={{ fontSize: '13.5px', lineHeight: '1.6', margin: '0 0 20px' }}>แหล่งรวบรวมข้อมูลแพตช์เกมใหม่ เทคนิคการเล่นสุดเจ๋ง และข่าวสารโปรโมชั่นเติมเกมราคาประหยัด อัปเดตสดใหม่เพื่อเกมเมอร์ตัวจริง</p>
        <div style={{ display: 'flex', gap: '10px' }}>
          <div style={{ position: 'relative', flex: '1' }}>
            <svg className="svg-icon" style={{ position: 'absolute', left: '14px', top: '15px', color: '#8b93a8', width: '20px', height: '20px' }} viewBox="0 0 24 24"><circle cx="11" cy="11" r="8" /><line x1="21" y1="21" x2="16.65" y2="16.65" /></svg>
            <input id="blog-search" ref={searchRef} className="field" type="search" placeholder="ค้นหาบทความ เช่น RoV, เทคนิค" style={{ padding: '13px 12px 13px 44px', borderRadius: '16px', background: '#0d0f1a' }} />
          </div>
          <button type="button" className="primary" onClick={searchBlog} style={{ padding: '0 20px', borderRadius: '16px', fontSize: '14px', boxShadow: '0 4px 14px rgba(80,54,239,.4)' }}>ค้นหา</button>
        </div>
      </div>

      <div className="filter-pills" style={{ marginTop: '20px' }}>
        <button type="button" className="pill selected">ทั้งหมด</button>
      </div>

      <div style={{ background: '#11141e', border: '1px solid #1f2330', borderRadius: '24px', padding: '48px 20px', marginTop: '12px', textAlign: 'center' }}>
        <div style={{ width: '64px', height: '64px', borderRadius: '16px', background: '#1c1e2a', display: 'flex', alignItems: 'center', justifyContent: 'center', margin: '0 auto 16px' }}>
          <svg className="svg-icon" style={{ color: '#6b7388', width: '30px', height: '30px' }} viewBox="0 0 24 24"><path d="M2 3h6a4 4 0 0 1 4 4v14a3 3 0 0 0-3-3H2z" /><path d="M22 3h-6a4 4 0 0 0-4 4v14a3 3 0 0 1 3-3h7z" /></svg>
        </div>
        <h3 style={{ fontSize: '17px', margin: '0 0 8px' }}>ไม่พบบทความที่คุณค้นหา</h3>
        <p className="muted" style={{ fontSize: '13.5px', margin: '0 0 20px' }}>ลองเปลี่ยนคำค้นหา หรือเลือกหมวดหมู่อื่นเพื่อดูบทความทั้งหมด</p>
        <button type="button" className="primary" onClick={() => { searchRef.current.value = ''; }} style={{ padding: '11px 22px', fontSize: '14px', borderRadius: '10px' }}>ดูบทความทั้งหมด</button>
      </div>
    </section>
  );
}
