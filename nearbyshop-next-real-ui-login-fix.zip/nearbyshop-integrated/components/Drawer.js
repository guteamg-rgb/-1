'use client';

import Swal from 'sweetalert2';
import { useApp } from '@/context/AppContext';
import Icon from '@/components/Icon';

const NAV_ITEMS = [
  { page: 'home', icon: 'home', label: 'หน้าแรก' },
  { page: 'categories', icon: 'grid', label: 'หมวดหมู่' },
  { page: 'news', icon: 'book', label: 'ข่าวสาร & บทความ' },
  { page: 'topup', icon: 'wallet', label: 'เติมเงิน' },
  { page: 'redeem', icon: 'gift', label: 'แลกโค้ดรางวัล' },
  { page: 'history', icon: 'receipt', label: 'ประวัติรายการ' },
  { page: 'api', icon: 'code', label: 'API & นักพัฒนา' },
];

export default function Drawer() {
  const { ready, currentUser, page, drawerOpen, closeDrawer, navigate, logout } = useApp();
  // หน้าเกม (game) ให้ไฮไลต์เมนู "หมวดหมู่"
  const navKey = page === 'game' ? 'categories' : page;

  return (
    <div
          id="drawer-overlay"
          aria-hidden="true"
          style={{ display: drawerOpen ? 'flex' : 'none' }}
          onClick={(e) => { if (e.target === e.currentTarget) closeDrawer(); }}
        >
        <aside className="drawer" aria-label="เมนูนำทาง">
          <div className="drawer-header">
            <svg className="drawer-logo" viewBox="0 0 120 76" aria-hidden="true"><use href="#logo-nb" /></svg>
            <div>
              <div style={{ fontWeight: '700', fontSize: '20px', color: '#fff', letterSpacing: '-.5px' }}>NEARBY<span style={{ color: '#6a5cff' }}>SHOP</span></div>
              <div style={{ fontSize: '13px', color: '#8b93a8', marginTop: '2px' }}>บริการเติมเกมออนไลน์</div>
            </div>
          </div>

          <div id="drawer-user-card" className="drawer-user-card" style={{ display: ready && currentUser ? 'block' : 'none' }}>
            <div className="duc-top">
              <div className="duc-user"><span className="duc-avatar"><svg className="svg-icon" viewBox="0 0 24 24" aria-hidden="true"><use href="#i-user" /></svg></span><span id="drawer-username" className="duc-name">{currentUser ? currentUser.username : ''}</span></div>
              <button type="button" onClick={logout} aria-label="ออกจากระบบ" className="duc-logout"><svg className="svg-icon" viewBox="0 0 24 24" aria-hidden="true"><use href="#i-logout" /></svg></button>
            </div>
            <div className="duc-bottom">
              <div><div className="muted duc-label">ยอดเครดิต</div><div className="duc-bal">฿0</div></div>
              <div className="duc-actions">
                <button type="button" className="duc-hist" aria-label="ประวัติรายการ" onClick={() => navigate('history')}><svg className="svg-icon" viewBox="0 0 24 24" aria-hidden="true"><use href="#i-receipt" /></svg></button>
                <button type="button" className="primary duc-topup" onClick={() => navigate('topup')}>เติมเงิน</button>
              </div>
            </div>
          </div>

          <div id="drawer-guest-card" className="drawer-guest-card" style={{ display: ready && !currentUser ? 'block' : 'none' }}>
            <h3 style={{ fontSize: '16px', margin: '0 0 6px', color: '#fff' }}>ยินดีต้อนรับสู่ NEARBYSHOP</h3>
            <p className="muted" style={{ fontSize: '13px', margin: '0 0 14px' }}>เข้าสู่ระบบเพื่อเติมเครดิตและสั่งซื้อ</p>
            <div style={{ display: 'flex', gap: '10px' }}>
              <button className="primary" style={{ flex: '1', padding: '11px 8px', fontSize: '14px', borderRadius: '10px', display: 'flex', justifyContent: 'center', alignItems: 'center', gap: '6px' }} onClick={() => navigate('login')}>
                <svg className="svg-icon" viewBox="0 0 24 24"><path d="M15 3h4a2 2 0 0 1 2 2v14a2 2 0 0 1-2 2h-4" /><polyline points="10 17 15 12 10 7" /><line x1="15" y1="12" x2="3" y2="12" /></svg>เข้าสู่ระบบ
              </button>
              <button className="secondary" style={{ flex: '1', padding: '11px 8px', fontSize: '14px', borderRadius: '10px', display: 'flex', justifyContent: 'center', alignItems: 'center', gap: '6px' }} onClick={() => navigate('register')}>
                <svg className="svg-icon" viewBox="0 0 24 24"><path d="M16 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2" /><circle cx="8.5" cy="7" r="4" /><line x1="20" y1="8" x2="20" y2="14" /><line x1="23" y1="11" x2="17" y2="11" /></svg>สมัคร
              </button>
            </div>
          </div>

          <div style={{ padding: '0 12px', flex: '1', overflowY: 'auto' }}>
            <p style={{ fontSize: '13px', color: '#8b93a8', margin: '0 0 8px 8px' }}>เมนู</p>
            <nav>
              {NAV_ITEMS.map((item) => (
                <button
                  key={item.page}
                  type="button"
                  className={'drawer-nav-item' + (navKey === item.page ? ' active' : '')}
                  onClick={() => navigate(item.page)}
                >
                  <Icon name={item.icon} />{item.label}
                </button>
              ))}
              {ready && currentUser?.isAdmin && (
                <button
                  type="button"
                  className="drawer-nav-item admin-nav-item"
                  onClick={() => { closeDrawer(); window.location.href = '/admin/index.html'; }}
                >
                  <Icon name="code" />จัดการหลังบ้าน
                </button>
              )}
              <button
                type="button"
                onClick={() => { closeDrawer(); Swal.fire({ title: 'ติดต่อเรา', text: 'อีเมล: support@nearbyshop.xyz', icon: 'info', confirmButtonText: 'ตกลง' }); }}
                className="drawer-nav-item"
              >
                <Icon name="phone" />ติดต่อเรา
              </button>
            </nav>
          </div>

          <div style={{ padding: '14px 16px', display: 'flex', justifyContent: 'space-between', alignItems: 'center', fontSize: '13px', color: '#8b93a8', borderTop: '1px solid #1a1f2e' }}>
            <span>© 2026 NearbyShop</span>
            <span style={{ color: '#10b981', display: 'flex', alignItems: 'center', gap: '4px' }}><svg className="svg-icon" viewBox="0 0 24 24"><path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z" /><polyline points="9 12 11 14 15 10" /></svg>ปลอดภัย</span>
          </div>
        </aside>
      </div>
  );
}
