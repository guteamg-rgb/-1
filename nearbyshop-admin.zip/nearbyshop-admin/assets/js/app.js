/* NearbyShop Admin — shared JS (ใช้ร่วมกันทุกหน้า) */
/* ============ SAFE STORAGE ============ */
const store = (() => {
  const mem = {}; let ls = null;
  try { ls = window.localStorage; ls.getItem('__nbadmin7'); } catch (e) { ls = null; }
  return {
    get(k) { try { return ls ? ls.getItem(k) : (k in mem ? mem[k] : null); } catch (e) { return k in mem ? mem[k] : null; } },
    set(k, v) { try { if (ls) ls.setItem(k, v); else mem[k] = v; } catch (e) { mem[k] = v; } },
    del(k) { try { if (ls) ls.removeItem(k); else delete mem[k]; } catch (e) { delete mem[k]; } }
  };
})();

if (typeof Swal === 'undefined') {
  window.Swal = { fire(o) { o = o || {}; if (o.input) { const v = prompt(o.title || '', o.inputValue || ''); return Promise.resolve({ isConfirmed: v !== null, value: v }); } const t = [o.title, o.text].filter(Boolean).join('\n'); if (o.showCancelButton) return Promise.resolve({ isConfirmed: confirm(t) }); if (!o.timer) alert(t); return Promise.resolve({ isConfirmed: true }); } };
}

/* ============ SEED ============ */
const SEED = {
  games: [
    { id: 1, name: "Free Fire", cat: "เติมเกมออนไลน์", tag: "เติมไว", sub: "เข้าทันที", popular: true, active: true, cover: null, packs: [
      { name: "90 บาท ได้รับ 310 Diamond", price: 90 },
      { name: "50 บาท ได้รับ 172 Diamond", price: 50 }
    ]},
    { id: 2, name: "RoV Mobile", cat: "เติมเกมออนไลน์", tag: "ฮิตอันดับ 1", sub: "เข้าทันที", popular: true, active: true, cover: null, packs: [
      { name: "50 บาท ได้รับ 172 Diamond", price: 50 },
      { name: "150 บาท ได้รับ 517 Diamond", price: 150 }
    ]},
    { id: 3, name: "Mobile Legends", cat: "เติมเกมออนไลน์", tag: "เติมไว", sub: "เข้าทันที", popular: true, active: true, cover: null, packs: [
      { name: "50 บาท ได้รับ 86 Diamond", price: 50 }
    ]},
    { id: 4, name: "Genshin Impact", cat: "เติมเกมออนไลน์", tag: "ยอดนิยม", sub: "เข้าทันที", popular: true, active: false, cover: null, packs: [
      { name: "100 บาท ได้รับ 60 Genesis", price: 100 }
    ]}
  ],
  users: [
    { id: 1, username: "Team", email: "team@nearbyshop.local", credit: 0, orders: 0, status: "active", date: "2026-11-01", note: "", balanceLog: [] },
    { id: 2, username: "gamer_pro", email: "gamer.pro@example.com", credit: 250, orders: 12, status: "active", date: "2026-10-15", note: "VIP", balanceLog: [
      { delta: 200, reason: "เติมเงิน TXN-001", time: "2026-11-12 09:10" }
    ]},
    { id: 3, username: "rovmaster", email: "rov.master@example.com", credit: 1500, orders: 45, status: "active", date: "2026-09-20", note: "", balanceLog: [] },
    { id: 4, username: "ff_lover", email: "ff.lover@example.com", credit: 75, orders: 3, status: "active", date: "2026-11-10", note: "", balanceLog: [] },
    { id: 5, username: "test_user", email: "test@example.com", credit: 0, orders: 0, status: "inactive", date: "2026-08-05", note: "ทดสอบ", balanceLog: [] }
  ],
  orders: [
    { id: "ORD-001", user: "gamer_pro", product: "Free Fire — 90 บาท", uid: "12345678", amount: 90, status: "success", date: "2026-11-12 09:15", note: "" },
    { id: "ORD-002", user: "rovmaster", product: "RoV Mobile — 50 บาท", uid: "87654321", amount: 50, status: "success", date: "2026-11-12 08:42", note: "" },
    { id: "ORD-003", user: "ff_lover", product: "Free Fire — 10 บาท", uid: "11223344", amount: 10, status: "pending", date: "2026-11-12 07:30", note: "" },
    { id: "ORD-004", user: "gamer_pro", product: "Mobile Legends — 150 บาท", uid: "55667788", amount: 150, status: "success", date: "2026-11-11 21:10", note: "" },
    { id: "ORD-005", user: "rovmaster", product: "Valorant — 300 บาท", uid: "99887766", amount: 300, status: "failed", date: "2026-11-11 18:55", note: "" }
  ],
  topups: [
    { id: "TXN-001", user: "gamer_pro", method: "TrueMoney", amount: 200, fee: 5.8, status: "success", date: "2026-11-12 09:10", note: "ตรวจสอบสลิปแล้ว" },
    { id: "TXN-002", user: "rovmaster", method: "ธนาคาร", amount: 500, fee: 0, status: "success", date: "2026-11-12 08:35", note: "" },
    { id: "TXN-003", user: "ff_lover", method: "Voucher", amount: 50, fee: 0, status: "pending", date: "2026-11-12 07:20", note: "" }
  ],
  redeemCodes: [
    { code: "ROV-FREE-2026", reward: "เครดิต ฿50", type: "credit", qty: 100, used: 34, start: "2026-11-01", expiry: "2026-12-31" },
    { code: "WELCOME-50", reward: "เครดิต ฿50", type: "credit", qty: 500, used: 128, start: "", expiry: "" }
  ],
  coupons: [
    { code: "SAVE10", type: "percent", discount: 10, min: 100, max: 0, qty: 100, used: 45, expiry: "2026-12-31" },
    { code: "SAVE50", type: "fixed", discount: 50, min: 200, max: 50, qty: 30, used: 12, expiry: "2026-12-31" }
  ],
  news: [
    { id: 1, title: "ยินดีต้อนรับสู่ NearbyShop", excerpt: "เปิดให้บริการเติมเกม 24 ชม.", body: "เปิดให้บริการเติมเกม 24 ชม. มีโปรโมชั่นพิเศษสำหรับลูกค้าใหม่", category: "announcement", status: "published", date: "2026-11-01", updated: "2026-11-01" },
    { id: 2, title: "อัปเดตเกม Free Fire", excerpt: "แพ็กเกจใหม่พร้อมให้บริการแล้ว", body: "เพิ่มแพ็กเกจ Free Fire ใหม่ 3 รายการ พร้อมโปรโมชั่นพิเศษ", category: "update", status: "published", date: "2026-11-10", updated: "2026-11-10" }
  ],
  apiKeys: [
    { id: 1, name: "Production Bot", note: "Discord Bot", key: "nb_live_a1b2c3d4e5f6g7h8i9j0k1l2m3n4o5p6", date: "2026-11-01 10:00", active: true, expiry: "2027-11-01", scopes: ["v1", "v2", "tmn"] },
    { id: 2, name: "Backup Server", note: "เซิร์ฟเวอร์สำรอง", key: "nb_live_q1w2e3r4t5y6u7i8o9p0a1s2d3f4g5h6", date: "2026-10-20 15:30", active: false, expiry: "", scopes: ["v1", "v2"] }
  ],
  logs: [
    { id: 1, type: "order", action: "สร้างคำสั่งซื้อ ORD-001", user: "gamer_pro", time: "2026-11-12 09:15:00" },
    { id: 2, type: "topup", action: "อนุมัติ TXN-001", user: "Admin", time: "2026-11-12 09:12:00" }
  ],
  settings: {
    brandName: "NEARBYSHOP", brandSub: "Control Center",
    siteEmail: "support@nearbyshop.xyz", sitePhone: "02-123-4567", siteDiscord: "https://discord.gg/nearbyshop",
    tmFee: 2.9, minTopup: 0,
    colors: { bg: "#090d17", panel: "#151820", panel2: "#11141e", panel3: "#0d111a", line: "#252a38", muted: "#929bb0", accent: "#5036ef", accentLight: "#8b92ff", green: "#10b981", amber: "#f59e0b", red: "#ef4444" },
    logoDataUrl: null,
    bankAccounts: [
      { id: 1, name: "ธนาคารกสิกรไทย", acc: "214-8-29425-1", owner: "นาย ปุณญพัฒน์ เครือบุญ", note: "บัญชีหลัก" }
    ]
  }
};

function loadData(key) {
  const raw = store.get('nbadmin7_' + key);
  if (raw) { try { return JSON.parse(raw); } catch (e) {} }
  return JSON.parse(JSON.stringify(SEED[key]));
}
function saveData(key, data) { store.set('nbadmin7_' + key, JSON.stringify(data)); if (typeof updateNavBadges === 'function' && typeof sidebar !== 'undefined') updateNavBadges(); }

let games = loadData('games');
let users = loadData('users');
let orders = loadData('orders');
let topups = loadData('topups');
let redeemCodes = loadData('redeemCodes');
let coupons = loadData('coupons');
let news = loadData('news');
let apiKeys = loadData('apiKeys');
let logs = loadData('logs');
let settings = loadData('settings');

/* ============ NAV / LAYOUT (shared by every page) ============ */
const PAGE_TITLES = { dashboard: 'แดชบอร์ด', analytics: 'วิเคราะห์ข้อมูล', games: 'เกม & แพ็กเกจ', orders: 'คำสั่งซื้อ', users: 'ผู้ใช้', topups: 'เติมเงิน', redeem: 'โค้ดแลกรางวัล', coupons: 'คูปองส่วนลด', news: 'ข่าวสาร', history: 'ประวัติการทำรายการ', health: 'สถานะระบบ', api: 'API Keys', logs: 'บันทึกระบบ', settings: 'ตั้งค่าระบบ' };
const PAGE_URLS = { dashboard: 'index.html', analytics: 'analytics.html', games: 'games.html', orders: 'orders.html', users: 'users.html', topups: 'topups.html', redeem: 'redeem.html', coupons: 'coupons.html', news: 'news.html', history: 'history.html', health: 'health.html', api: 'api.html', logs: 'logs.html', settings: 'settings.html' };
const CURRENT_PAGE = document.body.dataset.page || 'dashboard';

/* ไปหน้าอื่น (รองรับ query เช่น navigate('orders', { status: 'pending' })) */
function navigate(page, query) {
  if (!PAGE_URLS[page]) return;
  let url = PAGE_URLS[page];
  if (query) url += '?' + new URLSearchParams(query).toString();
  window.location.href = url;
}

const SIDEBAR_HTML = `
<div class="sidebar-brand">
  <svg class="brand-logo" id="brand-logo-svg" viewBox="0 0 120 76" aria-hidden="true">
    <defs><linearGradient id="nbg" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#6b55ff"/><stop offset="1" stop-color="#3a22c8"/></linearGradient></defs>
    <path d="M24 8C14 8 10 16 8 28L2 52C-1 66 8 74 18 72 26 70 30 62 34 54H86C90 62 94 70 102 72 112 74 121 66 118 52L112 28C110 16 106 8 96 8Z" fill="url(#nbg)" stroke="#d9d4ff" stroke-width="3" stroke-linejoin="round"/>
    <path d="M27 20h6v5h5v6h-5v5h-6v-5h-5v-6h5z" fill="#fff"/>
    <circle cx="90" cy="22" r="3" fill="#fff"/><circle cx="98" cy="28" r="3" fill="#fff"/><circle cx="90" cy="34" r="3" fill="#fff"/><circle cx="82" cy="28" r="3" fill="#fff"/>
    <path d="M56 21l9 5-9 5z" fill="#b9b0ff"/>
    <circle cx="46" cy="40" r="5" fill="#2a1aa5" stroke="#fff" stroke-width="1.6"/><circle cx="74" cy="40" r="5" fill="#2a1aa5" stroke="#fff" stroke-width="1.6"/>
    <path d="M13 66V44l18 22V44" fill="none" stroke="#1a1180" stroke-width="11" stroke-linecap="round" stroke-linejoin="round"/>
    <path d="M89 44h9a5.5 5.5 0 0 1 0 11h-9m0 0h11a5.5 5.5 0 0 1 0 11H89V44" fill="none" stroke="#1a1180" stroke-width="11" stroke-linecap="round" stroke-linejoin="round"/>
    <path d="M13 66V44l18 22V44" fill="none" stroke="#fff" stroke-width="6" stroke-linecap="round" stroke-linejoin="round"/>
    <path d="M89 44h9a5.5 5.5 0 0 1 0 11h-9m0 0h11a5.5 5.5 0 0 1 0 11H89V44" fill="none" stroke="#fff" stroke-width="6" stroke-linecap="round" stroke-linejoin="round"/>
  </svg>
  <img id="brand-logo-img" class="brand-logo custom-logo hidden" alt="Logo">
  <div>
    <div class="brand-name" id="brand-name-el">NEARBY<span>SHOP</span></div>
    <div class="brand-sub" id="brand-sub-el">Control Center</div>
  </div>
</div>

<div class="nav-group">
  <div class="nav-label">ภาพรวม</div>
  <a href="index.html" class="nav-item" data-page="dashboard">
    <svg viewBox="0 0 24 24"><rect width="7" height="9" x="3" y="3" rx="1"/><rect width="7" height="5" x="14" y="3" rx="1"/><rect width="7" height="9" x="14" y="12" rx="1"/><rect width="7" height="5" x="3" y="16" rx="1"/></svg>
    แดชบอร์ด
  </a>
  <a href="analytics.html" class="nav-item" data-page="analytics">
    <svg viewBox="0 0 24 24"><path d="M3 3v18h18"/><path d="m19 9-5 5-4-4-3 3"/></svg>
    วิเคราะห์ข้อมูล
  </a>
</div>

<div class="nav-group">
  <div class="nav-label">จัดการร้านค้า</div>
  <a href="games.html" class="nav-item" data-page="games">
    <svg viewBox="0 0 24 24"><rect width="18" height="18" x="3" y="3" rx="2"/><path d="M3 9h18"/><path d="M3 15h18"/><path d="M9 3v18"/><path d="M15 3v18"/></svg>
    เกม &amp; แพ็กเกจ
    <span class="badge-count" id="nav-game-count">0</span>
  </a>
  <a href="orders.html" class="nav-item" data-page="orders">
    <svg viewBox="0 0 24 24"><path d="M4 2v20l2-1 2 1 2-1 2 1 2-1 2 1 2-1 2 1V2l-2 1-2-1-2 1-2-1-2 1-2-1-2 1Z"/><path d="M14 8H8"/><path d="M16 12H8"/><path d="M13 16H8"/></svg>
    คำสั่งซื้อ
    <span class="badge-count amber" id="nav-order-count">0</span>
  </a>
  <a href="users.html" class="nav-item" data-page="users">
    <svg viewBox="0 0 24 24"><path d="M19 21v-2a4 4 0 0 0-4-4H9a4 4 0 0 0-4 4v2"/><circle cx="12" cy="7" r="4"/></svg>
    ผู้ใช้
    <span class="badge-count" id="nav-user-count">0</span>
  </a>
  <a href="topups.html" class="nav-item" data-page="topups">
    <svg viewBox="0 0 24 24"><path d="M17 14h.01"/><path d="M7 7h12a2 2 0 0 1 2 2v10a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h14"/></svg>
    เติมเงิน
    <span class="badge-count amber" id="nav-topup-count">0</span>
  </a>
</div>

<div class="nav-group">
  <div class="nav-label">โปรโมชั่น</div>
  <a href="redeem.html" class="nav-item" data-page="redeem">
    <svg viewBox="0 0 24 24"><rect x="3" y="8" width="18" height="4" rx="1"/><path d="M12 8v13"/><path d="M19 12v7a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2v-7"/><path d="M7.5 8a2.5 2.5 0 0 1 0-5A4.8 8 0 0 1 12 8a4.8 8 0 0 1 4.5-5 2.5 2.5 0 0 1 0 5"/></svg>
    โค้ดแลกรางวัล
  </a>
  <a href="coupons.html" class="nav-item" data-page="coupons">
    <svg viewBox="0 0 24 24"><path d="M20.59 13.41l-7.17 7.17a2 2 0 0 1-2.83 0L2 12V2h10l8.59 8.59a2 2 0 0 1 0 2.82z"/><line x1="7" y1="7" x2="7.01" y2="7"/></svg>
    คูปองส่วนลด
  </a>
</div>

<div class="nav-group">
  <div class="nav-label">เนื้อหา</div>
  <a href="news.html" class="nav-item" data-page="news">
    <svg viewBox="0 0 24 24"><path d="M4 22h16a2 2 0 0 0 2-2V4a2 2 0 0 0-2-2H8a2 2 0 0 0-2 2v16a2 2 0 0 1-2 2Zm0 0a2 2 0 0 1-2-2v-9c0-1.1.9-2 2-2h2"/><path d="M18 14h-8"/><path d="M15 18h-5"/><path d="M10 6h8v4h-8V6Z"/></svg>
    ข่าวสาร / บทความ
    <span class="badge-count" id="nav-news-count">0</span>
  </a>
</div>

<div class="nav-group">
  <div class="nav-label">ระบบ</div>
  <a href="history.html" class="nav-item" data-page="history">
    <svg viewBox="0 0 24 24"><path d="M3 12a9 9 0 1 0 3-6.74L3 8"/><path d="M3 3v5h5"/><path d="M12 7v5l4 2"/></svg>
    ประวัติการทำรายการ
  </a>
  <a href="health.html" class="nav-item" data-page="health">
    <svg viewBox="0 0 24 24"><path d="M22 12h-4l-3 9L9 3l-3 9H2"/></svg>
    สถานะระบบ
  </a>
</div>

<div class="nav-group">
  <div class="nav-label">นักพัฒนา</div>
  <a href="api.html" class="nav-item" data-page="api">
    <svg viewBox="0 0 24 24"><path d="m18 16 4-4-4-4"/><path d="m6 8-4 4 4 4"/><path d="m14.5 4-5 16"/></svg>
    API Keys
    <span class="badge-count" id="nav-api-count">0</span>
  </a>
  <a href="logs.html" class="nav-item" data-page="logs">
    <svg viewBox="0 0 24 24"><path d="M15 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V7Z"/><path d="M14 2v4a2 2 0 0 0 2 2h4"/><path d="M10 9H8"/><path d="M16 13H8"/><path d="M16 17H8"/></svg>
    บันทึกระบบ
  </a>
  <a href="settings.html" class="nav-item" data-page="settings">
    <svg viewBox="0 0 24 24"><path d="M12.22 2h-.44a2 2 0 0 0-2 2v.18a2 2 0 0 1-1 1.73l-.43.25a2 2 0 0 1-2 0l-.15-.08a2 2 0 0 0-2.73.73l-.22.38a2 2 0 0 0 .73 2.73l.15.1a2 2 0 0 1 1 1.72v.51a2 2 0 0 1-1 1.74l-.15.09a2 2 0 0 0-.73 2.73l.22.38a2 2 0 0 0 2.73.73l.15-.08a2 2 0 0 1 2 0l.43.25a2 2 0 0 1 1 1.73V20a2 2 0 0 0 2 2h.44a2 2 0 0 0 2-2v-.18a2 2 0 0 1 1-1.73l.43-.25a2 2 0 0 1 2 0l.15.08a2 2 0 0 0 2.73-.73l.22-.39a2 2 0 0 0-.73-2.73l-.15-.08a2 2 0 0 1-1-1.74v-.5a2 2 0 0 1 1-1.74l.15-.09a2 2 0 0 0 .73-2.73l-.22-.38a2 2 0 0 0-2.73-.73l-.15.08a2 2 0 0 1-2 0l-.43-.25a2 2 0 0 1-1-1.73V4a2 2 0 0 0-2-2z"/><circle cx="12" cy="12" r="3"/></svg>
    ตั้งค่าระบบ
  </a>
</div>

<div class="sidebar-footer">
  <div class="user-avatar"><svg viewBox="0 0 24 24"><path d="M19 21v-2a4 4 0 0 0-4-4H9a4 4 0 0 0-4 4v2"/><circle cx="12" cy="7" r="4"/></svg></div>
  <div class="user-info"><div class="user-name">Admin</div><div class="user-role">ผู้ดูแลระบบ</div></div>
  <button class="logout-btn" onclick="handleLogout()" title="ออกจากระบบ"><svg viewBox="0 0 24 24"><path d="M9 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h4"/><polyline points="16 17 21 12 16 7"/><line x1="21" x2="9" y1="12" y2="12"/></svg></button>
</div>
`;

const CONFIRM_MODAL_HTML = `
<div class="modal-overlay" id="confirm-modal"><div class="modal-box" style="max-width: 400px;"><div class="modal-head"><h2 id="confirm-title">ยืนยันการลบ</h2><button class="modal-close" onclick="closeConfirmModal()"><svg viewBox="0 0 24 24"><path d="M18 6 6 18"/><path d="m6 6 12 12"/></svg></button></div>
<p id="confirm-message" style="font-size: 13px; color: var(--muted); line-height: 1.6;"></p>
<div class="form-group" style="margin-top: 14px;"><label class="form-label">พิมพ์ <span style="color: var(--red); font-family: monospace;" id="confirm-word"></span> เพื่อยืนยัน</label><input type="text" class="form-input" id="confirm-input" autocomplete="off"></div>
<div class="modal-actions"><button class="btn btn-secondary" onclick="closeConfirmModal()">ยกเลิก</button><button class="btn btn-danger" onclick="executeConfirm()">ยืนยันลบ</button></div></div></div>
`;

function buildLayout() {
  const body = document.body;
  body.insertAdjacentHTML('afterbegin',
    '<div class="overlay-bg" id="overlay-bg"></div>' +
    '<aside class="sidebar" id="sidebar">' + SIDEBAR_HTML + '</aside>');
  const mainWrap = document.querySelector('.main-wrap');
  if (mainWrap) mainWrap.insertAdjacentHTML('afterbegin',
    '<div class="topbar"><button class="hamburger" id="hamburger"><svg viewBox="0 0 24 24"><line x1="3" y1="12" x2="21" y2="12"/><line x1="3" y1="6" x2="21" y2="6"/><line x1="3" y1="18" x2="21" y2="18"/></svg></button>' +
    '<span class="topbar-title" id="topbar-title">' + PAGE_TITLES[CURRENT_PAGE] + '</span></div>');
  body.insertAdjacentHTML('beforeend', CONFIRM_MODAL_HTML + '<div class="toast-container" id="toast-container"></div>');
  document.querySelectorAll('.nav-item[data-page]').forEach(a => a.classList.toggle('active', a.dataset.page === CURRENT_PAGE));
}
buildLayout();

const sidebar = document.getElementById('sidebar');
const overlayBg = document.getElementById('overlay-bg');
function openSidebar() { sidebar.classList.add('open'); overlayBg.classList.add('active'); }
function closeSidebar() { sidebar.classList.remove('open'); overlayBg.classList.remove('active'); }
document.getElementById('hamburger').addEventListener('click', openSidebar);
overlayBg.addEventListener('click', closeSidebar);

/* badge ตัวเลขใน sidebar — อัปเดตทุกหน้า */
function updateNavBadges() {
  const set = (id, v) => { const el = document.getElementById(id); if (el) el.textContent = v; };
  set('nav-game-count', games.length);
  set('nav-order-count', orders.filter(o => o.status === 'pending').length);
  set('nav-user-count', users.length);
  set('nav-topup-count', topups.filter(t => t.status === 'pending').length);
  set('nav-api-count', apiKeys.length);
  set('nav-news-count', news.length);
}

/* ============ TOAST ============ */
function toast(msg, type = 'success') {
  const container = document.getElementById('toast-container');
  const el = document.createElement('div');
  el.className = 'toast ' + type;
  let icon = '';
  if (type === 'success') icon = '<svg viewBox="0 0 24 24" fill="none" stroke="#10b981" stroke-width="2"><polyline points="20 6 9 17 4 12"/></svg>';
  else if (type === 'error') icon = '<svg viewBox="0 0 24 24" fill="none" stroke="#ef4444" stroke-width="2"><circle cx="12" cy="12" r="10"/><line x1="15" y1="9" x2="9" y2="15"/><line x1="9" y1="9" x2="15" y2="15"/></svg>';
  else icon = '<svg viewBox="0 0 24 24" fill="none" stroke="#8b92ff" stroke-width="2"><circle cx="12" cy="12" r="10"/><line x1="12" y1="16" x2="12" y2="12"/><line x1="12" y1="8" x2="12.01" y2="8"/></svg>';
  el.innerHTML = icon + '<span>' + msg + '</span>';
  container.appendChild(el);
  setTimeout(() => { el.style.opacity = '0'; el.style.transition = 'opacity .3s'; setTimeout(() => el.remove(), 300); }, 2800);
}

/* ============ HELPERS ============ */
const esc = s => String(s).replace(/[&<>"']/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const fmtMoney = n => '฿' + Number(n).toLocaleString('en-US', { minimumFractionDigits: 0, maximumFractionDigits: 2 });
const todayStr = () => '2026-11-12';

function addLog(type, action, user) {
  const now = new Date();
  const time = `2026-11-12 ${String(now.getHours()).padStart(2,'0')}:${String(now.getMinutes()).padStart(2,'0')}:${String(now.getSeconds()).padStart(2,'0')}`;
  logs.unshift({ id: logs.length + 1, type, action, user: user || 'Admin', time });
  if (logs.length > 200) logs = logs.slice(0, 200);
  saveData('logs', logs);
}

function applyTheme() {
  const c = settings.colors;
  const root = document.documentElement.style;
  ['bg','panel','panel2','panel3','line','muted','accent','accentLight','green','amber','red'].forEach(k => root.setProperty('--' + k.replace(/[A-Z]/g, m => '-' + m.toLowerCase()), c[k]));
  const brandEl = document.getElementById('brand-name-el');
  if (brandEl) { const name = settings.brandName || 'NEARBYSHOP'; if (name.length > 6) brandEl.innerHTML = name.slice(0,6) + '<span>' + name.slice(6) + '</span>'; else brandEl.innerHTML = name; }
  const subEl = document.getElementById('brand-sub-el');
  if (subEl) subEl.textContent = settings.brandSub || 'Control Center';
  const svgLogo = document.getElementById('brand-logo-svg');
  const imgLogo = document.getElementById('brand-logo-img');
  if (settings.logoDataUrl) { svgLogo.classList.add('hidden'); imgLogo.classList.remove('hidden'); imgLogo.src = settings.logoDataUrl; }
  else { svgLogo.classList.remove('hidden'); imgLogo.classList.add('hidden'); }
  const meta = document.querySelector('meta[name="theme-color"]');
  if (meta) meta.setAttribute('content', c.bg);
}

/* ============ CONFIRM MODAL ============ */
let confirmAction = null;
function openConfirmModal(title, message, word, callback) {
  document.getElementById('confirm-title').textContent = title;
  document.getElementById('confirm-message').textContent = message;
  document.getElementById('confirm-word').textContent = word;
  document.getElementById('confirm-input').value = '';
  confirmAction = callback;
  document.getElementById('confirm-modal').classList.add('active');
}
function closeConfirmModal() { document.getElementById('confirm-modal').classList.remove('active'); confirmAction = null; }
function executeConfirm() {
  const word = document.getElementById('confirm-word').textContent;
  const input = document.getElementById('confirm-input').value.trim();
  if (input !== word) { toast('ข้อความยืนยันไม่ถูกต้อง', 'error'); return; }
  if (confirmAction) { const cb = confirmAction; closeConfirmModal(); cb(); }
}

/* ============ DASHBOARD ============ */
function renderDashboard() {
  if (!document.getElementById('page-dashboard')) return;
  document.getElementById('dash-date').textContent = 'ภาพรวมระบบ NearbyShop — ข้อมูล ณ วันที่ 12 พ.ย. 2569';
  const today = todayStr();
  const todayOrders = orders.filter(o => o.date.startsWith(today) && o.status === 'success');
  const revenue = todayOrders.reduce((s, o) => s + o.amount, 0);
  document.getElementById('stat-revenue').textContent = fmtMoney(revenue);
  document.getElementById('stat-orders-today').textContent = todayOrders.length;
  document.getElementById('stat-users').textContent = users.length;
  document.getElementById('stat-users-new').textContent = users.filter(u => u.date === today).length;
  const todayTopups = topups.filter(t => t.date.startsWith(today) && t.status === 'success');
  document.getElementById('stat-topup').textContent = fmtMoney(todayTopups.reduce((s, t) => s + t.amount, 0));
  document.getElementById('stat-topup-count').textContent = todayTopups.length;
  document.getElementById('stat-keys').textContent = apiKeys.filter(k => k.active).length;
  document.getElementById('stat-key-users').textContent = apiKeys.length;
  document.getElementById('stat-pending').textContent = orders.filter(o => o.status === 'pending').length;
  document.getElementById('stat-topup-pending').textContent = topups.filter(t => t.status === 'pending').length;
  document.getElementById('stat-codes').textContent = redeemCodes.filter(r => r.used < r.qty).length;
  document.getElementById('stat-codes-total').textContent = redeemCodes.length;
  document.getElementById('stat-coupons').textContent = coupons.filter(c => c.used < c.qty).length;
  document.getElementById('stat-coupons-total').textContent = coupons.length;
  document.getElementById('nav-game-count').textContent = games.length;
  document.getElementById('nav-order-count').textContent = orders.filter(o => o.status === 'pending').length;
  document.getElementById('nav-user-count').textContent = users.length;
  document.getElementById('nav-topup-count').textContent = topups.filter(t => t.status === 'pending').length;
  document.getElementById('nav-api-count').textContent = apiKeys.length;
  document.getElementById('nav-news-count').textContent = news.length;

  const alertsEl = document.getElementById('pending-alerts');
  const pendingOrders = orders.filter(o => o.status === 'pending').length;
  const pendingTopups = topups.filter(t => t.status === 'pending').length;
  let alertsHtml = '';
  if (pendingOrders > 0) alertsHtml += `<div style="background: rgba(245,158,11,.1); border: 1px solid rgba(245,158,11,.3); border-radius: 10px; padding: 11px 14px; margin-bottom: 10px; display: flex; align-items: center; gap: 10px; flex-wrap: wrap;">
    <svg viewBox="0 0 24 24" fill="none" stroke="#f59e0b" stroke-width="2" style="width:18px;height:18px;flex-shrink:0"><circle cx="12" cy="12" r="10"/><polyline points="12 6 12 12 16 14"/></svg>
    <span style="flex:1;font-size:12.5px;"><b>${pendingOrders}</b> คำสั่งซื้อรอตรวจสอบ</span>
    <button class="btn btn-sm" style="background:var(--amber);color:#000;" onclick="navigate('orders', { status: 'pending' })">ดูเลย</button>
  </div>`;
  if (pendingTopups > 0) alertsHtml += `<div style="background: rgba(6,182,212,.1); border: 1px solid rgba(6,182,212,.3); border-radius: 10px; padding: 11px 14px; margin-bottom: 10px; display: flex; align-items: center; gap: 10px; flex-wrap: wrap;">
    <svg viewBox="0 0 24 24" fill="none" stroke="#06b6d4" stroke-width="2" style="width:18px;height:18px;flex-shrink:0"><path d="M12 2v20M17 5H9.5a3.5 3.5 0 0 0 0 7h5a3.5 3.5 0 0 1 0 7H6"/></svg>
    <span style="flex:1;font-size:12.5px;"><b>${pendingTopups}</b> รายการเติมเงินรออนุมัติ</span>
    <button class="btn btn-sm" style="background:var(--cyan);color:#000;" onclick="navigate('topups', { status: 'pending' })">ดูเลย</button>
  </div>`;
  alertsEl.innerHTML = alertsHtml;

  const days = ['6 พ.ย.','7 พ.ย.','8 พ.ย.','9 พ.ย.','10 พ.ย.','11 พ.ย.','12 พ.ย.'];
  const values = [1200, 1800, 950, 2100, 1600, 2400, revenue || 1500];
  const max = Math.max(...values, 1);
  document.getElementById('dash-chart').innerHTML = days.map((d, i) => `<div class="chart-bar-col"><div class="chart-bar-val">฿${values[i].toLocaleString()}</div><div class="chart-bar" style="height: ${Math.round((values[i]/max)*115)}px;"></div><div class="chart-bar-label">${d}</div></div>`).join('');

  const recent = [...orders].sort((a, b) => b.date.localeCompare(a.date)).slice(0, 6);
  document.getElementById('dash-recent-orders').innerHTML = recent.length ? recent.map(o => {
    const badge = o.status === 'success' ? 'green' : o.status === 'pending' ? 'amber' : 'red';
    const label = o.status === 'success' ? 'สำเร็จ' : o.status === 'pending' ? 'รอ' : 'ล้มเหลว';
    return `<div style="display:flex;justify-content:space-between;align-items:center;padding:6px 0;border-bottom:1px solid var(--line2);">
      <div style="min-width:0;flex:1;"><div style="font-weight:500;font-size:11.5px;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;">${esc(o.user)}</div><div style="font-size:10px;color:var(--muted);white-space:nowrap;overflow:hidden;text-overflow:ellipsis;">${esc(o.product.split('—')[0].trim())}</div></div>
      <div style="text-align:right;flex-shrink:0;margin-left:8px;"><span class="badge ${badge}">${label}</span><div style="font-size:10px;color:var(--muted);margin-top:1px;">${fmtMoney(o.amount)}</div></div>
    </div>`;
  }).join('') : '<div class="empty-state"><p>ไม่มีคำสั่งซื้อ</p></div>';

  const popular = games.filter(g => g.popular).slice(0, 8);
  document.getElementById('dash-popular-games').innerHTML = popular.length ? `<table><thead><tr><th>รูป</th><th>เกม</th><th>แพ็กเกจ</th><th>สถานะ</th></tr></thead><tbody>${popular.map(g => `<tr><td>${g.cover ? `<img src="${g.cover}" style="width:32px;height:32px;border-radius:6px;object-fit:cover;">` : '<div style="width:32px;height:32px;border-radius:6px;background:var(--panel3);display:flex;align-items:center;justify-content:center;font-size:10px;color:var(--muted);">—</div>'}</td><td class="cell-title">${esc(g.name)}</td><td>${g.packs.length}</td><td>${g.active ? '<span class="badge green">เปิด</span>' : '<span class="badge red">ปิด</span>'}</td></tr>`).join('')}</tbody></table>` : '<div class="empty-state"><p>ไม่มีเกมยอดนิยม</p></div>';

  fixResponsive();
}

function refreshDashboard() { renderDashboard(); toast('รีเฟรชข้อมูลแดชบอร์ดแล้ว'); }

/* ============ ANALYTICS ============ */
function renderAnalytics() {
  if (!document.getElementById('page-analytics')) return;
  const period = parseInt(document.getElementById('analytics-period').value) || 7;
  const days = period === 7 ? ['6 พ.ย.','7 พ.ย.','8 พ.ย.','9 พ.ย.','10 พ.ย.','11 พ.ย.','12 พ.ย.'] : Array.from({length: period === 30 ? 30 : 12}, (_, i) => period === 30 ? `${i+1} พ.ย.` : `สัปดาห์ ${i+1}`);
  const baseValues = period === 7 ? [1200, 1800, 950, 2100, 1600, 2400, 1800] : Array.from({length: period === 30 ? 30 : 12}, () => Math.floor(Math.random() * 2000) + 500);
  const totalRevenue = baseValues.reduce((s, v) => s + v, 0);
  const totalOrders = Math.floor(totalRevenue / 120);
  const avgOrder = Math.floor(totalRevenue / totalOrders);
  document.getElementById('an-revenue').textContent = fmtMoney(totalRevenue);
  document.getElementById('an-revenue-note').innerHTML = `<span style="color:var(--green);">↑ 12.5%</span> เทียบช่วงก่อน`;
  document.getElementById('an-orders').textContent = totalOrders.toLocaleString();
  document.getElementById('an-orders-note').innerHTML = `<span style="color:var(--green);">↑ 8.3%</span> เทียบช่วงก่อน`;
  document.getElementById('an-avg').textContent = fmtMoney(avgOrder);
  document.getElementById('an-avg-note').innerHTML = `<span style="color:var(--green);">↑ 3.2%</span> เทียบช่วงก่อน`;
  const max = Math.max(...baseValues, 1);
  document.getElementById('analytics-chart').innerHTML = days.map((d, i) => `<div class="chart-bar-col"><div class="chart-bar-val">฿${baseValues[i].toLocaleString()}</div><div class="chart-bar" style="height: ${Math.round((baseValues[i]/max)*140)}px;"></div><div class="chart-bar-label">${d}</div></div>`).join('');
  const catOnline = orders.filter(o => o.product.includes('Free Fire') || o.product.includes('RoV') || o.product.includes('Mobile Legends') || o.product.includes('Genshin'));
  const catCard = orders.filter(o => !catOnline.includes(o));
  const catTotal = orders.length || 1;
  document.getElementById('analytics-categories').innerHTML = `
    <div style="display:flex;flex-direction:column;gap:9px;">
      <div><div style="display:flex;justify-content:space-between;font-size:11.5px;margin-bottom:4px;"><span>เติมเกมออนไลน์</span><b>${Math.round(catOnline.length/catTotal*100)}%</b></div><div style="height:7px;background:var(--panel3);border-radius:4px;overflow:hidden;"><div style="height:100%;width:${Math.round(catOnline.length/catTotal*100)}%;background:var(--accent);border-radius:4px;"></div></div></div>
      <div><div style="display:flex;justify-content:space-between;font-size:11.5px;margin-bottom:4px;"><span>บัตรเติมเงิน &amp; วอลเล็ต</span><b>${Math.round(catCard.length/catTotal*100)}%</b></div><div style="height:7px;background:var(--panel3);border-radius:4px;overflow:hidden;"><div style="height:100%;width:${Math.round(catCard.length/catTotal*100)}%;background:var(--green);border-radius:4px;"></div></div></div>
    </div>`;
  const methods = {};
  topups.forEach(t => { methods[t.method] = (methods[t.method] || 0) + t.amount; });
  const methodTotal = Object.values(methods).reduce((s, v) => s + v, 0) || 1;
  const methodColors = { 'TrueMoney': 'var(--amber)', 'ธนาคาร': 'var(--accent)', 'Voucher': 'var(--green)' };
  document.getElementById('analytics-methods').innerHTML = Object.entries(methods).map(([name, amount]) => `<div style="margin-bottom:9px;"><div style="display:flex;justify-content:space-between;font-size:11.5px;margin-bottom:4px;"><span>${esc(name)}</span><b>${fmtMoney(amount)}</b></div><div style="height:7px;background:var(--panel3);border-radius:4px;overflow:hidden;"><div style="height:100%;width:${Math.round(amount/methodTotal*100)}%;background:${methodColors[name] || 'var(--accent)'};border-radius:4px;"></div></div></div>`).join('') || '<div class="empty-state"><p>ไม่มีข้อมูล</p></div>';
  fixResponsive();
}

/* ============ GAMES (with cover) ============ */
let editingGameId = null;
let currentGameCover = null;

function renderGamesTable() {
  if (!document.getElementById('page-games')) return;
  const q = (document.getElementById('game-search-admin')?.value || '').toLowerCase();
  const filtered = games.filter(g => g.name.toLowerCase().includes(q) || g.cat.toLowerCase().includes(q));
  document.getElementById('game-count').textContent = games.length;
  document.getElementById('nav-game-count').textContent = games.length;
  document.getElementById('games-tbody').innerHTML = filtered.length ? filtered.map(g => `
    <tr>
      <td>${g.cover ? `<img src="${g.cover}" class="game-cover-thumb" alt="">` : '<div style="width:40px;height:40px;border-radius:8px;background:var(--panel3);display:flex;align-items:center;justify-content:center;font-size:10px;color:var(--muted);">—</div>'}</td>
      <td class="cell-title">${esc(g.name)}</td>
      <td><span class="badge indigo">${esc(g.cat)}</span></td>
      <td>${g.active ? '<span class="badge green">เปิด</span>' : '<span class="badge red">ปิด</span>'}</td>
      <td><button class="btn btn-secondary btn-sm" onclick="openPkgModal(${g.id})"><svg viewBox="0 0 24 24" style="width:12px;height:12px"><path d="M11 21.73a2 2 0 0 0 2 0l7-4A2 2 0 0 0 21 16V8a2 2 0 0 0-1-1.73l-7-4a2 2 0 0 0-2 0l-7 4A2 2 0 0 0 3 8v8a2 2 0 0 0 1 1.73z"/><path d="M12 22V12"/></svg>${g.packs.length} แพ็กเกจ</button></td>
      <td><div class="table-actions">
        <button class="btn-icon ${g.active ? 'warn' : 'success'}" onclick="toggleGameActive(${g.id})" title="${g.active ? 'ปิด' : 'เปิด'}">${g.active ? '<svg viewBox="0 0 24 24"><path d="M18.36 6.64a9 9 0 1 1-12.73 0"/><line x1="12" y1="2" x2="12" y2="12"/></svg>' : '<svg viewBox="0 0 24 24"><path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z"/><polyline points="9 12 11 14 15 10"/></svg>'}</button>
        <button class="btn-icon primary" onclick="editGame(${g.id})" title="แก้ไข"><svg viewBox="0 0 24 24"><path d="M21.174 6.812a1 1 0 0 0-3.986-3.987L3.842 16.174a2 2 0 0 0-.5.83l-1.321 4.352a.5.5 0 0 0 .623.622l4.353-1.32a2 2 0 0 0 .83-.497z"/><path d="m15 5 4 4"/></svg></button>
        <button class="btn-icon danger" onclick="deleteGame(${g.id})" title="ลบ"><svg viewBox="0 0 24 24"><path d="M3 6h18"/><path d="M19 6v14c0 1-1 2-2 2H7c-1 0-2-1-2-2V6"/><path d="M8 6V4c0-1 1-2 2-2h4c1 0 2 1 2 2v2"/></svg></button>
      </div></td>
    </tr>`).join('') : '<tr><td colspan="6"><div class="empty-state"><p>ไม่พบเกม</p></div></td></tr>';
}

function openGameModal() {
  editingGameId = null;
  currentGameCover = null;
  document.getElementById('game-modal-title').textContent = 'เพิ่มเกมใหม่';
  document.getElementById('game-name-input').value = '';
  document.getElementById('game-cat-input').value = 'เติมเกมออนไลน์';
  document.getElementById('game-tag-input').value = '';
  document.getElementById('game-sub-input').value = '';
  document.getElementById('game-popular-input').value = 'false';
  document.getElementById('game-active-input').value = 'true';
  document.getElementById('game-cover-preview').classList.remove('show');
  document.getElementById('game-cover-upload').value = '';
  document.getElementById('game-modal').classList.add('active');
}

function editGame(id) {
  const g = games.find(x => x.id === id); if (!g) return;
  editingGameId = id;
  currentGameCover = g.cover || null;
  document.getElementById('game-modal-title').textContent = 'แก้ไข: ' + g.name;
  document.getElementById('game-name-input').value = g.name;
  document.getElementById('game-cat-input').value = g.cat;
  document.getElementById('game-tag-input').value = g.tag || '';
  document.getElementById('game-sub-input').value = g.sub || '';
  document.getElementById('game-popular-input').value = g.popular ? 'true' : 'false';
  document.getElementById('game-active-input').value = g.active ? 'true' : 'false';
  const prev = document.getElementById('game-cover-preview');
  if (g.cover) { prev.src = g.cover; prev.classList.add('show'); } else { prev.classList.remove('show'); }
  document.getElementById('game-cover-upload').value = '';
  document.getElementById('game-modal').classList.add('active');
}

function closeGameModal() { document.getElementById('game-modal').classList.remove('active'); editingGameId = null; currentGameCover = null; }

function handleGameCoverUpload(input) {
  const f = input.files && input.files[0]; if (!f) return;
  if (!/^image\/(png|jpeg|webp)$/.test(f.type)) { Swal.fire({ title: 'ไฟล์ไม่รองรับ', text: 'กรุณาเลือก PNG, JPG หรือ WebP', icon: 'error', confirmButtonText: 'ตกลง' }); input.value = ''; return; }
  if (f.size > 2 * 1024 * 1024) { Swal.fire({ title: 'ไฟล์ใหญ่เกินไป', text: 'ขนาดต้องไม่เกิน 2 MB', icon: 'error', confirmButtonText: 'ตกลง' }); input.value = ''; return; }
  const reader = new FileReader();
  reader.onload = e => {
    currentGameCover = e.target.result;
    const prev = document.getElementById('game-cover-preview');
    prev.src = e.target.result; prev.classList.add('show');
    toast('อัปโหลดรูปปกเรียบร้อย');
  };
  reader.readAsDataURL(f);
}

function removeGameCover() {
  currentGameCover = null;
  document.getElementById('game-cover-preview').classList.remove('show');
  document.getElementById('game-cover-upload').value = '';
  toast('ลบรูปปกเรียบร้อย');
}

function saveGame() {
  const name = document.getElementById('game-name-input').value.trim();
  if (!name) { Swal.fire({ title: 'ผิดพลาด', text: 'กรุณาระบุชื่อเกม', icon: 'warning', confirmButtonText: 'ตกลง' }); return; }
  const cat = document.getElementById('game-cat-input').value;
  const tag = document.getElementById('game-tag-input').value.trim();
  const sub = document.getElementById('game-sub-input').value.trim();
  const popular = document.getElementById('game-popular-input').value === 'true';
  const active = document.getElementById('game-active-input').value === 'true';
  if (editingGameId) {
    const g = games.find(x => x.id === editingGameId);
    if (g) { g.name = name; g.cat = cat; g.tag = tag; g.sub = sub; g.popular = popular; g.active = active; g.cover = currentGameCover; }
    addLog('game', `แก้ไขเกม "${name}"`, 'Admin');
    toast('อัปเดตเกมเรียบร้อย');
  } else {
    const newId = Math.max(...games.map(g => g.id), 0) + 1;
    games.push({ id: newId, name, cat, tag, sub, popular, active, cover: currentGameCover, packs: [] });
    addLog('game', `เพิ่มเกม "${name}"`, 'Admin');
    toast('เพิ่มเกมเรียบร้อย');
  }
  saveData('games', games);
  closeGameModal();
  renderGamesTable();
  renderDashboard();
}

function toggleGameActive(id) {
  const g = games.find(x => x.id === id); if (!g) return;
  g.active = !g.active;
  saveData('games', games);
  addLog('game', `${g.active ? 'เปิด' : 'ปิด'}ขายเกม "${g.name}"`, 'Admin');
  renderGamesTable(); renderDashboard();
  toast(`เกม "${g.name}" ถูก${g.active ? 'เปิด' : 'ปิด'}ขาย`);
}

function deleteGame(id) {
  const g = games.find(x => x.id === id); if (!g) return;
  openConfirmModal('ลบเกม?', `ต้องการลบ "${g.name}" ใช่หรือไม่? การกระทำนี้ไม่สามารถย้อนกลับได้`, 'DELETE', () => {
    games = games.filter(x => x.id !== id);
    saveData('games', games);
    addLog('game', `ลบเกม "${g.name}"`, 'Admin');
    renderGamesTable(); renderDashboard();
    toast('ลบเกมเรียบร้อย');
  });
}

/* ============ PACKAGE ============ */
let pkgGameId = null;
function openPkgModal(gameId) {
  pkgGameId = gameId;
  const g = games.find(x => x.id === gameId); if (!g) return;
  document.getElementById('pkg-modal-title').textContent = 'แพ็กเกจ: ' + g.name;
  renderPkgList();
  document.getElementById('pkg-modal').classList.add('active');
}
function closePkgModal() { document.getElementById('pkg-modal').classList.remove('active'); pkgGameId = null; }
function renderPkgList() {
  const g = games.find(x => x.id === pkgGameId); if (!g) return;
  const container = document.getElementById('pkg-modal').querySelector('.modal-box');
  const existing = container.querySelector('.pkg-list'); if (existing) existing.remove();
  const existingBtn = container.querySelector('.pkg-add-btn'); if (existingBtn) existingBtn.remove();
  const existingEditor = container.querySelector('.pkg-item-editor'); if (existingEditor) existingEditor.remove();
  container.querySelector('.modal-actions').style.display = 'flex';

  const pkgHtml = document.createElement('div');
  pkgHtml.className = 'pkg-list'; pkgHtml.style.marginTop = '14px';
  pkgHtml.innerHTML = g.packs.length ? g.packs.map((p, i) => `
    <div class="pkg-item">
      <div class="pkg-name">${esc(p.name)}</div>
      <div class="pkg-price">${fmtMoney(p.price)}</div>
      <div class="pkg-actions">
        <button class="btn-icon primary" onclick="editPkgItem(${i})" title="แก้ไข"><svg viewBox="0 0 24 24"><path d="M21.174 6.812a1 1 0 0 0-3.986-3.987L3.842 16.174a2 2 0 0 0-.5.83l-1.321 4.352a.5.5 0 0 0 .623.622l4.353-1.32a2 2 0 0 0 .83-.497z"/><path d="m15 5 4 4"/></svg></button>
        <button class="btn-icon danger" onclick="deletePkgItem(${i})" title="ลบ"><svg viewBox="0 0 24 24"><path d="M3 6h18"/><path d="M19 6v14c0 1-1 2-2 2H7c-1 0-2-1-2-2V6"/><path d="M8 6V4c0-1 1-2 2-2h4c1 0 2 1 2 2v2"/></svg></button>
      </div>
    </div>`).join('') : '<div class="empty-state" style="padding: 16px;"><p style="font-size: 11.5px;">ยังไม่มีแพ็กเกจ</p></div>';
  const addBtn = document.createElement('button');
  addBtn.className = 'btn btn-primary btn-sm pkg-add-btn';
  addBtn.style.cssText = 'width: 100%; margin-top: 10px;';
  addBtn.innerHTML = '<svg viewBox="0 0 24 24"><path d="M5 12h14"/><path d="M12 5v14"/></svg> เพิ่มแพ็กเกจ';
  addBtn.onclick = () => openPkgItemModal();
  const modalActions = container.querySelector('.modal-actions');
  container.insertBefore(pkgHtml, modalActions);
  container.insertBefore(addBtn, modalActions);
}
function openPkgItemModal(editIdx) {
  const g = games.find(x => x.id === pkgGameId); if (!g) return;
  const p = editIdx !== undefined ? g.packs[editIdx] : null;
  document.getElementById('pkg-modal-title').textContent = p ? 'แก้ไขแพ็กเกจ' : 'เพิ่มแพ็กเกจ';
  const modal = document.getElementById('pkg-modal');
  const modalBox = modal.querySelector('.modal-box');
  const oldEditor = modalBox.querySelector('.pkg-item-editor'); if (oldEditor) oldEditor.remove();
  const editor = document.createElement('div');
  editor.className = 'pkg-item-editor';
  editor.style.cssText = 'margin-top: 14px; padding-top: 14px; border-top: 1px solid var(--line2);';
  editor.innerHTML = `
    <div class="form-group"><label class="form-label">ชื่อแพ็กเกจ <span class="req">*</span></label><input type="text" class="form-input" id="pkg-name-input" value="${p ? esc(p.name) : ''}"></div>
    <div class="form-group"><label class="form-label">ราคา (บาท) <span class="req">*</span></label><input type="number" class="form-input" id="pkg-price-input" value="${p ? p.price : ''}" step="0.01" min="0"></div>
    <div style="display: flex; gap: 7px; margin-top: 10px;"><button class="btn btn-secondary" style="flex: 1;" onclick="cancelPkgEdit()">ยกเลิก</button><button class="btn btn-primary" style="flex: 1;" onclick="savePkgItem(${editIdx !== undefined ? editIdx : 'null'})">${p ? 'บันทึก' : 'เพิ่ม'}</button></div>
  `;
  modalBox.appendChild(editor);
  modalBox.querySelector('.modal-actions').style.display = 'none';
  const pl = modalBox.querySelector('.pkg-list'); if (pl) pl.style.display = 'none';
  const ab = modalBox.querySelector('.pkg-add-btn'); if (ab) ab.style.display = 'none';
}
function cancelPkgEdit() {
  const modal = document.getElementById('pkg-modal');
  const modalBox = modal.querySelector('.modal-box');
  const editor = modalBox.querySelector('.pkg-item-editor'); if (editor) editor.remove();
  modalBox.querySelector('.modal-actions').style.display = 'flex';
  renderPkgList();
  const g = games.find(x => x.id === pkgGameId); if (g) document.getElementById('pkg-modal-title').textContent = 'แพ็กเกจ: ' + g.name;
}
function savePkgItem(editIdx) {
  const g = games.find(x => x.id === pkgGameId); if (!g) return;
  const name = document.getElementById('pkg-name-input').value.trim();
  const price = parseFloat(document.getElementById('pkg-price-input').value);
  if (!name) { Swal.fire({ title: 'ผิดพลาด', text: 'กรุณาระบุชื่อแพ็กเกจ', icon: 'warning', confirmButtonText: 'ตกลง' }); return; }
  if (isNaN(price) || price < 0) { Swal.fire({ title: 'ผิดพลาด', text: 'กรุณาระบุราคาที่ถูกต้อง', icon: 'warning', confirmButtonText: 'ตกลง' }); return; }
  if (editIdx !== null && editIdx !== undefined) {
    g.packs[editIdx] = { name, price };
    addLog('game', `แก้ไขแพ็กเกจ "${name}" ใน "${g.name}"`, 'Admin');
    toast('อัปเดตแพ็กเกจเรียบร้อย');
  } else {
    g.packs.push({ name, price });
    addLog('game', `เพิ่มแพ็กเกจ "${name}" ใน "${g.name}"`, 'Admin');
    toast('เพิ่มแพ็กเกจเรียบร้อย');
  }
  saveData('games', games);
  cancelPkgEdit();
  renderGamesTable(); renderDashboard();
}
function editPkgItem(idx) { openPkgItemModal(idx); }
function deletePkgItem(idx) {
  const g = games.find(x => x.id === pkgGameId); if (!g || !g.packs[idx]) return;
  Swal.fire({ title: 'ลบแพ็กเกจ?', text: `ต้องการลบ "${g.packs[idx].name}" ใช่หรือไม่?`, icon: 'warning', showCancelButton: true, confirmButtonText: 'ลบ', cancelButtonText: 'ยกเลิก' }).then(r => {
    if (!r.isConfirmed) return;
    const removed = g.packs[idx]; g.packs.splice(idx, 1);
    saveData('games', games);
    addLog('game', `ลบแพ็กเกจ "${removed.name}" ใน "${g.name}"`, 'Admin');
    renderPkgList();
    renderGamesTable(); renderDashboard();
    toast('ลบแพ็กเกจเรียบร้อย');
  });
}

/* ============ ORDERS (with date filter + bulk) ============ */
let selectedOrders = new Set();
function renderOrdersTable() {
  if (!document.getElementById('page-orders')) return;
  const filter = document.getElementById('order-filter')?.value || 'all';
  const dateFrom = document.getElementById('order-date-from')?.value || '';
  const dateTo = document.getElementById('order-date-to')?.value || '';
  const search = (document.getElementById('order-search')?.value || '').toLowerCase();
  let filtered = orders;
  if (filter !== 'all') filtered = filtered.filter(o => o.status === filter);
  if (dateFrom) filtered = filtered.filter(o => o.date.slice(0, 10) >= dateFrom);
  if (dateTo) filtered = filtered.filter(o => o.date.slice(0, 10) <= dateTo);
  if (search) filtered = filtered.filter(o => o.id.toLowerCase().includes(search) || o.user.toLowerCase().includes(search) || o.uid.includes(search));
  document.getElementById('nav-order-count').textContent = orders.filter(o => o.status === 'pending').length;
  document.getElementById('orders-bulk').style.display = filtered.length ? 'flex' : 'none';
  document.getElementById('orders-selected-count').textContent = selectedOrders.size;
  document.getElementById('orders-tbody').innerHTML = filtered.length ? filtered.map(o => {
    const badge = o.status === 'success' ? 'green' : o.status === 'pending' ? 'amber' : 'red';
    const label = o.status === 'success' ? 'สำเร็จ' : o.status === 'pending' ? 'รอดำเนินการ' : 'ล้มเหลว';
    return `<tr>
      <td><input type="checkbox" ${selectedOrders.has(o.id) ? 'checked' : ''} onchange="toggleOrderSelect('${esc(o.id)}', this)"></td>
      <td class="cell-mono">${esc(o.id)}</td>
      <td class="cell-title">${esc(o.user)}</td>
      <td>${esc(o.product)}</td>
      <td class="cell-mono">${esc(o.uid)}</td>
      <td>${fmtMoney(o.amount)}</td>
      <td><span class="badge ${badge}">${label}</span></td>
      <td style="font-size:10.5px;color:var(--muted);">${esc(o.date)}</td>
      <td><div class="table-actions">
        <button class="btn-icon primary" onclick="viewOrderDetail('${esc(o.id)}')" title="ดู"><svg viewBox="0 0 24 24"><path d="M2 12s3-7 10-7 10 7 10 7-3 7-10 7-10-7-10-7Z"/><circle cx="12" cy="12" r="3"/></svg></button>
        ${o.status === 'pending' ? `<button class="btn-icon success" onclick="updateOrderStatus('${esc(o.id)}','success')" title="อนุมัติ"><svg viewBox="0 0 24 24"><polyline points="20 6 9 17 4 12"/></svg></button>` : ''}
        ${o.status !== 'failed' ? `<button class="btn-icon danger" onclick="refundOrder('${esc(o.id)}')" title="คืนเงิน"><svg viewBox="0 0 24 24"><path d="M3 12a9 9 0 0 1 9-9 9.75 9.75 0 0 1 6.74 2.74L21 8"/><path d="M21 3v5h-5"/></svg></button>` : ''}
      </div></td>
    </tr>`;
  }).join('') : '<tr><td colspan="9"><div class="empty-state"><p>ไม่มีคำสั่งซื้อ</p></div></td></tr>';
}
function resetOrderFilters() {
  document.getElementById('order-filter').value = 'all';
  document.getElementById('order-date-from').value = '';
  document.getElementById('order-date-to').value = '';
  document.getElementById('order-search').value = '';
  selectedOrders.clear();
  renderOrdersTable();
}
function toggleOrderSelect(id, cb) { if (cb.checked) selectedOrders.add(id); else selectedOrders.delete(id); document.getElementById('orders-selected-count').textContent = selectedOrders.size; }
function toggleSelectAllOrders(cb) {
  document.querySelectorAll('#orders-tbody input[type="checkbox"]').forEach(c => { c.checked = cb.checked; const id = c.parentElement.parentElement.children[1].textContent; if (cb.checked) selectedOrders.add(id); else selectedOrders.delete(id); });
  document.getElementById('orders-selected-count').textContent = selectedOrders.size;
}
function bulkApproveOrders() {
  if (selectedOrders.size === 0) { toast('กรุณาเลือกรายการ', 'error'); return; }
  Swal.fire({ title: `อนุมัติ ${selectedOrders.size} รายการ?`, icon: 'question', showCancelButton: true, confirmButtonText: 'อนุมัติ', cancelButtonText: 'ยกเลิก' }).then(r => {
    if (!r.isConfirmed) return;
    let count = 0;
    selectedOrders.forEach(id => { const o = orders.find(x => x.id === id); if (o && o.status === 'pending') { o.status = 'success'; count++; } });
    saveData('orders', orders);
    addLog('order', `อนุมัติ ${count} คำสั่งซื้อ (bulk)`, 'Admin');
    selectedOrders.clear();
    document.getElementById('orders-select-all').checked = false;
    renderOrdersTable(); renderDashboard();
    toast(`อนุมัติ ${count} รายการเรียบร้อย`);
  });
}
function bulkRejectOrders() {
  if (selectedOrders.size === 0) { toast('กรุณาเลือกรายการ', 'error'); return; }
  Swal.fire({ title: `ยกเลิก ${selectedOrders.size} รายการ?`, icon: 'question', showCancelButton: true, confirmButtonText: 'ยกเลิก', cancelButtonText: 'ปิด' }).then(r => {
    if (!r.isConfirmed) return;
    let count = 0;
    selectedOrders.forEach(id => { const o = orders.find(x => x.id === id); if (o && o.status !== 'failed') { o.status = 'failed'; count++; } });
    saveData('orders', orders);
    addLog('order', `ยกเลิก ${count} คำสั่งซื้อ (bulk)`, 'Admin');
    selectedOrders.clear();
    document.getElementById('orders-select-all').checked = false;
    renderOrdersTable(); renderDashboard();
    toast(`ยกเลิก ${count} รายการเรียบร้อย`);
  });
}
function viewOrderDetail(orderId) {
  const o = orders.find(x => x.id === orderId); if (!o) return;
  const badge = o.status === 'success' ? 'green' : o.status === 'pending' ? 'amber' : 'red';
  const label = o.status === 'success' ? 'สำเร็จ' : o.status === 'pending' ? 'รอดำเนินการ' : 'ล้มเหลว';
  Swal.fire({ title: 'รายละเอียดคำสั่งซื้อ', html: `<div style="text-align:left;font-size:12px;line-height:1.8;"><div><b>Order ID:</b> <span style="font-family:monospace;">${esc(o.id)}</span></div><div><b>ผู้ใช้:</b> ${esc(o.user)}</div><div><b>สินค้า:</b> ${esc(o.product)}</div><div><b>UID:</b> <span style="font-family:monospace;">${esc(o.uid)}</span></div><div><b>ยอดเงิน:</b> ${fmtMoney(o.amount)}</div><div><b>สถานะ:</b> <span class="badge ${badge}">${label}</span></div><div><b>วันที่:</b> ${esc(o.date)}</div>${o.note ? `<div><b>หมายเหตุ:</b> ${esc(o.note)}</div>` : ''}</div>`, confirmButtonText: 'ปิด' });
}
function updateOrderStatus(orderId, status) {
  const o = orders.find(x => x.id === orderId); if (!o) return;
  const label = status === 'success' ? 'อนุมัติ' : 'ยกเลิก';
  Swal.fire({ title: `${label}คำสั่งซื้อ?`, text: `ต้องการ${label} ${orderId} ใช่หรือไม่?`, icon: 'question', showCancelButton: true, confirmButtonText: label, cancelButtonText: 'ยกเลิก' }).then(r => {
    if (!r.isConfirmed) return;
    o.status = status;
    saveData('orders', orders);
    addLog('order', `${label}คำสั่งซื้อ ${orderId}`, 'Admin');
    renderOrdersTable(); renderDashboard();
    toast(`${label}เรียบร้อย`);
  });
}
function refundOrder(orderId) {
  const o = orders.find(x => x.id === orderId); if (!o) return;
  const u = users.find(x => x.username === o.user);
  Swal.fire({
    title: 'คืนเงิน?',
    html: `<div style="text-align:left;font-size:12px;line-height:1.6;">คืนเงิน <b>${fmtMoney(o.amount)}</b> ให้ <b>${esc(o.user)}</b>?<br>สถานะจะเป็น "ล้มเหลว" และเครดิตจะถูกคืนเข้าบัญชีผู้ใช้</div>`,
    icon: 'warning', showCancelButton: true, confirmButtonText: 'คืนเงิน', cancelButtonText: 'ยกเลิก'
  }).then(r => {
    if (!r.isConfirmed) return;
    o.status = 'failed';
    if (u) {
      const oldCredit = u.credit;
      u.credit = (u.credit || 0) + o.amount;
      if (!u.balanceLog) u.balanceLog = [];
      u.balanceLog.unshift({ delta: o.amount, reason: `คืนเงินคำสั่งซื้อ ${orderId}`, time: '2026-11-12 ' + new Date().toTimeString().slice(0, 5) });
      saveData('users', users);
      addLog('user', `คืนเงิน ${fmtMoney(o.amount)} ให้ "${u.username}"`, 'Admin');
    }
    saveData('orders', orders);
    addLog('order', `คืนเงินคำสั่งซื้อ ${orderId}`, 'Admin');
    renderOrdersTable(); renderUsersTable(); renderDashboard();
    toast('คืนเงินเรียบร้อย');
  });
}
function exportOrders() {
  const csv = 'id,user,product,uid,amount,status,date\n' + orders.map(o => `${o.id},${o.user},"${o.product}",${o.uid},${o.amount},${o.status},${o.date}`).join('\n');
  const blob = new Blob(['\uFEFF' + csv], { type: 'text/csv;charset=utf-8;' });
  const link = document.createElement('a');
  link.href = URL.createObjectURL(blob);
  link.download = 'nearbyshop_orders_' + todayStr() + '.csv';
  link.click();
  toast('ส่งออก CSV เรียบร้อย');
}

/* ============ USERS ============ */
let editingUserId = null;
function renderUsersTable() {
  if (!document.getElementById('page-users')) return;
  const q = (document.getElementById('user-search-admin')?.value || '').toLowerCase();
  const filtered = users.filter(u => u.username.toLowerCase().includes(q) || u.email.toLowerCase().includes(q));
  document.getElementById('user-count').textContent = users.length;
  document.getElementById('nav-user-count').textContent = users.length;
  document.getElementById('users-tbody').innerHTML = filtered.length ? filtered.map(u => `
    <tr>
      <td class="cell-title">${esc(u.username)}</td>
      <td style="font-size:11px;color:var(--muted);">${esc(u.email)}</td>
      <td>${fmtMoney(u.credit)}</td>
      <td>${u.orders}</td>
      <td><span class="badge ${u.status === 'active' ? 'green' : 'red'}">${u.status === 'active' ? 'ใช้งาน' : 'ระงับ'}</span></td>
      <td style="font-size:10.5px;color:var(--muted);">${esc(u.date)}</td>
      <td><div class="table-actions">
        <button class="btn-icon primary" onclick="openUserModal(${u.id})" title="แก้ไข"><svg viewBox="0 0 24 24"><path d="M21.174 6.812a1 1 0 0 0-3.986-3.987L3.842 16.174a2 2 0 0 0-.5.83l-1.321 4.352a.5.5 0 0 0 .623.622l4.353-1.32a2 2 0 0 0 .83-.497z"/><path d="m15 5 4 4"/></svg></button>
        <button class="btn-icon ${u.status === 'active' ? 'danger' : 'success'}" onclick="toggleUserStatus(${u.id})" title="${u.status === 'active' ? 'ระงับ' : 'เปิด'}">${u.status === 'active' ? '<svg viewBox="0 0 24 24"><path d="M18.36 6.64a9 9 0 1 1-12.73 0"/><line x1="12" y1="2" x2="12" y2="12"/></svg>' : '<svg viewBox="0 0 24 24"><path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z"/><polyline points="9 12 11 14 15 10"/></svg>'}</button>
      </div></td>
    </tr>`).join('') : '<tr><td colspan="7"><div class="empty-state"><p>ไม่พบผู้ใช้</p></div></td></tr>';
}
function openUserModal(id) {
  editingUserId = id;
  const u = users.find(x => x.id === id); if (!u) return;
  document.getElementById('user-modal-title').textContent = 'แก้ไขผู้ใช้: ' + u.username;
  document.getElementById('user-username-input').value = u.username;
  document.getElementById('user-email-input').value = u.email;
  document.getElementById('user-credit-input').value = u.credit;
  document.getElementById('user-status-input').value = u.status;
  document.getElementById('user-note-input').value = u.note || '';
  document.getElementById('user-balance-reason').value = '';
  document.getElementById('user-modal').classList.add('active');
}
function closeUserModal() { document.getElementById('user-modal').classList.remove('active'); editingUserId = null; }
function saveUser() {
  if (editingUserId === null) return;
  const u = users.find(x => x.id === editingUserId); if (!u) return;
  const username = document.getElementById('user-username-input').value.trim();
  const email = document.getElementById('user-email-input').value.trim();
  const newCredit = parseFloat(document.getElementById('user-credit-input').value) || 0;
  const status = document.getElementById('user-status-input').value;
  const note = document.getElementById('user-note-input').value.trim();
  const reason = document.getElementById('user-balance-reason').value.trim();
  if (!username) { Swal.fire({ title: 'ผิดพลาด', text: 'กรุณาระบุชื่อผู้ใช้', icon: 'warning', confirmButtonText: 'ตกลง' }); return; }
  if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) { Swal.fire({ title: 'ผิดพลาด', text: 'รูปแบบอีเมลไม่ถูกต้อง', icon: 'warning', confirmButtonText: 'ตกลง' }); return; }
  const dup = users.find(x => x.id !== editingUserId && x.username.toLowerCase() === username.toLowerCase());
  if (dup) { Swal.fire({ title: 'ผิดพลาด', text: 'ชื่อผู้ใช้นี้มีอยู่แล้ว', icon: 'error', confirmButtonText: 'ตกลง' }); return; }
  const oldCredit = u.credit;
  const delta = newCredit - oldCredit;
  if (delta !== 0) {
    if (!u.balanceLog) u.balanceLog = [];
    const now = new Date();
    u.balanceLog.unshift({ delta, reason: reason || 'ปรับยอดโดยแอดมิน', time: `2026-11-12 ${String(now.getHours()).padStart(2,'0')}:${String(now.getMinutes()).padStart(2,'0')}` });
    addLog('user', `ปรับยอด "${u.username}" ${delta > 0 ? '+' : ''}${fmtMoney(delta)}${reason ? ' เหตุผล: ' + reason : ''}`, 'Admin');
  }
  u.username = username; u.email = email; u.credit = newCredit; u.status = status; u.note = note;
  saveData('users', users);
  closeUserModal();
  renderUsersTable(); renderDashboard();
  toast('อัปเดตผู้ใช้เรียบร้อย');
}
function deleteUserFromModal() {
  if (editingUserId === null) return;
  const u = users.find(x => x.id === editingUserId); if (!u) return;
  closeUserModal();
  openConfirmModal('ลบผู้ใช้?', `ต้องการลบ "${u.username}" ใช่หรือไม่? การกระทำนี้ไม่สามารถย้อนกลับได้`, 'DELETE', () => {
    users = users.filter(x => x.id !== editingUserId);
    saveData('users', users);
    addLog('user', `ลบผู้ใช้ "${u.username}"`, 'Admin');
    renderUsersTable(); renderDashboard();
    toast('ลบผู้ใช้เรียบร้อย');
  });
}
function toggleUserStatus(id) {
  const u = users.find(x => x.id === id); if (!u) return;
  const newStatus = u.status === 'active' ? 'inactive' : 'active';
  const label = newStatus === 'active' ? 'เปิดใช้งาน' : 'ระงับ';
  Swal.fire({ title: `${label}ผู้ใช้?`, text: `ต้องการ${label} "${u.username}" ใช่หรือไม่?`, icon: 'question', showCancelButton: true, confirmButtonText: label, cancelButtonText: 'ยกเลิก' }).then(r => {
    if (!r.isConfirmed) return;
    u.status = newStatus;
    saveData('users', users);
    addLog('user', `${label}ผู้ใช้ "${u.username}"`, 'Admin');
    renderUsersTable(); renderDashboard();
    toast(`${label}เรียบร้อย`);
  });
}
function exportUsers() {
  const csv = 'username,email,credit,orders,status,date,note\n' + users.map(u => `${u.username},${u.email},${u.credit},${u.orders},${u.status},${u.date},"${(u.note || '').replace(/"/g, '""')}"`).join('\n');
  const blob = new Blob(['\uFEFF' + csv], { type: 'text/csv;charset=utf-8;' });
  const link = document.createElement('a');
  link.href = URL.createObjectURL(blob);
  link.download = 'nearbyshop_users_' + todayStr() + '.csv';
  link.click();
  toast('ส่งออก CSV เรียบร้อย');
}

/* ============ TOPUPS ============ */
let selectedTopups = new Set();
let pendingTopupAction = null;
function renderTopupsTable() {
  if (!document.getElementById('page-topups')) return;
  const filter = document.getElementById('topup-filter')?.value || 'all';
  const dateFrom = document.getElementById('topup-date-from')?.value || '';
  const dateTo = document.getElementById('topup-date-to')?.value || '';
  let filtered = topups;
  if (filter !== 'all') filtered = filtered.filter(t => t.status === filter);
  if (dateFrom) filtered = filtered.filter(t => t.date.slice(0, 10) >= dateFrom);
  if (dateTo) filtered = filtered.filter(t => t.date.slice(0, 10) <= dateTo);
  document.getElementById('nav-topup-count').textContent = topups.filter(t => t.status === 'pending').length;
  document.getElementById('topups-bulk').style.display = filtered.length ? 'flex' : 'none';
  document.getElementById('topups-selected-count').textContent = selectedTopups.size;
  document.getElementById('topups-tbody').innerHTML = filtered.length ? filtered.map(t => {
    const badge = t.status === 'success' ? 'green' : t.status === 'pending' ? 'amber' : 'red';
    const label = t.status === 'success' ? 'สำเร็จ' : t.status === 'pending' ? 'รอดำเนินการ' : 'ล้มเหลว';
    return `<tr>
      <td><input type="checkbox" ${selectedTopups.has(t.id) ? 'checked' : ''} onchange="toggleTopupSelect('${esc(t.id)}', this)"></td>
      <td class="cell-mono">${esc(t.id)}</td>
      <td class="cell-title">${esc(t.user)}</td>
      <td>${esc(t.method)}</td>
      <td>${fmtMoney(t.amount)}</td>
      <td>${fmtMoney(t.fee.toFixed(2))}</td>
      <td><span class="badge ${badge}">${label}</span></td>
      <td style="font-size:10.5px;color:var(--muted);">${esc(t.date)}</td>
      <td><div class="table-actions">
        ${t.status === 'pending' ? `<button class="btn-icon success" onclick="updateTopupStatus('${esc(t.id)}','success')" title="อนุมัติ"><svg viewBox="0 0 24 24"><polyline points="20 6 9 17 4 12"/></svg></button>` : ''}
        ${t.status !== 'failed' ? `<button class="btn-icon danger" onclick="updateTopupStatus('${esc(t.id)}','failed')" title="ปฏิเสธ"><svg viewBox="0 0 24 24"><path d="M18 6 6 18"/><path d="m6 6 12 12"/></svg></button>` : ''}
        ${t.note ? `<span title="${esc(t.note)}" style="color:var(--muted);cursor:help;">📝</span>` : ''}
      </div></td>
    </tr>`;
  }).join('') : '<tr><td colspan="9"><div class="empty-state"><p>ไม่มีรายการเติมเงิน</p></div></td></tr>';
}
function toggleTopupSelect(id, cb) { if (cb.checked) selectedTopups.add(id); else selectedTopups.delete(id); document.getElementById('topups-selected-count').textContent = selectedTopups.size; }
function toggleSelectAllTopups(cb) {
  document.querySelectorAll('#topups-tbody input[type="checkbox"]').forEach(c => {
    c.checked = cb.checked;
    const id = c.parentElement.parentElement.children[1].textContent;
    if (cb.checked) selectedTopups.add(id); else selectedTopups.delete(id);
  });
  document.getElementById('topups-selected-count').textContent = selectedTopups.size;
}
function bulkApproveTopups() {
  if (selectedTopups.size === 0) { toast('กรุณาเลือกรายการ', 'error'); return; }
  pendingTopupAction = { type: 'approve', ids: Array.from(selectedTopups) };
  document.getElementById('topup-note-title').textContent = `อนุมัติ ${selectedTopups.size} รายการ`;
  document.getElementById('topup-note-input').value = '';
  document.getElementById('topup-note-modal').classList.add('active');
}
function bulkRejectTopups() {
  if (selectedTopups.size === 0) { toast('กรุณาเลือกรายการ', 'error'); return; }
  pendingTopupAction = { type: 'reject', ids: Array.from(selectedTopups) };
  document.getElementById('topup-note-title').textContent = `ปฏิเสธ ${selectedTopups.size} รายการ`;
  document.getElementById('topup-note-input').value = '';
  document.getElementById('topup-note-modal').classList.add('active');
}
function updateTopupStatus(txnId, status) {
  const t = topups.find(x => x.id === txnId); if (!t) return;
  const label = status === 'success' ? 'อนุมัติ' : 'ปฏิเสธ';
  Swal.fire({ title: `${label}รายการ?`, text: `ต้องการ${label} ${txnId} ใช่หรือไม่?`, icon: 'question', showCancelButton: true, confirmButtonText: label, cancelButtonText: 'ยกเลิก' }).then(r => {
    if (!r.isConfirmed) return;
    t.status = status;
    saveData('topups', topups);
    addLog('topup', `${label} ${txnId}`, 'Admin');
    renderTopupsTable(); renderDashboard();
    toast(`${label}เรียบร้อย`);
  });
}
function closeTopupNoteModal() { document.getElementById('topup-note-modal').classList.remove('active'); pendingTopupAction = null; }
function confirmTopupAction() {
  if (!pendingTopupAction) return;
  const note = document.getElementById('topup-note-input').value.trim();
  const status = pendingTopupAction.type === 'approve' ? 'success' : 'failed';
  let count = 0;
  pendingTopupAction.ids.forEach(id => { const t = topups.find(x => x.id === id); if (t && t.status === 'pending') { t.status = status; t.note = note; count++; } });
  saveData('topups', topups);
  addLog('topup', `${pendingTopupAction.type === 'approve' ? 'อนุมัติ' : 'ปฏิเสธ'} ${count} รายการ (bulk)${note ? ' - ' + note : ''}`, 'Admin');
  selectedTopups.clear();
  closeTopupNoteModal();
  renderTopupsTable(); renderDashboard();
  toast(`ดำเนินการ ${count} รายการเรียบร้อย`);
}
function exportTopups() {
  const csv = 'id,user,method,amount,fee,status,date,note\n' + topups.map(t => `${t.id},${t.user},${t.method},${t.amount},${t.fee},${t.status},${t.date},"${(t.note || '').replace(/"/g, '""')}"`).join('\n');
  const blob = new Blob(['\uFEFF' + csv], { type: 'text/csv;charset=utf-8;' });
  const link = document.createElement('a');
  link.href = URL.createObjectURL(blob);
  link.download = 'nearbyshop_topups_' + todayStr() + '.csv';
  link.click();
  toast('ส่งออก CSV เรียบร้อย');
}

/* ============ REDEEM CODES (Enhanced) ============ */
let editingRedeemCode = null;
function renderRedeemTable() {
  if (!document.getElementById('page-redeem')) return;
  document.getElementById('redeem-tbody').innerHTML = redeemCodes.length ? redeemCodes.map(r => {
    const isExpired = r.expiry && r.expiry < todayStr();
    const isDepleted = r.used >= r.qty;
    let statusBadge = '<span class="badge green">ใช้งานได้</span>';
    if (isExpired) statusBadge = '<span class="badge red">หมดอายุ</span>';
    else if (isDepleted) statusBadge = '<span class="badge gray">ใช้ครบแล้ว</span>';
    return `<tr>
      <td class="cell-mono" style="font-weight:600;">${esc(r.code)}</td>
      <td>${esc(r.reward)}</td>
      <td><span class="badge ${r.type === 'credit' ? 'green' : r.type === 'item' ? 'purple' : 'amber'}">${r.type === 'credit' ? 'เครดิต' : r.type === 'item' ? 'ไอเทม' : 'ส่วนลด'}</span></td>
      <td>${r.qty}</td>
      <td>${r.used}</td>
      <td>${r.qty - r.used}</td>
      <td style="font-size:10.5px;color:var(--muted);">${r.expiry ? esc(r.expiry) : '<span style="color:var(--green);">ไม่หมดอายุ</span>'}</td>
      <td><div class="table-actions">
        ${statusBadge}
        <button class="btn-icon primary" onclick="editRedeemCode('${esc(r.code)}')" title="แก้ไข"><svg viewBox="0 0 24 24"><path d="M21.174 6.812a1 1 0 0 0-3.986-3.987L3.842 16.174a2 2 0 0 0-.5.83l-1.321 4.352a.5.5 0 0 0 .623.622l4.353-1.32a2 2 0 0 0 .83-.497z"/><path d="m15 5 4 4"/></svg></button>
        <button class="btn-icon primary" onclick="copyRedeemCode('${esc(r.code)}')" title="คัดลอก"><svg viewBox="0 0 24 24"><rect width="14" height="14" x="8" y="8" rx="2" ry="2"/><path d="M4 16c-1.1 0-2-.9-2-2V4c0-1.1.9-2 2-2h10c1.1 0 2 .9 2 2"/></svg></button>
        <button class="btn-icon danger" onclick="deleteRedeemCode('${esc(r.code)}')" title="ลบ"><svg viewBox="0 0 24 24"><path d="M3 6h18"/><path d="M19 6v14c0 1-1 2-2 2H7c-1 0-2-1-2-2V6"/><path d="M8 6V4c0-1 1-2 2-2h4c1 0 2 1 2 2v2"/></svg></button>
      </div></td>
    </tr>`;
  }).join('') : '<tr><td colspan="8"><div class="empty-state"><p>ไม่มีโค้ด</p></div></td></tr>';
}
function openRedeemModal() {
  editingRedeemCode = null;
  document.getElementById('redeem-modal-title').textContent = 'สร้างโค้ดใหม่';
  document.getElementById('redeem-code-input').value = '';
  document.getElementById('redeem-reward-input').value = '';
  document.getElementById('redeem-type-input').value = 'credit';
  document.getElementById('redeem-qty-input').value = '100';
  document.getElementById('redeem-start-input').value = '';
  document.getElementById('redeem-expiry-input').value = '';
  document.getElementById('redeem-modal').classList.add('active');
}
function editRedeemCode(code) {
  const r = redeemCodes.find(x => x.code === code); if (!r) return;
  editingRedeemCode = code;
  document.getElementById('redeem-modal-title').textContent = 'แก้ไขโค้ด: ' + r.code;
  document.getElementById('redeem-code-input').value = r.code;
  document.getElementById('redeem-reward-input').value = r.reward;
  document.getElementById('redeem-type-input').value = r.type || 'credit';
  document.getElementById('redeem-qty-input').value = r.qty;
  document.getElementById('redeem-start-input').value = r.start || '';
  document.getElementById('redeem-expiry-input').value = r.expiry || '';
  document.getElementById('redeem-modal').classList.add('active');
}
function closeRedeemModal() { document.getElementById('redeem-modal').classList.remove('active'); editingRedeemCode = null; }
function generateRedeemCode() { const chars = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789'; let code = 'NB-'; for (let i = 0; i < 12; i++) { code += chars[Math.floor(Math.random()*chars.length)]; if (i === 5) code += '-'; } document.getElementById('redeem-code-input').value = code; }
function saveRedeemCode() {
  const code = document.getElementById('redeem-code-input').value.trim().toUpperCase();
  const reward = document.getElementById('redeem-reward-input').value.trim();
  const type = document.getElementById('redeem-type-input').value;
  const qty = parseInt(document.getElementById('redeem-qty-input').value) || 1;
  const start = document.getElementById('redeem-start-input').value;
  const expiry = document.getElementById('redeem-expiry-input').value;
  if (!code || !reward) { Swal.fire({ title: 'ผิดพลาด', text: 'กรุณากรอกโค้ดและรางวัล', icon: 'warning', confirmButtonText: 'ตกลง' }); return; }
  if (editingRedeemCode) {
    const r = redeemCodes.find(x => x.code === editingRedeemCode);
    if (r) { r.reward = reward; r.type = type; r.qty = qty; r.start = start; r.expiry = expiry; }
    addLog('redeem', `แก้ไขโค้ด "${code}"`, 'Admin');
    toast('อัปเดตโค้ดเรียบร้อย');
  } else {
    if (redeemCodes.find(r => r.code === code)) { Swal.fire({ title: 'ผิดพลาด', text: 'โค้ดนี้มีอยู่แล้ว', icon: 'error', confirmButtonText: 'ตกลง' }); return; }
    redeemCodes.push({ code, reward, type, qty, used: 0, start, expiry });
    addLog('redeem', `สร้างโค้ด "${code}" (${qty} คน)`, 'Admin');
    toast('สร้างโค้ดเรียบร้อย');
  }
  saveData('redeemCodes', redeemCodes);
  closeRedeemModal();
  renderRedeemTable(); renderDashboard();
}
function copyRedeemCode(code) { copyToClipboard(code, 'คัดลอกโค้ด ' + code); }
function deleteRedeemCode(code) {
  Swal.fire({ title: 'ลบโค้ด?', text: `ต้องการลบ "${code}" ใช่หรือไม่?`, icon: 'warning', showCancelButton: true, confirmButtonText: 'ลบ', cancelButtonText: 'ยกเลิก' }).then(r => {
    if (!r.isConfirmed) return;
    redeemCodes = redeemCodes.filter(x => x.code !== code);
    saveData('redeemCodes', redeemCodes);
    addLog('redeem', `ลบโค้ด "${code}"`, 'Admin');
    renderRedeemTable(); renderDashboard();
    toast('ลบเรียบร้อย');
  });
}

/* ============ COUPONS (Enhanced) ============ */
let editingCouponCode = null;
function toggleCouponType() {
  const type = document.getElementById('coupon-type-input').value;
  const discountInput = document.getElementById('coupon-discount-input');
  discountInput.max = type === 'percent' ? 100 : '';
  discountInput.placeholder = type === 'percent' ? '0-100' : 'จำนวนเงิน';
}
function renderCouponsTable() {
  if (!document.getElementById('page-coupons')) return;
  document.getElementById('coupons-tbody').innerHTML = coupons.length ? coupons.map(c => {
    const isExpired = c.expiry && c.expiry < todayStr();
    let statusBadge = '<span class="badge green">ใช้งานได้</span>';
    if (isExpired) statusBadge = '<span class="badge red">หมดอายุ</span>';
    else if (c.used >= c.qty) statusBadge = '<span class="badge gray">ใช้ครบแล้ว</span>';
    const discountDisplay = c.type === 'percent' ? c.discount + '%' : fmtMoney(c.discount);
    return `<tr>
      <td class="cell-mono" style="font-weight:600;">${esc(c.code)}</td>
      <td><span class="badge ${c.type === 'percent' ? 'green' : 'amber'}">${discountDisplay}</span></td>
      <td>${fmtMoney(c.min)}</td>
      <td>${c.qty}</td>
      <td>${c.used}</td>
      <td style="font-size:10.5px;color:var(--muted);">${c.expiry ? esc(c.expiry) : '<span style="color:var(--green);">ไม่หมดอายุ</span>'}</td>
      <td><div class="table-actions">
        ${statusBadge}
        <button class="btn-icon primary" onclick="editCoupon('${esc(c.code)}')" title="แก้ไข"><svg viewBox="0 0 24 24"><path d="M21.174 6.812a1 1 0 0 0-3.986-3.987L3.842 16.174a2 2 0 0 0-.5.83l-1.321 4.352a.5.5 0 0 0 .623.622l4.353-1.32a2 2 0 0 0 .83-.497z"/><path d="m15 5 4 4"/></svg></button>
        <button class="btn-icon primary" onclick="copyCouponCode('${esc(c.code)}')" title="คัดลอก"><svg viewBox="0 0 24 24"><rect width="14" height="14" x="8" y="8" rx="2" ry="2"/><path d="M4 16c-1.1 0-2-.9-2-2V4c0-1.1.9-2 2-2h10c1.1 0 2 .9 2 2"/></svg></button>
        <button class="btn-icon danger" onclick="deleteCoupon('${esc(c.code)}')" title="ลบ"><svg viewBox="0 0 24 24"><path d="M3 6h18"/><path d="M19 6v14c0 1-1 2-2 2H7c-1 0-2-1-2-2V6"/><path d="M8 6V4c0-1 1-2 2-2h4c1 0 2 1 2 2v2"/></svg></button>
      </div></td>
    </tr>`;
  }).join('') : '<tr><td colspan="7"><div class="empty-state"><p>ไม่มีคูปอง</p></div></td></tr>';
}
function openCouponModal() {
  editingCouponCode = null;
  document.getElementById('coupon-modal-title').textContent = 'สร้างคูปอง';
  document.getElementById('coupon-code-input').value = '';
  document.getElementById('coupon-type-input').value = 'percent';
  document.getElementById('coupon-discount-input').value = '10';
  document.getElementById('coupon-min-input').value = '100';
  document.getElementById('coupon-max-input').value = '0';
  document.getElementById('coupon-qty-input').value = '50';
  document.getElementById('coupon-expiry-input').value = '';
  toggleCouponType();
  document.getElementById('coupon-modal').classList.add('active');
}
function editCoupon(code) {
  const c = coupons.find(x => x.code === code); if (!c) return;
  editingCouponCode = code;
  document.getElementById('coupon-modal-title').textContent = 'แก้ไขคูปอง: ' + c.code;
  document.getElementById('coupon-code-input').value = c.code;
  document.getElementById('coupon-type-input').value = c.type || 'percent';
  document.getElementById('coupon-discount-input').value = c.discount;
  document.getElementById('coupon-min-input').value = c.min;
  document.getElementById('coupon-max-input').value = c.max || 0;
  document.getElementById('coupon-qty-input').value = c.qty;
  document.getElementById('coupon-expiry-input').value = c.expiry || '';
  toggleCouponType();
  document.getElementById('coupon-modal').classList.add('active');
}
function closeCouponModal() { document.getElementById('coupon-modal').classList.remove('active'); editingCouponCode = null; }
function generateCouponCode() { const chars = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789'; let code = ''; for (let i = 0; i < 8; i++) code += chars[Math.floor(Math.random()*chars.length)]; document.getElementById('coupon-code-input').value = code; }
function saveCoupon() {
  const code = document.getElementById('coupon-code-input').value.trim().toUpperCase();
  const type = document.getElementById('coupon-type-input').value;
  const discount = parseFloat(document.getElementById('coupon-discount-input').value) || 0;
  const min = parseFloat(document.getElementById('coupon-min-input').value) || 0;
  const max = parseFloat(document.getElementById('coupon-max-input').value) || 0;
  const qty = parseInt(document.getElementById('coupon-qty-input').value) || 1;
  const expiry = document.getElementById('coupon-expiry-input').value;
  if (!code) { Swal.fire({ title: 'ผิดพลาด', text: 'กรุณากรอกโค้ด', icon: 'warning', confirmButtonText: 'ตกลง' }); return; }
  if (type === 'percent' && (discount < 0 || discount > 100)) { Swal.fire({ title: 'ผิดพลาด', text: 'ส่วนลดต้องอยู่ระหว่าง 0-100%', icon: 'warning', confirmButtonText: 'ตกลง' }); return; }
  if (editingCouponCode) {
    const c = coupons.find(x => x.code === editingCouponCode);
    if (c) { c.type = type; c.discount = discount; c.min = min; c.max = max; c.qty = qty; c.expiry = expiry; }
    addLog('coupon', `แก้ไขคูปอง "${code}"`, 'Admin');
    toast('อัปเดตคูปองเรียบร้อย');
  } else {
    if (coupons.find(c => c.code === code)) { Swal.fire({ title: 'ผิดพลาด', text: 'โค้ดนี้มีอยู่แล้ว', icon: 'error', confirmButtonText: 'ตกลง' }); return; }
    coupons.push({ code, type, discount, min, max, qty, used: 0, expiry });
    addLog('coupon', `สร้างคูปอง "${code}"`, 'Admin');
    toast('สร้างคูปองเรียบร้อย');
  }
  saveData('coupons', coupons);
  closeCouponModal();
  renderCouponsTable(); renderDashboard();
}
function copyCouponCode(code) { copyToClipboard(code, 'คัดลอกคูปอง ' + code); }
function deleteCoupon(code) {
  Swal.fire({ title: 'ลบคูปอง?', text: `ต้องการลบ "${code}" ใช่หรือไม่?`, icon: 'warning', showCancelButton: true, confirmButtonText: 'ลบ', cancelButtonText: 'ยกเลิก' }).then(r => {
    if (!r.isConfirmed) return;
    coupons = coupons.filter(c => c.code !== code);
    saveData('coupons', coupons);
    addLog('coupon', `ลบคูปอง "${code}"`, 'Admin');
    renderCouponsTable(); renderDashboard();
    toast('ลบเรียบร้อย');
  });
}

/* ============ NEWS (Full CRUD) ============ */
let editingNewsId = null;
function renderNewsList() {
  if (!document.getElementById('page-news')) return;
  document.getElementById('nav-news-count').textContent = news.length;
  const container = document.getElementById('news-list');
  if (!news.length) { container.innerHTML = '<div class="empty-state"><p>ยังไม่มีข่าวสาร</p></div>'; return; }
  container.innerHTML = news.map(n => {
    const catLabels = { announcement: 'ประกาศ', update: 'อัปเดต', promotion: 'โปรโมชั่น', guide: 'บทความ' };
    const catColors = { announcement: 'indigo', update: 'cyan', promotion: 'amber', guide: 'purple' };
    const statusBadge = n.status === 'published' ? '<span class="badge green">เผยแพร่</span>' : '<span class="badge gray">ฉบับร่าง</span>';
    return `<div class="news-card">
      <div style="display: flex; justify-content: space-between; align-items: flex-start; gap: 8px;">
        <div style="flex: 1; min-width: 0;">
          <div class="news-title">${esc(n.title)}</div>
          <div class="news-meta">
            <span class="badge ${catColors[n.category] || 'gray'}">${catLabels[n.category] || n.category}</span>
            ${statusBadge}
            <span>📅 ${esc(n.date)}</span>
          </div>
        </div>
      </div>
      <div class="news-excerpt">${esc(n.excerpt || n.body.slice(0, 100))}</div>
      <div class="news-actions">
        <button class="btn-icon primary" onclick="editNews(${n.id})" title="แก้ไข"><svg viewBox="0 0 24 24"><path d="M21.174 6.812a1 1 0 0 0-3.986-3.987L3.842 16.174a2 2 0 0 0-.5.83l-1.321 4.352a.5.5 0 0 0 .623.622l4.353-1.32a2 2 0 0 0 .83-.497z"/><path d="m15 5 4 4"/></svg></button>
        <button class="btn-icon ${n.status === 'published' ? 'warn' : 'success'}" onclick="toggleNewsStatus(${n.id})" title="${n.status === 'published' ? 'ซ่อน' : 'เผยแพร่'}">
          ${n.status === 'published' ? '<svg viewBox="0 0 24 24"><path d="M17.94 17.94A10.07 10.07 0 0 1 12 20c-7 0-11-8-11-8a18.45 18.45 0 0 1 5.06-5.94M9.9 4.24A9.12 9.12 0 0 1 12 4c7 0 11 8 11 8a18.5 18.5 0 0 1-2.16 3.19m-6.72-1.07a3 3 0 1 1-4.24-4.24"/><line x1="1" y1="1" x2="23" y2="23"/></svg>' : '<svg viewBox="0 0 24 24"><path d="M1 12s4-8 11-8 11 8 11 8-4 8-11 8-11-8-11-8z"/><circle cx="12" cy="12" r="3"/></svg>'}
        </button>
        <button class="btn-icon danger" onclick="deleteNews(${n.id})" title="ลบ"><svg viewBox="0 0 24 24"><path d="M3 6h18"/><path d="M19 6v14c0 1-1 2-2 2H7c-1 0-2-1-2-2V6"/><path d="M8 6V4c0-1 1-2 2-2h4c1 0 2 1 2 2v2"/></svg></button>
      </div>
    </div>`;
  }).join('');
}
function openNewsModal() {
  editingNewsId = null;
  document.getElementById('news-modal-title').textContent = 'เพิ่มข่าวสาร';
  document.getElementById('news-title-input').value = '';
  document.getElementById('news-excerpt-input').value = '';
  document.getElementById('news-body-input').value = '';
  document.getElementById('news-category-input').value = 'announcement';
  document.getElementById('news-status-input').value = 'published';
  document.getElementById('news-modal').classList.add('active');
}
function editNews(id) {
  const n = news.find(x => x.id === id); if (!n) return;
  editingNewsId = id;
  document.getElementById('news-modal-title').textContent = 'แก้ไขข่าวสาร';
  document.getElementById('news-title-input').value = n.title;
  document.getElementById('news-excerpt-input').value = n.excerpt || '';
  document.getElementById('news-body-input').value = n.body;
  document.getElementById('news-category-input').value = n.category;
  document.getElementById('news-status-input').value = n.status;
  document.getElementById('news-modal').classList.add('active');
}
function closeNewsModal() { document.getElementById('news-modal').classList.remove('active'); editingNewsId = null; }
function saveNews() {
  const title = document.getElementById('news-title-input').value.trim();
  const excerpt = document.getElementById('news-excerpt-input').value.trim();
  const body = document.getElementById('news-body-input').value.trim();
  const category = document.getElementById('news-category-input').value;
  const status = document.getElementById('news-status-input').value;
  if (!title || !body) { Swal.fire({ title: 'ผิดพลาด', text: 'กรุณากรอกหัวข้อและเนื้อหา', icon: 'warning', confirmButtonText: 'ตกลง' }); return; }
  if (editingNewsId) {
    const n = news.find(x => x.id === editingNewsId);
    if (n) { n.title = title; n.excerpt = excerpt; n.body = body; n.category = category; n.status = status; n.updated = todayStr(); }
    addLog('news', `แก้ไขข่าว "${title}"`, 'Admin');
    toast('อัปเดตข่าวสารเรียบร้อย');
  } else {
    const newId = Math.max(...news.map(n => n.id), 0) + 1;
    news.push({ id: newId, title, excerpt, body, category, status, date: todayStr(), updated: todayStr() });
    addLog('news', `เพิ่มข่าว "${title}"`, 'Admin');
    toast('เพิ่มข่าวสารเรียบร้อย');
  }
  saveData('news', news);
  closeNewsModal();
  renderNewsList(); renderDashboard();
}
function toggleNewsStatus(id) {
  const n = news.find(x => x.id === id); if (!n) return;
  n.status = n.status === 'published' ? 'draft' : 'published';
  n.updated = todayStr();
  saveData('news', news);
  addLog('news', `${n.status === 'published' ? 'เผยแพร่' : 'ซ่อน'}ข่าว "${n.title}"`, 'Admin');
  renderNewsList();
  toast(`${n.status === 'published' ? 'เผยแพร่' : 'ซ่อน'}เรียบร้อย`);
}
function deleteNews(id) {
  const n = news.find(x => x.id === id); if (!n) return;
  Swal.fire({ title: 'ลบข่าว?', text: `ต้องการลบ "${n.title}" ใช่หรือไม่?`, icon: 'warning', showCancelButton: true, confirmButtonText: 'ลบ', cancelButtonText: 'ยกเลิก' }).then(r => {
    if (!r.isConfirmed) return;
    news = news.filter(x => x.id !== id);
    saveData('news', news);
    addLog('news', `ลบข่าว "${n.title}"`, 'Admin');
    renderNewsList(); renderDashboard();
    toast('ลบเรียบร้อย');
  });
}

/* ============ HISTORY (Combined) ============ */
let historyTab = 'all';
function switchHistoryTab(tab, btn) {
  historyTab = tab;
  document.querySelectorAll('.tab-btn').forEach(b => b.classList.remove('active'));
  if (btn) btn.classList.add('active');
  renderHistory(tab);
}
function renderHistory(tab) {
  if (!document.getElementById('page-history')) return;
  const items = [];
  if (tab === 'all' || tab === 'topup') {
    topups.forEach(t => {
      items.push({ type: 'topup', id: t.id, user: t.user, amount: t.amount, status: t.status, date: t.date, note: t.note, method: t.method, raw: t });
    });
  }
  if (tab === 'all' || tab === 'order') {
    orders.forEach(o => {
      items.push({ type: 'order', id: o.id, user: o.user, amount: o.amount, status: o.status, date: o.date, note: o.note, product: o.product, raw: o });
    });
  }
  if (tab === 'all' || tab === 'api') {
    apiKeys.forEach(k => {
      items.push({ type: 'api', id: 'KEY-' + k.id, user: 'Admin', amount: 0, status: k.active ? 'active' : 'inactive', date: k.date, note: k.note, name: k.name, raw: k });
    });
  }
  items.sort((a, b) => (b.date || '').localeCompare(a.date || ''));
  const container = document.getElementById('history-list');
  if (!items.length) { container.innerHTML = '<div class="empty-state"><p>ไม่มีประวัติ</p></div>'; return; }
  const typeConfig = {
    topup: { label: 'เติมเงิน', color: 'amber', icon: '<path d="M17 14h.01"/><path d="M7 7h12a2 2 0 0 1 2 2v10a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h14"/>' },
    order: { label: 'คำสั่งซื้อ', color: 'indigo', icon: '<path d="M4 2v20l2-1 2 1 2-1 2 1 2-1 2 1 2-1 2 1V2l-2 1-2-1-2 1-2-1-2 1-2-1-2 1Z"/>' },
    api: { label: 'API Key', color: 'purple', icon: '<path d="m18 16 4-4-4-4"/><path d="m6 8-4 4 4 4"/><path d="m14.5 4-5 16"/>' }
  };
  container.innerHTML = items.map(item => {
    const cfg = typeConfig[item.type];
    const statusBadge = item.status === 'success' || item.status === 'active' ? 'green' : item.status === 'pending' ? 'amber' : 'red';
    const statusLabel = item.status === 'success' ? 'สำเร็จ' : item.status === 'pending' ? 'รอ' : item.status === 'active' ? 'ใช้งาน' : item.status === 'inactive' ? 'ปิด' : 'ล้มเหลว';
    let title = '';
    if (item.type === 'topup') title = `เติมเงิน ${fmtMoney(item.amount)} (${item.method})`;
    else if (item.type === 'order') title = item.product;
    else if (item.type === 'api') title = `API Key: ${item.name}`;
    return `<div class="history-log">
      <div class="hl-icon" style="background: rgba(99,102,241,.16); color: var(--accent-light);">
        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">${cfg.icon}</svg>
      </div>
      <div class="hl-content">
        <div class="hl-title"><span class="badge ${cfg.color}" style="margin-right: 6px;">${cfg.label}</span>${esc(title)}</div>
        <div class="hl-meta">${esc(item.id)} • ${esc(item.user)} • ${esc(item.date)}${item.note ? ' • ' + esc(item.note) : ''}</div>
      </div>
      <div style="text-align: right; flex-shrink: 0;">
        ${item.amount ? `<div class="hl-amount ${item.status === 'success' ? 'up' : 'down'}">${item.status === 'success' ? '+' : '-'}${fmtMoney(item.amount)}</div>` : ''}
        <span class="badge ${statusBadge}" style="margin-top: 3px;">${statusLabel}</span>
      </div>
    </div>`;
  }).join('');
}
function exportHistory() {
  const csv = 'type,id,user,amount,status,date,note\n' + topups.map(t => `topup,${t.id},${t.user},${t.amount},${t.status},${t.date},"${(t.note || '').replace(/"/g, '""')}"`).join('\n') + '\n' + orders.map(o => `order,${o.id},${o.user},${o.amount},${o.status},${o.date},"${(o.note || '').replace(/"/g, '""')}"`).join('\n');
  const blob = new Blob(['\uFEFF' + csv], { type: 'text/csv;charset=utf-8;' });
  const link = document.createElement('a');
  link.href = URL.createObjectURL(blob);
  link.download = 'nearbyshop_history_' + todayStr() + '.csv';
  link.click();
  toast('ส่งออก CSV เรียบร้อย');
}

/* ============ HEALTH ============ */
function renderHealth() {
  if (!document.getElementById('page-health')) return;
  const services = [
    { name: 'API Gateway', status: 'ok', meta: 'Uptime 99.98%' },
    { name: 'Database', status: 'ok', meta: 'Latency 12ms' },
    { name: 'Payment Gateway', status: 'warn', meta: 'Latency 250ms' },
    { name: 'Email Service', status: 'ok', meta: 'ทำงานปกติ' },
    { name: 'File Storage', status: 'ok', meta: 'ใช้ 45%' },
    { name: 'Webhook Queue', status: 'ok', meta: '0 pending' },
    { name: 'Cache (Redis)', status: 'ok', meta: 'Hit rate 96%' },
    { name: 'Backup', status: 'ok', meta: 'ล่าสุด 3 ชม. ที่แล้ว' }
  ];
  document.getElementById('health-grid').innerHTML = services.map(s => `
    <div class="health-card">
      <div class="health-dot ${s.status}"></div>
      <div class="health-info">
        <div class="health-name">${s.name}</div>
        <div class="health-meta">${s.meta}</div>
      </div>
    </div>
  `).join('');
}

/* ============ API KEYS (Enhanced) ============ */
let editingApiKeyId = null;
function renderApiKeys() {
  if (!document.getElementById('page-api')) return;
  document.getElementById('api-key-count').textContent = apiKeys.length;
  document.getElementById('nav-api-count').textContent = apiKeys.length;
  document.getElementById('api-keys-list').innerHTML = apiKeys.length ? apiKeys.map(k => {
    const isExpired = k.expiry && k.expiry < todayStr();
    const scopesHtml = (k.scopes || []).map(s => `<span style="display:inline-block;background:var(--panel3);padding:1px 6px;border-radius:4px;font-size:10px;font-family:monospace;color:var(--muted);margin-right:3px;">${s}</span>`).join('');
    return `<div class="key-row">
      <div style="min-width:140px;flex-shrink:0;">
        <div style="font-weight:600;font-size:12px;">${esc(k.name)}</div>
        <div style="font-size:10px;color:var(--muted);">${esc(k.note || 'ไม่มีหมายเหตุ')}</div>
      </div>
      <span class="key-mask">${esc(k.key.slice(0, 20))}${'•'.repeat(20)}</span>
      <div style="display:flex;align-items:center;gap:4px;font-size:10.5px;color:var(--muted);flex-shrink:0;">
        <span class="status-dot ${k.active && !isExpired ? 'online' : 'offline'}"></span>${isExpired ? 'หมดอายุ' : k.active ? 'ใช้งาน' : 'ปิด'}
      </div>
      <div style="font-size:10px;color:var(--muted);white-space:nowrap;flex-shrink:0;">${esc(k.date)}</div>
      ${scopesHtml ? `<div style="font-size:10px;">${scopesHtml}</div>` : ''}
      <div class="key-actions">
        <button class="btn-icon primary" onclick="copyApiKeyString('${esc(k.key)}')" title="คัดลอก"><svg viewBox="0 0 24 24"><rect width="14" height="14" x="8" y="8" rx="2" ry="2"/><path d="M4 16c-1.1 0-2-.9-2-2V4c0-1.1.9-2 2-2h10c1.1 0 2 .9 2 2"/></svg></button>
        <button class="btn-icon primary" onclick="editApiKey(${k.id})" title="แก้ไข"><svg viewBox="0 0 24 24"><path d="M21.174 6.812a1 1 0 0 0-3.986-3.987L3.842 16.174a2 2 0 0 0-.5.83l-1.321 4.352a.5.5 0 0 0 .623.622l4.353-1.32a2 2 0 0 0 .83-.497z"/><path d="m15 5 4 4"/></svg></button>
        <button class="btn-icon ${k.active ? 'danger' : 'success'}" onclick="toggleApiKeyActive(${k.id})" title="${k.active ? 'ปิด' : 'เปิด'}">
          ${k.active ? '<svg viewBox="0 0 24 24"><path d="M18.36 6.64a9 9 0 1 1-12.73 0"/><line x1="12" y1="2" x2="12" y2="12"/></svg>' : '<svg viewBox="0 0 24 24"><path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z"/><polyline points="9 12 11 14 15 10"/></svg>'}
        </button>
        <button class="btn-icon danger" onclick="deleteApiKeyById(${k.id})" title="ลบ"><svg viewBox="0 0 24 24"><path d="M3 6h18"/><path d="M19 6v14c0 1-1 2-2 2H7c-1 0-2-1-2-2V6"/><path d="M8 6V4c0-1 1-2 2-2h4c1 0 2 1 2 2v2"/></svg></button>
      </div>
    </div>`;
  }).join('') : '<div class="empty-state"><svg viewBox="0 0 24 24"><path d="m15.5 7.5 2.3 2.3a1 1 0 0 0 1.4 0l2.1-2.1a1 1 0 0 0 0-1.4L19 4"/><path d="m21 2-9.6 9.6"/><circle cx="7.5" cy="15.5" r="5.5"/></svg><p>ยังไม่มี API Key</p></div>';
}
function openApiKeyModal() {
  editingApiKeyId = null;
  document.getElementById('api-key-modal-title').textContent = 'สร้าง API Key';
  document.getElementById('new-api-key-name').value = '';
  document.getElementById('new-api-key-note').value = '';
  document.getElementById('new-api-key-status').value = 'true';
  document.getElementById('new-api-key-expiry').value = '';
  document.getElementById('new-api-scope-v1').checked = true;
  document.getElementById('new-api-scope-v2').checked = true;
  document.getElementById('new-api-scope-tmn').checked = true;
  document.getElementById('new-api-scope-noslip').checked = false;
  document.getElementById('api-key-modal').classList.add('active');
}
function editApiKey(id) {
  const k = apiKeys.find(x => x.id === id); if (!k) return;
  editingApiKeyId = id;
  document.getElementById('api-key-modal-title').textContent = 'แก้ไข API Key: ' + k.name;
  document.getElementById('new-api-key-name').value = k.name;
  document.getElementById('new-api-key-note').value = k.note || '';
  document.getElementById('new-api-key-status').value = k.active ? 'true' : 'false';
  document.getElementById('new-api-key-expiry').value = k.expiry || '';
  const scopes = k.scopes || [];
  document.getElementById('new-api-scope-v1').checked = scopes.includes('v1');
  document.getElementById('new-api-scope-v2').checked = scopes.includes('v2');
  document.getElementById('new-api-scope-tmn').checked = scopes.includes('tmn');
  document.getElementById('new-api-scope-noslip').checked = scopes.includes('noslip');
  document.getElementById('api-key-modal').classList.add('active');
}
function closeApiKeyModal() { document.getElementById('api-key-modal').classList.remove('active'); editingApiKeyId = null; }
function createApiKey() {
  const name = document.getElementById('new-api-key-name').value.trim();
  const note = document.getElementById('new-api-key-note').value.trim();
  const active = document.getElementById('new-api-key-status').value === 'true';
  const expiry = document.getElementById('new-api-key-expiry').value;
  const scopes = [];
  if (document.getElementById('new-api-scope-v1').checked) scopes.push('v1');
  if (document.getElementById('new-api-scope-v2').checked) scopes.push('v2');
  if (document.getElementById('new-api-scope-tmn').checked) scopes.push('tmn');
  if (document.getElementById('new-api-scope-noslip').checked) scopes.push('noslip');
  if (!name) { Swal.fire({ title: 'ผิดพลาด', text: 'กรุณาระบุชื่อ Key', icon: 'warning', confirmButtonText: 'ตกลง' }); return; }
  if (scopes.length === 0) { Swal.fire({ title: 'ผิดพลาด', text: 'กรุณาเลือกสิทธิ์อย่างน้อย 1 อย่าง', icon: 'warning', confirmButtonText: 'ตกลง' }); return; }
  if (editingApiKeyId) {
    const k = apiKeys.find(x => x.id === editingApiKeyId);
    if (k) { k.name = name; k.note = note; k.active = active; k.expiry = expiry; k.scopes = scopes; }
    addLog('api', `แก้ไข API Key "${name}"`, 'Admin');
    toast('อัปเดต API Key เรียบร้อย');
  } else {
    const bytes = new Uint8Array(16); (window.crypto || window.msCrypto).getRandomValues(bytes);
    const hex = Array.from(bytes, b => b.toString(16).padStart(2, '0')).join('');
    const now = new Date();
    const dateStr = `${now.getDate()}/${now.getMonth() + 1}/${now.getFullYear() + 543} ${String(now.getHours()).padStart(2, '0')}:${String(now.getMinutes()).padStart(2, '0')}`;
    const newId = Math.max(...apiKeys.map(k => k.id), 0) + 1;
    apiKeys.push({ id: newId, name, note, key: 'nb_live_' + hex, date: dateStr, active, expiry, scopes });
    addLog('api', `สร้าง API Key "${name}"`, 'Admin');
    toast('สร้าง API Key เรียบร้อย');
  }
  saveData('apiKeys', apiKeys);
  closeApiKeyModal();
  renderApiKeys(); renderDashboard();
}
function toggleApiKeyActive(id) {
  const k = apiKeys.find(x => x.id === id); if (!k) return;
  k.active = !k.active;
  saveData('apiKeys', apiKeys);
  addLog('api', `${k.active ? 'เปิด' : 'ปิด'} API Key "${k.name}"`, 'Admin');
  renderApiKeys(); renderDashboard();
  toast(`${k.active ? 'เปิด' : 'ปิด'}เรียบร้อย`);
}
function deleteApiKeyById(id) {
  const k = apiKeys.find(x => x.id === id); if (!k) return;
  openConfirmModal('ลบ API Key?', `ต้องการลบ "${k.name}" ใช่หรือไม่?`, 'DELETE', () => {
    apiKeys = apiKeys.filter(x => x.id !== id);
    saveData('apiKeys', apiKeys);
    addLog('api', `ลบ API Key "${k.name}"`, 'Admin');
    renderApiKeys(); renderDashboard();
    toast('ลบเรียบร้อย');
  });
}

/* ============ LOGS ============ */
function renderLogs() {
  if (!document.getElementById('page-logs')) return;
  const typeLabels = { order: 'คำสั่งซื้อ', topup: 'เติมเงิน', user: 'ผู้ใช้', api: 'API', game: 'เกม', redeem: 'โค้ด', coupon: 'คูปอง', news: 'ข่าว', settings: 'ตั้งค่า', auth: 'เข้าสู่ระบบ' };
  const typeColors = { order: 'indigo', topup: 'amber', user: 'green', api: 'cyan', game: 'purple', redeem: 'pink', coupon: 'indigo', news: 'cyan', settings: 'gray', auth: 'gray' };
  document.getElementById('logs-list').innerHTML = logs.length ? logs.map(l => `
    <div style="display:flex;gap:9px;padding:9px 0;border-bottom:1px solid var(--line2);align-items:flex-start;">
      <span class="badge ${typeColors[l.type] || 'gray'}" style="flex-shrink:0;">${typeLabels[l.type] || l.type}</span>
      <div style="flex:1;min-width:0;"><div style="font-size:12px;">${esc(l.action)}</div><div style="font-size:10px;color:var(--muted);margin-top:1px;">โดย ${esc(l.user)} • ${esc(l.time)}</div></div>
    </div>`).join('') : '<div class="empty-state"><p>ไม่มีบันทึก</p></div>';
}
function clearLogs() {
  openConfirmModal('ล้างบันทึก?', 'ต้องการลบบันทึกทั้งหมดใช่หรือไม่?', 'CLEAR', () => {
    logs = [];
    saveData('logs', logs);
    renderLogs();
    toast('ล้างบันทึกเรียบร้อย');
  });
}

/* ============ SETTINGS ============ */
let editingBankIndex = null;
function renderSettings() {
  if (!document.getElementById('page-settings')) return;
  document.getElementById('set-brand-name').value = settings.brandName || 'NEARBYSHOP';
  document.getElementById('set-brand-sub').value = settings.brandSub || 'Control Center';
  document.getElementById('set-site-email').value = settings.siteEmail || '';
  document.getElementById('set-site-phone').value = settings.sitePhone || '';
  document.getElementById('set-site-discord').value = settings.siteDiscord || '';
  document.getElementById('set-tm-fee').value = settings.tmFee ?? 2.9;
  document.getElementById('set-min-topup').value = settings.minTopup ?? 0;
  const logoPreview = document.getElementById('logo-preview');
  if (settings.logoDataUrl) { logoPreview.src = settings.logoDataUrl; logoPreview.classList.add('show'); } else { logoPreview.classList.remove('show'); }
  renderColorTheme();
  renderBankAccounts();
}
function renderColorTheme() {
  const colorKeys = [
    { key: 'bg', label: 'พื้นหลังหลัก' }, { key: 'panel', label: 'พื้นหลังการ์ด' },
    { key: 'panel3', label: 'พื้นหลังอินพุต' }, { key: 'line', label: 'เส้นขอบ' },
    { key: 'muted', label: 'ข้อความรอง' }, { key: 'accent', label: 'สีหลัก' },
    { key: 'accentLight', label: 'สีหลักอ่อน' }, { key: 'green', label: 'สีเขียว (Success)' },
    { key: 'amber', label: 'สีเหลือง (Warning)' }, { key: 'red', label: 'สีแดง (Danger)' }
  ];
  document.getElementById('color-theme-list').innerHTML = colorKeys.map(k => {
    const val = settings.colors[k.key] || '#000000';
    return `<div class="color-row"><label>${k.label}</label><div class="color-input-wrap"><input type="color" id="color-${k.key}" value="${val}" oninput="onColorChange('${k.key}', this.value)"><input type="text" class="form-input color-hex" value="${val}" onchange="onColorHexChange('${k.key}', this.value)" maxlength="7"></div></div>`;
  }).join('');
}
function onColorChange(key, value) {
  settings.colors[key] = value;
  const hexInput = document.querySelector(`#color-${key}`)?.parentElement.querySelector('.color-hex');
  if (hexInput) hexInput.value = value;
  applyTheme();
}
function onColorHexChange(key, value) {
  if (!/^#[0-9a-fA-F]{6}$/.test(value)) { toast('รูปแบบสีไม่ถูกต้อง', 'error'); return; }
  settings.colors[key] = value;
  const colorInput = document.getElementById(`color-${key}`);
  if (colorInput) colorInput.value = value;
  applyTheme();
}
function resetColors() {
  Swal.fire({ title: 'รีเซ็ตสี?', text: 'ต้องการกลับไปใช้สีเริ่มต้นใช่หรือไม่?', icon: 'question', showCancelButton: true, confirmButtonText: 'รีเซ็ต', cancelButtonText: 'ยกเลิก' }).then(r => {
    if (!r.isConfirmed) return;
    settings.colors = JSON.parse(JSON.stringify(SEED.settings.colors));
    saveData('settings', settings);
    applyTheme(); renderColorTheme();
    toast('รีเซ็ตสีเรียบร้อย');
  });
}
function handleLogoUpload(input) {
  const f = input.files && input.files[0]; if (!f) return;
  if (!/^image\/(png|jpeg|svg\+xml)$/.test(f.type)) { Swal.fire({ title: 'ไฟล์ไม่รองรับ', text: 'กรุณาเลือก PNG, JPG หรือ SVG', icon: 'error', confirmButtonText: 'ตกลง' }); input.value = ''; return; }
  if (f.size > 1024 * 1024) { Swal.fire({ title: 'ไฟล์ใหญ่เกินไป', text: 'ขนาดต้องไม่เกิน 1 MB', icon: 'error', confirmButtonText: 'ตกลง' }); input.value = ''; return; }
  const reader = new FileReader();
  reader.onload = e => {
    settings.logoDataUrl = e.target.result;
    saveData('settings', settings);
    applyTheme();
    const prev = document.getElementById('logo-preview');
    prev.src = e.target.result; prev.classList.add('show');
    toast('อัปโหลดโลโก้เรียบร้อย');
  };
  reader.readAsDataURL(f);
}
function removeLogo() {
  settings.logoDataUrl = null;
  saveData('settings', settings);
  applyTheme();
  document.getElementById('logo-preview').classList.remove('show');
  document.getElementById('logo-upload').value = '';
  toast('ลบโลโก้เรียบร้อย');
}
function renderBankAccounts() {
  const list = document.getElementById('bank-accounts-list');
  if (!settings.bankAccounts || !settings.bankAccounts.length) { list.innerHTML = '<div class="empty-state" style="padding: 16px;"><p style="font-size: 11.5px;">ยังไม่มีบัญชีธนาคาร</p></div>'; return; }
  list.innerHTML = settings.bankAccounts.map((b, i) => `
    <div class="pkg-item" style="margin-bottom: 7px;">
      <div style="flex: 1; min-width: 0;">
        <div style="font-weight: 600; font-size: 12.5px;">${esc(b.name)}</div>
        <div style="font-family: monospace; font-size: 12px; color: var(--accent-light);">${esc(b.acc)}</div>
        <div style="font-size: 10.5px; color: var(--muted);">${esc(b.owner)}${b.note ? ' • ' + esc(b.note) : ''}</div>
      </div>
      <div class="pkg-actions">
        <button class="btn-icon primary" onclick="editBankAccount(${i})" title="แก้ไข"><svg viewBox="0 0 24 24"><path d="M21.174 6.812a1 1 0 0 0-3.986-3.987L3.842 16.174a2 2 0 0 0-.5.83l-1.321 4.352a.5.5 0 0 0 .623.622l4.353-1.32a2 2 0 0 0 .83-.497z"/><path d="m15 5 4 4"/></svg></button>
        <button class="btn-icon danger" onclick="deleteBankAccount(${i})" title="ลบ"><svg viewBox="0 0 24 24"><path d="M3 6h18"/><path d="M19 6v14c0 1-1 2-2 2H7c-1 0-2-1-2-2V6"/><path d="M8 6V4c0-1 1-2 2-2h4c1 0 2 1 2 2v2"/></svg></button>
      </div>
    </div>`).join('');
}
function addBankAccount() {
  editingBankIndex = null;
  document.getElementById('bank-modal-title').textContent = 'เพิ่มบัญชีธนาคาร';
  document.getElementById('bank-name-input').value = '';
  document.getElementById('bank-acc-input').value = '';
  document.getElementById('bank-owner-input').value = '';
  document.getElementById('bank-note-input').value = '';
  document.getElementById('bank-modal').classList.add('active');
}
function editBankAccount(idx) {
  editingBankIndex = idx;
  const b = settings.bankAccounts[idx]; if (!b) return;
  document.getElementById('bank-modal-title').textContent = 'แก้ไขบัญชี';
  document.getElementById('bank-name-input').value = b.name;
  document.getElementById('bank-acc-input').value = b.acc;
  document.getElementById('bank-owner-input').value = b.owner;
  document.getElementById('bank-note-input').value = b.note || '';
  document.getElementById('bank-modal').classList.add('active');
}
function closeBankModal() { document.getElementById('bank-modal').classList.remove('active'); editingBankIndex = null; }
function saveBankAccount() {
  const name = document.getElementById('bank-name-input').value.trim();
  const acc = document.getElementById('bank-acc-input').value.trim();
  const owner = document.getElementById('bank-owner-input').value.trim();
  const note = document.getElementById('bank-note-input').value.trim();
  if (!name || !acc || !owner) { Swal.fire({ title: 'ผิดพลาด', text: 'กรุณากรอกข้อมูลให้ครบถ้วน', icon: 'warning', confirmButtonText: 'ตกลง' }); return; }
  if (editingBankIndex !== null) {
    settings.bankAccounts[editingBankIndex] = { name, acc, owner, note };
    addLog('settings', `แก้ไขบัญชี "${name}"`, 'Admin');
  } else {
    settings.bankAccounts.push({ name, acc, owner, note });
    addLog('settings', `เพิ่มบัญชี "${name}"`, 'Admin');
  }
  saveData('settings', settings);
  closeBankModal(); renderBankAccounts();
  toast('บันทึกบัญชีเรียบร้อย');
}
function deleteBankAccount(idx) {
  const b = settings.bankAccounts[idx]; if (!b) return;
  Swal.fire({ title: 'ลบบัญชี?', text: `ต้องการลบ "${b.name}" ใช่หรือไม่?`, icon: 'warning', showCancelButton: true, confirmButtonText: 'ลบ', cancelButtonText: 'ยกเลิก' }).then(r => {
    if (!r.isConfirmed) return;
    settings.bankAccounts.splice(idx, 1);
    saveData('settings', settings);
    addLog('settings', `ลบบัญชี "${b.name}"`, 'Admin');
    renderBankAccounts(); toast('ลบเรียบร้อย');
  });
}
function saveAllSettings() {
  settings.brandName = document.getElementById('set-brand-name').value.trim() || 'NEARBYSHOP';
  settings.brandSub = document.getElementById('set-brand-sub').value.trim() || 'Control Center';
  settings.siteEmail = document.getElementById('set-site-email').value.trim();
  settings.sitePhone = document.getElementById('set-site-phone').value.trim();
  settings.siteDiscord = document.getElementById('set-site-discord').value.trim();
  settings.tmFee = parseFloat(document.getElementById('set-tm-fee').value) || 2.9;
  settings.minTopup = parseFloat(document.getElementById('set-min-topup').value) || 0;
  saveData('settings', settings);
  applyTheme();
  addLog('settings', 'บันทึกการตั้งค่าทั้งหมด', 'Admin');
  toast('บันทึกการตั้งค่าทั้งหมดเรียบร้อย');
}

/* ============ CLIPBOARD ============ */
function copyToClipboard(text, successMsg = 'คัดลอกแล้ว') {
  const ok = () => toast(successMsg);
  const fail = () => toast('ไม่สามารถคัดลอก', 'error');
  const legacy = () => {
    try {
      const ta = document.createElement('textarea');
      ta.value = text; ta.style.position = 'fixed'; ta.style.opacity = '0';
      document.body.appendChild(ta); ta.select(); document.execCommand('copy'); ta.remove(); ok();
    } catch (e) { fail(); }
  };
  if (navigator.clipboard && window.isSecureContext) navigator.clipboard.writeText(text).then(ok).catch(legacy);
  else legacy();
}
function copyApiKeyString(key) { copyToClipboard(key, 'คัดลอก API Key'); }

/* ============ LOGOUT ============ */
function handleLogout() {
  Swal.fire({ title: 'ออกจากระบบ?', text: 'ต้องการออกจากระบบใช่หรือไม่', icon: 'warning', showCancelButton: true, confirmButtonText: 'ออก', cancelButtonText: 'ยกเลิก' }).then(r => {
    if (!r.isConfirmed) return;
    addLog('auth', 'ออกจากระบบ', 'Admin');
    toast('ออกจากระบบเรียบร้อย');
    setTimeout(() => { Swal.fire({ title: 'Demo Mode', text: 'นี่คือตัวอย่างเท่านั้น ไม่มีการเชื่อมต่อเซิร์ฟเวอร์จริง', icon: 'info', confirmButtonText: 'ตกลง' }); }, 300);
  });
}

/* ============ RESPONSIVE ============ */
function fixResponsive() {
  const w = window.innerWidth;
  const dashMid = document.getElementById('dash-mid-grid');
  if (dashMid) dashMid.style.gridTemplateColumns = w <= 900 ? '1fr' : '2fr 1fr';
  const dashStats2 = document.getElementById('dash-stats-2');
  if (dashStats2) {
    if (w <= 600) dashStats2.style.gridTemplateColumns = '1fr';
    else if (w <= 1100) dashStats2.style.gridTemplateColumns = 'repeat(2, 1fr)';
    else dashStats2.style.gridTemplateColumns = 'repeat(4, 1fr)';
  }
  const anGrid = document.getElementById('analytics-grid');
  if (anGrid) anGrid.style.gridTemplateColumns = w <= 700 ? '1fr' : '1fr 1fr';
  const anStats = document.getElementById('analytics-stats');
  if (anStats) {
    if (w <= 600) anStats.style.gridTemplateColumns = '1fr';
    else anStats.style.gridTemplateColumns = 'repeat(3, 1fr)';
  }
}

/* ============ MODAL OVERLAY ============ */
document.querySelectorAll('.modal-overlay').forEach(el => {
  el.addEventListener('click', e => { if (e.target === el) el.classList.remove('active'); });
});
document.addEventListener('keydown', e => {
  if (e.key === 'Escape') {
    document.querySelectorAll('.modal-overlay.active').forEach(el => el.classList.remove('active'));
    closeSidebar();
  }
});

/* ============ INIT ============ */
const PAGE_RENDER = {
  dashboard: () => renderDashboard(), analytics: () => renderAnalytics(), games: () => renderGamesTable(),
  orders: () => renderOrdersTable(), users: () => renderUsersTable(), topups: () => renderTopupsTable(),
  redeem: () => renderRedeemTable(), coupons: () => renderCouponsTable(), news: () => renderNewsList(),
  history: () => renderHistory('all'), health: () => renderHealth(), api: () => renderApiKeys(),
  logs: () => renderLogs(), settings: () => renderSettings()
};

/* รับ ?status=pending จากหน้าแดชบอร์ด */
function applyUrlFilters() {
  const status = new URLSearchParams(window.location.search).get('status');
  if (!status) return;
  const sel = document.getElementById(CURRENT_PAGE === 'orders' ? 'order-filter' : 'topup-filter');
  if (sel) sel.value = status;
}

document.addEventListener('DOMContentLoaded', () => {
  applyTheme();
  updateNavBadges();
  applyUrlFilters();
  if (PAGE_RENDER[CURRENT_PAGE]) PAGE_RENDER[CURRENT_PAGE]();
  let resizeTimer;
  window.addEventListener('resize', () => { clearTimeout(resizeTimer); resizeTimer = setTimeout(fixResponsive, 100); });
  fixResponsive();
});
